# -*- coding: utf-8 -*-
# Concept E exports: STEP (all parts, NURBS, assembly home pose with the yoke resting), print STLs in print orientation
# (05 yoke and 25 arrow upside down, 23 rail on its -y face, 24 axle standing on its rear ring).
import sys, os, json, shutil
sys.path.insert(0, r"C:\Users\Public\mbx_work")
import numpy as np
import trimesh
_argv = sys.argv
sys.argv = [sys.argv[0], r"C:\Users\Public\mbx_work\pf2_out"]
from ap1_export import step_write, write_stl
sys.argv = _argv
from ap1_view import load_cache
from ap1_tool import moved, bbox
from mf_tool import to_manifold

SESSION = r"C:\Users\호준\AppData\Roaming\Claude\scratch-workspaces\2484390f-f0f2-4f82-bbfe-32b4ca171b18\68694043-e7ab-4f63-8fec-837dd5148705\scratch-2026-10-12-dfb134"
OUT = os.path.join(SESSION, "Meloprint_PF2_E")
EXP = r"C:\Users\Public\mbx_work\in\e_export"
for d in (OUT, EXP):
    os.makedirs(d, exist_ok=True)
for sub in ("CAD/STEP", "Print_STL", "Print_STL/MW4", "images", "checks"):
    os.makedirs(os.path.join(OUT, sub), exist_ok=True)
I3 = np.eye(3)
FLIP_X = np.diag([1.0, -1.0, -1.0])
R_YOKE = np.array([[0, 0, 1], [0, 1, 0], [-1, 0, 0]], float)
R_X90 = np.array([[1, 0, 0], [0, 0, -1], [0, 1, 0]], float)      # new z = old y: rail 23 on its -y face, axle on its rear ring
PR = {"01_Base": I3, "02_Cover": FLIP_X, "03_MainGear": FLIP_X, "04_Handle": I3, "05_Yoke": FLIP_X, "06_CrankRoller": FLIP_X,
      "10_MainRetainer": I3, "11_Dial": FLIP_X, "15_CombLower": I3, "16_CombUpper": FLIP_X, "23_RearGuideRail": R_X90, "24_SyncAxle": R_X90, "25_Arrow": FLIP_X}
COMMON = ("03_MainGear", "04_Handle", "05_Yoke", "06_CrankRoller", "10_MainRetainer", "11_Dial", "23_RearGuideRail", "24_SyncAxle")
rep = {"stl": {}}


def put(rel, shape, R, name):
    mm = to_manifold(shape, 0.005).to_mesh()
    V = np.array(mm.vert_properties)[:, :3].astype(float) @ R.T
    V -= np.array([(V[:, 0].min() + V[:, 0].max()) / 2, (V[:, 1].min() + V[:, 1].max()) / 2, V[:, 2].min()])
    F = np.array(mm.tri_verts).astype(np.int64)
    p = os.path.join(OUT, rel)
    write_stl(p, V, F, name)
    t = trimesh.load(p)
    rep["stl"][rel] = {"watertight": bool(t.is_watertight), "volume": round(float(t.volume), 2), "size": [round(float(v), 2) for v in t.extents]}
    print("%-40s %s" % (rel, rep["stl"][rel]), flush=True)


def step(name, shape):
    p = os.path.join(OUT, "CAD/STEP", name + ".step")
    step_write([(name, shape)], p)
    shutil.copy(p, os.path.join(EXP, name + ".step"))


for var in ("AP1", "MW4"):
    S = load_cache(r"C:\Users\Public\mbx_work\in\e_brep_%s" % var.lower())
    for n, s in S.items():
        if n in COMMON and var == "MW4":
            continue
        pose = moved(s, 0, 0, -0.248) if n in ("05_Yoke", "25_Arrow") else s
        nm = n if n in COMMON else "%s_%s" % (n, var)
        step(nm, pose)
        put(("Print_STL/%s.stl" if var == "AP1" or n in COMMON else "Print_STL/MW4/%s.stl") % nm, s, PR[n], nm)
HW = load_cache(r"C:\Users\Public\mbx_work\in\e_hw")
step_write([(n, HW[n]) for n in sorted(HW)], os.path.join(OUT, "CAD/STEP", "Hardware_M3x5.step"))
shutil.copy(os.path.join(OUT, "CAD/STEP", "Hardware_M3x5.step"), os.path.join(EXP, "Hardware_M3x5.step"))
json.dump({n: [round((bbox(s)[i] + bbox(s)[i + 3]) / 2, 3) for i in range(3)] + [round(bbox(s)[i + 3] - bbox(s)[i], 3) for i in range(3)]
           for n, s in HW.items()}, open(os.path.join(EXP, "hw_centers.json"), "w"), indent=1)
json.dump(rep, open(os.path.join(OUT, "checks", "export_E.json"), "w"), indent=1)
json.dump(rep, open(os.path.join(EXP, "export_E.json"), "w"), indent=1)
print("done")
