# -*- coding: utf-8 -*-
# Concept E parts as NURBS B-rep (OCC): sync axle (exact involute pinions: B-spline flanks, circular tip/root arcs,
# rolling rings), straight-sided racks, new rail 23, and the modifications of the D base / cover / yoke / main gear.
import sys, math
sys.path.insert(0, r"C:\Users\Public\mbx_work")
import numpy as np
from OCP.gp import gp_Pnt, gp_Ax2, gp_Dir, gp_Vec
from OCP.GC import GC_MakeSegment, GC_MakeArcOfCircle
from OCP.TColgp import TColgp_HArray1OfPnt
from OCP.GeomAPI import GeomAPI_Interpolate
from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeEdge, BRepBuilderAPI_MakeWire, BRepBuilderAPI_MakeFace
from OCP.BRepPrimAPI import BRepPrimAPI_MakePrism, BRepPrimAPI_MakeCylinder
from ap1_tool import cut, fuse, box, cyl, moved, valid, n_solids
from ap1_mods import hexagon
from occ_conv import volume
from c2_parts import poly_prism
import e_layout as L

inv = lambda a: math.tan(a) - a


def _checked(op_cls, a, t, kind):
    """Boolean with a volume check: OCC sometimes returns the input unchanged (valid but wrong)."""
    from ap1_tool import _bool
    from OCP.BRepAlgoAPI import BRepAlgoAPI_Common
    import manifold3d as m3
    from mf_tool import to_manifold
    from OCP.TopExp import TopExp_Explorer
    from OCP.TopAbs import TopAbs_SOLID
    from OCP.TopoDS import TopoDS
    va, vt = volume(a), volume(t)
    # common volume independent of OCC (OCC common can fail silently too), solid by solid
    ex = TopExp_Explorer(a, TopAbs_SOLID)
    mt = to_manifold(t, 0.003)
    cm, bad = 0.0, False
    while ex.More():
        so = TopoDS.Solid_s(ex.Current())
        ms = to_manifold(so, 0.003)
        if ms.status() != m3.Error.NoError or abs(ms.volume() - volume(so)) > 1e-3 * abs(volume(so)) + 0.05:
            bad = True
        cm += (ms ^ mt).volume()
        ex.Next()
    if bad:
        cm = max(volume(_bool(BRepAlgoAPI_Common, a, t, f)) for f in (5e-3, 1e-5))
    log = []
    for fz in (5e-3, 1e-5, 1e-3, 2e-2, 1e-4):
        try:
            r = _bool(op_cls, a, t, fz)
        except RuntimeError:
            continue
        exp = va - cm if kind == "cut" else va + vt - cm
        log.append((fz, valid(r), n_solids(r), round(volume(r), 3), round(exp, 3)))
        if not valid(r) and n_solids(r) >= 1:
            from ap1_tool import _fix
            r = _fix(r)
        if valid(r) and n_solids(r) >= 1 and abs(volume(r) - exp) < 2e-4 * max(1.0, abs(exp)) + 0.01 * cm + 0.05:
            return r
    from ap1_tool import bbox
    raise RuntimeError("%s failed volume check tool bbox %s log %s" % (kind, [round(v, 2) for v in bbox(t)], log))


def vcut(a, *tools):
    from OCP.BRepAlgoAPI import BRepAlgoAPI_Cut
    for t in tools:
        a = _checked(BRepAlgoAPI_Cut, a, t, "cut")
    return a


def vfuse(a, *tools):
    from OCP.BRepAlgoAPI import BRepAlgoAPI_Fuse
    for t in tools:
        a = _checked(BRepAlgoAPI_Fuse, a, t, "fuse")
    return a


def _pt(u, v, y):
    return gp_Pnt(float(u), float(y), float(v))           # profile (u, v) -> global (x = u, z = v) at y


def pinion_face(y, cx=0.0, cz=L.AXLE_Z, phase_deg=0.0):
    """Planar face of the involute pinion in the plane y = const, tooth 0 pointing -z at phase 0."""
    pa = math.radians(L.PA)
    rp, rb, ra, rf = L.RP, L.RP * math.cos(pa), L.RA, L.RF
    s = L.M * (math.pi / 2.0 + 2.0 * L.X_SHIFT * math.tan(pa)) - L.THIN_PINION
    half_b = s / (2.0 * rp) + inv(pa)
    pitch = 2.0 * math.pi / L.Z
    rr = np.linspace(rb, ra, 13)
    th = [half_b - inv(math.acos(min(1.0, rb / r))) for r in rr]
    P = lambda r, a: (cx + r * math.cos(a), cz + r * math.sin(a))
    segs = []                                              # CCW in (x, z)
    for k in range(L.Z):
        c = math.radians(-90.0 + phase_deg) + k * pitch
        segs.append(("line", [P(rf, c - half_b), P(rb, c - half_b)]))
        segs.append(("spl", [P(r, c - t) for r, t in zip(rr, th)]))
        segs.append(("arc", [P(ra, c - th[-1]), P(ra, c), P(ra, c + th[-1])]))
        segs.append(("spl", [P(r, c + t) for r, t in zip(rr[::-1], th[::-1])]))
        segs.append(("line", [P(rb, c + half_b), P(rf, c + half_b)]))
        a0, a1 = c + half_b, c + pitch - half_b
        segs.append(("arc", [P(rf, a0), P(rf, 0.5 * (a0 + a1)), P(rf, a1)]))
    # CCW in (x, z) has normal -y; reverse so the face normal is +y (prism along +y stays outward)
    segs = [(t, p[::-1]) for t, p in segs[::-1]]
    w = BRepBuilderAPI_MakeWire()
    for t, p in segs:
        if t == "line":
            e = BRepBuilderAPI_MakeEdge(GC_MakeSegment(_pt(*p[0], y), _pt(*p[1], y)).Value()).Edge()
        elif t == "arc":
            e = BRepBuilderAPI_MakeEdge(GC_MakeArcOfCircle(_pt(*p[0], y), _pt(*p[1], y), _pt(*p[2], y)).Value()).Edge()
        else:
            arr = TColgp_HArray1OfPnt(1, len(p))
            for i, q in enumerate(p):
                arr.SetValue(i + 1, _pt(*q, y))
            it = GeomAPI_Interpolate(arr, False, 1e-7)
            it.Perform()
            e = BRepBuilderAPI_MakeEdge(it.Curve()).Edge()
        w.Add(e)
    return BRepBuilderAPI_MakeFace(w.Wire(), True).Face()


def pinion(y0, y1, **kw):
    s = BRepPrimAPI_MakePrism(pinion_face(y0, **kw), gp_Vec(0, y1 - y0, 0)).Shape()
    assert volume(s) > 0
    return s


def cyl_y(r, y0, y1, cx=0.0, cz=L.AXLE_Z):
    return BRepPrimAPI_MakeCylinder(gp_Ax2(gp_Pnt(cx, y0, cz), gp_Dir(0, 1, 0)), r, y1 - y0).Shape()


def sync_axle():
    s = cyl_y(L.AXLE_R, L.R_RING[0], L.F_PIN[1])
    s = fuse(s, cyl_y(L.RP, *L.R_RING), pinion(*L.R_PIN), cyl_y(L.RP, *L.F_RING), pinion(*L.F_PIN))
    return s


def rack_teeth(y0, y1, x_lim=L.RACK_X):
    """Straight-sided rack teeth (20 deg flanks) between the root and tip lines, spaces centred on x = k*pitch."""
    half = (L.PITCH / 2.0 - L.THIN_RACK) / 2.0
    t = math.tan(math.radians(L.PA))
    z0, z1 = L.RACK_ROOT - 0.02, L.RACK_TIP
    hb = half + (L.RACK_REF - z0) * t
    ht = half - (z1 - L.RACK_REF) * t
    out = None
    k = 0
    xs = []
    while (k + 0.5) * L.PITCH <= x_lim:
        xs += [(k + 0.5) * L.PITCH, -(k + 0.5) * L.PITCH]
        k += 1
    for xc in sorted(xs):
        tooth = poly_prism([(xc - hb, y0, z0), (xc + hb, y0, z0), (xc + ht, y0, z1), (xc - ht, y0, z1)], (0, y1 - y0, 0))
        out = tooth if out is None else fuse(out, tooth)
    return out


# ------------------------------------------------------------------ base, rail 23, cover, main gear, yoke
def base_e(B):
    gy0, gy1 = L.FR_GROOVE
    B = vcut(B, box(-43.2, 17.6, L.STRIP_Z, 43.2, 21.62, 10.3))                    # old rail top 9.85 -> 9.3
    B = vfuse(B, box(-43.25, 21.5, -3.31, 43.25, L.FR_Y1, L.STRIP_Z))               # rail widened to y 23.6
    B = vcut(B, box(-43.2, gy0, L.RACK_ROOT, 43.2, gy1, L.STRIP_Z + 0.5))          # rack groove
    B = vfuse(B, rack_teeth(*L.FR_TEETH))
    # rail 23 ledges follow the wider rail; ledge block for the rail screw
    for sx in (1, -1):
        B = vfuse(B, box(min(26.0 * sx, 43.25 * sx), -67.9, -3.31, max(26.0 * sx, 43.25 * sx), L.R23_Y1, 1.6))
    sxs, sys_ = L.R23_SCREW
    B = vcut(B, cyl(sxs, sys_, 3.1, -4.9, L.SCREW_HEAD_SEAT), cyl(sxs, sys_, 1.65, L.SCREW_HEAD_SEAT - 0.1, 1.7))
    # main gear tilt pad
    r0, r1, zt = L.MAIN_PAD
    pad = vcut(cyl(0.0, -23.218, r1, -3.4, zt), cyl(0.0, -23.218, r0, -3.5, zt + 0.1))
    B = vfuse(B, pad)
    # printed journal for the handle gear (no 608): old stub, shoulders and ring off, D9 post + thrust ring
    hx, hy = L.HANDLE_C
    B = vcut(B, cyl(hx, hy, 7.6, -3.3, 5.3))
    post = vfuse(cyl(hx, hy, L.POST_R, -3.45, L.POST_TOP - 0.5), _cone(hx, hy, L.POST_TOP - 0.5, L.POST_R, L.POST_TOP, L.POST_R - 0.5))
    B = vfuse(B, vfuse(post, cyl(hx, hy, L.THRUST_R, -3.45, L.THRUST_TOP)))
    # case screws thread into the corner columns (no nuts): fill the nut pocket inside the column, D2.6 pilot
    import c_case as CC
    for cx, cy in CC.CORNERS:
        sx = 1 if cx > 0 else -1
        z0 = CC.NUT_Z0_FRONT if cy < 0 else CC.NUT_Z0_REAR
        # fill stays 0.1 inside the column faces (coincident faces break the fuse); the slot mouth keeps a 0.1 recess
        f = vfuse(cyl(cx, cy, 3.75, z0 - 0.1, CC.NUT_TOP + 0.1), cyl(cx, cy, 1.75, CC.NUT_TOP, 14.722))
        if cy > 0:                                      # rear columns are clipped next to the cover wall (as in c_case)
            from ap1_mods import common
            f = common(f, box(cx - 2.45 if sx > 0 else cx - 3.9, cy - 3.9, z0 - 1, cx + 3.9 if sx > 0 else cx + 2.45, cy + 3.0, 15.0))
        # the pilot goes into the fill before it is fused (cutting the fused column afterwards breaks the B-rep);
        # below the fill the old D3.2 hole continues the pilot
        B = vfuse(B, vcut(f, cyl(cx, cy, L.PILOT_R, z0 - 0.5, 15.0)))
    return B


def rail23_e():
    y0, y1 = L.R23_Y0, L.R23_Y1
    X = L.R23_X
    s = box(-X, y0, 1.6, X, y1, L.STRIP_Z)                                       # outer parts and keel from z 1.6
    s = vcut(s, box(-10.5, y0 - 0.1, 1.5, 10.5, y1 + 0.1, 6.85))                  # middle over the handle gear boss
    g0, g1 = L.R23_GROOVE
    s = vcut(s, box(-X - 0.1, g0, L.RACK_ROOT, X + 0.1, g1, L.STRIP_Z + 0.5))
    s = vfuse(s, rack_teeth(*L.R23_TEETH))
    for sx in (1, -1):                                                           # v47 pins into the base holes
        s = vfuse(s, cyl(36.0 * sx, L.R23_PIN_Y, 1.35, -0.4, 1.61))
    nx, ny = L.R23_SCREW
    return vcut(s, cyl(nx, ny, L.PILOT_R, 1.5, 6.0))                             # M3x5 from below threads in (no nut)


def cover_e(C):
    C = vcut(C, box(-43.2, -25.6, 13.5, 43.2, -20.8, L.CEILING_Z))                       # mid rib (axle passes there)
    C = vcut(C, box(-43.2, -71.3, 12.0, 43.2, -67.3, L.CEILING_Z))                       # rear rib + D pad
    C = vcut(C, box(-41.6, L.R_PIN[0] - 0.3, L.CEILING_Z - 0.1, 41.6, L.R_PIN[1] + 0.3, 18.75))  # rear pinion relief
    x0, y0, x1, y1 = L.COVER_BAR_CUT
    return vcut(C, box(x0, y0, 17.0, x1, y1, 30.0))      # bar between window and comb opening: the pluck shows


def main_gear_e(G):
    """Crank pin moved to the roller (part 06): the gear keeps a flat top (z 5.5) and a blind pin hole, so it prints
    upside down on that top face with no support under the outer ring."""
    px, py = L.CRANK_PIN
    G = vcut(G, cyl(px, py, 3.3, L.GEAR_TOP, 12.6))                                # v47 pin, shoulder and head off
    h0, h1 = L.PIN_HOLE_Z
    return vcut(G, vfuse(cyl(px, py, L.PIN_HOLE_R, h0, h1 + 0.1),
                         cyl(px, py, L.PIN_HOLE_R + 0.25, h1 - 0.3, h1 + 0.1)))     # mouth relief (bed side, elephant foot)


def crank_roller_e():
    """06 roller with its own crank pin (one part): roller r 3.5 rolls on the slot walls, the pin turns in the gear's
    blind hole. The v47 bottom flange is gone: the sync axle above limits the lift. Printed upside down."""
    from OCP.BRepFilletAPI import BRepFilletAPI_MakeChamfer
    px, py = L.CRANK_PIN
    r0, r1 = L.ROLLER_Z
    p0 = L.PIN_Z[0]
    R = vfuse(cyl(px, py, L.ROLLER_R, r0, r1), cyl(px, py, L.PIN_R, p0, r0 + 0.05))
    R = vcut(R, vcut(cyl(px, py, L.ROLLER_R + 1, r1 - 0.3, r1 + 1), _cone(px, py, r1 - 0.3, L.ROLLER_R, r1, L.ROLLER_R - 0.3)))
    R = vcut(R, vcut(cyl(px, py, L.PIN_R + 1, p0 - 1, p0 + 0.3), _cone(px, py, p0, L.PIN_R - 0.3, p0 + 0.3, L.PIN_R)))
    return R


def _cone(x, y, z0, r0, z1, r1):
    from OCP.BRepPrimAPI import BRepPrimAPI_MakeCone
    return BRepPrimAPI_MakeCone(gp_Ax2(gp_Pnt(x, y, z0), gp_Dir(0, 0, 1)), r0, r1, z1 - z0).Shape()


def handle_heal(G):
    """v47 gear: the dial-nut core sits in the r 4.6 bore on coincident faces (zero-width crack with internal faces,
    z 19.4..25.2). Fill the core solid, then cut the nut pocket (nut fed up the hollow shaft) and the screw hole again."""
    from ap1_tool import bbox
    hx, hy = 0.0, -80.544
    top = bbox(G)[5]

    def hexp(af, z0, z1):
        rr = af / 2.0 / math.cos(math.radians(30))
        return poly_prism([(hx + rr * math.cos(math.radians(30 + 60 * k)), hy + rr * math.sin(math.radians(30 + 60 * k)), z0) for k in range(6)], (0, 0, z1 - z0))
    G = vfuse(G, cyl(hx, hy, 4.75, 19.40, top))
    return vcut(G, hexp(5.75, 19.40, 21.50), hexp(5.60, 21.45, 24.00), cyl(hx, hy, 1.6, 23.9, top + 0.5))


def handle_plain(G):
    """Handle gear without the 608: seat, crush ribs, relief and nut passage filled; D9.4 bore runs on the base post
    from the hub bottom to the core (journal 20.8 mm); the dial screw threads into a D2.6 pilot in the solid core."""
    from ap1_tool import bbox
    hx, hy = L.HANDLE_C
    top = bbox(G)[5]
    G = vfuse(G, cyl(hx, hy, 11.25, -1.8, 6.0))
    G = vfuse(G, cyl(hx, hy, 4.75, 5.9, 8.8))
    G = vfuse(G, cyl(hx, hy, 4.75, 19.40, top))
    G = vcut(G, cyl(hx, hy, L.GEAR_BORE_R, -1.9, 19.40))
    G = vcut(G, _cone(hx, hy, -1.9, L.GEAR_BORE_R + 0.6, -1.3, L.GEAR_BORE_R))       # lead-in on the bed face
    return vcut(G, cyl(hx, hy, L.PILOT_R, 20.9, top + 0.5))


def yoke_e(Yfile):
    """D yoke (file coords) -> E yoke (file coords). Work in resting coords."""
    dz = L.YOKE_FILE_DZ
    Y = moved(Yfile, 0, 0, -dz)
    cx = L.CHEEK_X
    Y = vcut(Y, box(-cx, 17.55, 7.0, cx, 23.7, 20.95),                           # front pinion / ring / old stem
            box(-7.2, 17.55, 3.0, 7.2, 23.7, 10.1),                              # widened front rail, old legs
            box(-7.2, -28.0, 10.76, 7.2, -18.5, 17.6),                            # old hump (cover mid rib gone)
            box(-7.2, -72.5, 3.0, 7.2, -64.5, 13.0),                              # whole D rear end (rebuilt below)
            box(-3.2, 16.0, 7.0, 3.2, 17.6, 10.35),                               # slot front wall under the axle (traps it)
            box(-3.2, -64.6, 7.0, 3.2, -63.9, 10.35))                             # slot rear end wall under the axle
    # front end (D guide legs, floor, v47 pick) rebuilt from clean prisms: the pick's spline faces will not fuse
    # with the front block; the box below contains them whole so they are only classified, never intersected
    pick = _pick_section(Y)
    Y = vcut(Y, box(-7.3, 23.65, 3.0, 7.3, 29.0, 25.0))
    cz, cr, co = L.CRADLE_Z, L.CRADLE_R, L.CRADLE_OPEN
    # printed upside down (top plane z 17.3 on the bed): everything hangs from the top plane. No arrow: the pick
    # rises as a fin to the top plane and is what shows through the cover opening, right where it plucks
    parts = [box(-7.0, L.FRONT_CRADLE[0], 10.3, 7.0, L.FRONT_CRADLE[1], L.TOP_Z),
             box(-7.0, L.REAR_CRADLE[0], 10.3, 7.0, L.REAR_CRADLE[1], L.TOP_Z),
             box(-7.0, L.LIP[0], 7.2, 7.0, L.LIP[1], L.TOP_Z),                    # rear lip behind rail 23
             # lip thickened 0.65 -> 1.9 between the handle hub's two 45 deg cones (gap >= 0.54 over the hub's axial play)
             poly_prism([(-7.0, y, z) for y, z in L.LIP_BACK], (14.0, 0, 0)),
             box(-7.0, -27.0, L.AXLE_Z + L.AXLE_R + 0.15, 7.0, -19.0, L.TOP_Z)]   # mid portal tie over the axle
    for sx in (1, -1):
        parts.append(box(min(cx * sx, 7.0 * sx), 17.7, 10.1, max(cx * sx, 7.0 * sx), L.FRONT_END_Y, L.TOP_Z))
        parts.append(box(min(cx * sx, 7.0 * sx), L.LIP[0], 10.1, max(cx * sx, 7.0 * sx), -67.0, L.TOP_Z))
        # slot walls full height between the cradles (roller faces stay vertical when printed upside down)
        parts.append(box(min(3.65 * sx, 7.0 * sx), L.REAR_CRADLE[1] - 0.5, 10.6, max(3.65 * sx, 7.0 * sx), L.FRONT_CRADLE[0] + 0.5, L.TOP_Z))
    N = parts[0]
    for p in parts[1:]:
        N = vfuse(N, p)
    Y = vfuse(Y, N)
    # front end, fused piece by piece (as one block the union came out invalid)
    front = [box(-7.0, 23.7, 3.852, 7.0, L.FRONT_END_Y, 5.202)]                # floor under the whole pick fin
    for sx in (1, -1):
        front.append(box(min(4.95 * sx, 7.0 * sx), 23.7, 3.852, max(4.95 * sx, 7.0 * sx), L.FRONT_END_Y, 10.75))   # guide legs (front rail +y face)
    front.append(poly_prism([(x, y, 5.10) for x, y in pick], (0, 0, 11.032 - 5.10)))
    fin = _clip_y(pick, L.FRONT_END_Y)                                         # above the pluck band: 0.34 short of the comb
    front.append(poly_prism([(x, y, 10.9) for x, y in fin], (0, 0, L.TOP_Z - 10.9)))
    for p in front:
        Y = vfuse(Y, p)
    # axle channel last: downward-open cradles (r 3.1, opening 6.1) through both blocks and the old slot end walls
    y0, y1 = L.REAR_CRADLE[0] - 0.15, L.FRONT_CRADLE[1] + 0.05
    Y = vcut(Y, vfuse(cyl_y(cr, y0, y1, cz=cz), box(-co, y0, 10.2, co, y1, cz)))
    # v47 arrow and stem off: the top plane is the print bed
    Y = vcut(Y, box(-8.0, -75.0, L.TOP_Z, 8.0, 32.0, 26.0))
    return moved(Y, 0, 0, dz)


def _clip_y(P, ymax):
    """Clip a polygon to y <= ymax (Sutherland-Hodgman, one edge)."""
    out = []
    for i in range(len(P)):
        a, b = P[i - 1], P[i]
        ia, ib = a[1] <= ymax, b[1] <= ymax
        if ia != ib:
            t = (ymax - a[1]) / (b[1] - a[1])
            out.append((a[0] + t * (b[0] - a[0]), ymax))
        if ib:
            out.append(b)
    clean = []
    for q in out:                                        # drop points closer than 0.02 (sliver edges at the cut)
        if not clean or (abs(q[0] - clean[-1][0]) + abs(q[1] - clean[-1][1])) > 0.02:
            clean.append(q)
    if (abs(clean[0][0] - clean[-1][0]) + abs(clean[0][1] - clean[-1][1])) <= 0.02:
        clean.pop()
    return clean


def _pick_section(Y):
    """Section of the v47 pick (constant from z 6 to its top 11.032) as a polygon, collinear points dropped."""
    from mf_tool import to_manifold
    M = to_manifold(Y, 0.002)
    P = [np.array(p) for p in M.slice(8.0).to_polygons()]
    P = [p for p in P if p[:, 1].min() > 24.9 and abs(p[:, 0].mean()) < 1.0][0]
    keep = []
    for i in range(len(P)):
        a, b, c = P[i - 1], P[i], P[(i + 1) % len(P)]
        u, v = b - a, c - b
        if abs(u[0] * v[1] - u[1] * v[0]) > 1e-6 and np.linalg.norm(u) > 1e-4:
            keep.append((float(b[0]), float(b[1])))
    return keep


def _offset_poly(P, d):
    """Mitre offset of a convex CCW polygon by d (outward > 0)."""
    P = [np.array(p, float) for p in P]
    n = len(P)
    lines = []
    for i in range(n):
        a, b = P[i], P[(i + 1) % n]
        t = (b - a) / np.linalg.norm(b - a)
        nn = np.array([t[1], -t[0]])                     # outward normal of a CCW polygon
        lines.append((a + nn * d, t))
    out = []
    for i in range(n):
        (p1, t1), (p2, t2) = lines[i - 1], lines[i]
        A = np.array([t1, -t2]).T
        s_ = np.linalg.solve(A, p2 - p1)
        out.append(tuple(p1 + t1 * s_[0]))
    return out


def arrow_socket_poly():
    """Socket = peg + 0.10 clearance, with a crush rib (0.25 high, 0.9 wide) in the middle of each slanted side:
    0.15 interference pushes the peg against the rear wall."""
    Q = _offset_poly(L.ARROW_PEG, 0.10)                 # rear-left, rear-right, front-right, front-left
    out = []
    for i in range(4):
        a, b = np.array(Q[i]), np.array(Q[(i + 1) % 4])
        out.append(tuple(a))
        if i in (1, 3):                                  # slanted sides
            ln = np.linalg.norm(b - a); t = (b - a) / ln; nn = np.array([t[1], -t[0]])
            m = (a + b) / 2
            out += [tuple(m - t * 0.45), tuple(m - nn * 0.25), tuple(m + t * 0.45)]
    return out


def arrow_e():
    """25 arrow (file coords like the yoke): the v47 arrow plate on two stems that sit on the yoke top, and a
    tapered peg pressed into the front block. Printed face down."""
    za, zb = L.ARROW_Z
    A = poly_prism([(x, y, za) for x, y in L.ARROW_PLATE], (0, 0, zb - za))
    tail = box(-3.0, 14.6, L.TOP_Z, 3.0, 17.55, za + 0.15)                 # original stem, rests on the front cradle
    head = poly_prism([(x, y, L.TOP_Z) for x, y in L.ARROW_HEAD_STEM], (0, 0, za + 0.15 - L.TOP_Z))
    p0, p1 = L.ARROW_PEG_Z
    peg = poly_prism([(x, y, p0 + 0.5) for x, y in L.ARROW_PEG], (0, 0, L.TOP_Z + 0.05 - p0 - 0.5))
    tipc = poly_prism([(x, y, p0) for x, y in _offset_poly(L.ARROW_PEG, -0.25)], (0, 0, 0.55))
    N = vfuse(tail, head)
    N = vfuse(N, peg)
    N = vfuse(N, tipc)
    return moved(vfuse(A, N), 0, 0, L.YOKE_FILE_DZ)


def hardware_e():
    """The only bought parts: 6 M3x5 socket head screws (4 case, dial, rail 23); they thread into printed pilots."""
    import c_case as CC
    import c2_layout as CL
    out = {}
    for i, (cx, cy) in enumerate(CC.CORNERS):
        out["HW_M3x5_Case_%d" % (i + 1)] = fuse(cyl(cx, cy, 2.75, CC.CB_Z_NEW, CC.CB_Z_NEW + 3.0), cyl(cx, cy, 1.5, CC.CB_Z_NEW - 5.0, CC.CB_Z_NEW + 0.01))
    cx, cy = CL.DIAL_C
    seat = CC.DIAL_CB_SEAT
    out["HW_M3x5_Dial"] = fuse(cyl(cx, cy, 2.75, seat, seat + 3.0 - 0.02), cyl(cx, cy, 1.5, seat - 5.0, seat + 0.01))
    nx, ny = L.R23_SCREW
    hs = L.SCREW_HEAD_SEAT
    out["HW_M3x5_Rail"] = fuse(cyl(nx, ny, 2.75, hs - 3.0, hs), cyl(nx, ny, 1.5, hs - 0.01, hs + 5.0))
    return out
