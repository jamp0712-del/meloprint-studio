# -*- coding: utf-8 -*-
# Build site_E from site_v47: E parts (sync axle + racks), viewer assets, 14 decorative covers, CAD, packages, texts,
# and the sync-axle motion in the viewer.
import os, sys, re, shutil, zipfile, hashlib, json
sys.path.insert(0, r"C:\Users\Public\mbx_work")
import numpy as np, trimesh, manifold3d as m3
from ap1_view import load_cache
from ap1_tool import moved
from mf_tool import to_manifold
W = r"C:\Users\Public\mbx_work"
S47, D = W + r"\site_v47", W + r"\site_E"
SESSION = r"C:\Users\호준\AppData\Roaming\Claude\scratch-workspaces\2484390f-f0f2-4f82-bbfe-32b4ca171b18\68694043-e7ab-4f63-8fec-837dd5148705\scratch-2026-10-12-dfb134"
EDIR = os.path.join(SESSION, "Meloprint_PF2_E")
sha = lambda b: hashlib.sha256(b).hexdigest()
rd = lambda p: open(p, "rb").read()
shutil.rmtree(D, ignore_errors=True)
shutil.copytree(S47, D)


def stl_bytes(shape, defl=0.004, dz=0.0, extra=None):
    mm = to_manifold(shape, defl)
    if extra is not None:                        # viewer: 25 arrow merged into the 05 yoke mesh (moves with it)
        mm = mm + to_manifold(extra, defl)
    assert mm.status() == m3.Error.NoError
    if dz:
        mm = mm.translate((0, 0, dz))
    mm = mm.to_mesh()
    t = trimesh.Trimesh(np.array(mm.vert_properties)[:, :3].astype(float), np.array(mm.tri_verts).astype(np.int64))
    assert t.is_watertight
    return t.export(file_type="stl")


# ---------------------------------------------------------------- viewer assets (CAD frame, home pose; yoke resting on the axle)
EA = load_cache(W + r"\in\e_brep_ap1")
EM = load_cache(W + r"\in\e_brep_mw4")
HW = load_cache(W + r"\in\e_hw")
A = os.path.join(D, "assets", "pf2")
for src, dst, dz in (("01_Base", "01_Base_AP1", 0), ("02_Cover", "02_Cover_AP1", 0), ("03_MainGear", "03_MainGear_AP1", 0), ("04_Handle", "04_Handle_AP1", 0),
                     ("05_Yoke", "05_Yoke_AP1", -0.248), ("10_MainRetainer", "10_MainRetainer_AP1", 0),
                     ("11_Dial", "11_HandleRetainer_AP1", 0), ("23_RearGuideRail", "23_RearGuideRail", 0), ("24_SyncAxle", "24_SyncAxle", 0)):
    open(os.path.join(A, dst + ".stl"), "wb").write(stl_bytes(EA[src], 0.004 if src != "24_SyncAxle" else 0.002, dz,
                                                              EA.get("25_Arrow") if src == "05_Yoke" else None))
open(os.path.join(A, "01_Base_MW4.stl"), "wb").write(stl_bytes(EM["01_Base"]))
Vs, Fs, off = [], [], 0
for n in sorted(HW):
    mm = to_manifold(HW[n], 0.01).to_mesh()
    V = np.array(mm.vert_properties)[:, :3].astype(float); F = np.array(mm.tri_verts).astype(np.int64)
    Vs.append(V); Fs.append(F + off); off += len(V)
open(os.path.join(A, "M3_Hardware.stl"), "wb").write(trimesh.Trimesh(np.vstack(Vs), np.vstack(Fs), process=False).export(file_type="stl"))
print("viewer assets ok", flush=True)

# ---------------------------------------------------------------- models: MW4 base print, 14 covers
t = trimesh.load(os.path.join(EDIR, "Print_STL", "MW4", "01_Base_MW4.stl"))
V = t.vertices.copy(); V -= np.array([(V[:, 0].min() + V[:, 0].max()) / 2, V[:, 1].min(), V[:, 2].min()])
open(os.path.join(D, "models", "01_Base_MW4_PRINT.stl"), "wb").write(trimesh.Trimesh(V, t.faces, process=False).export(file_type="stl"))
covers = json.load(open(W + r"\e_site_assets\covers_E.json"))
for f in os.listdir(W + r"\e_site_assets\models"):
    shutil.copy2(os.path.join(W, "e_site_assets", "models", f), os.path.join(D, "models", f))
print("models ok", flush=True)

# ---------------------------------------------------------------- CAD
for f in os.listdir(os.path.join(D, "cad")):
    if f.endswith(".3dm"):
        os.remove(os.path.join(D, "cad", f))
CADF = {"current": ("Meloprint_PF2_E_AP1_Assembly.3dm", "Meloprint_PF2_E_Assembly.3dm", 3251),
        "makerworld": ("Meloprint_PF2_E_MW4_Assembly.3dm", "Meloprint_PF2_E_MW4_Assembly.3dm", 2884)}
for tag, (src, dst, faces) in CADF.items():
    shutil.copy2(os.path.join(W, "pfc_out", src), os.path.join(D, "cad", dst))

# ---------------------------------------------------------------- packages
ESRC = ("e_layout.py", "e_parts.py", "e_helical.py", "e_mods.py", "e_validate.py", "e_helical_check.py", "e_statics.py", "e_print_audit.py",
        "e_print_fig.py", "e_coupons.py", "e_versions.py", "make_E_artifact.py", "e_export.py", "rh_build_e.py", "e_figs.py", "e_rail_check.py", "e_site_covers.py", "e_comb_fit.py", "build_E_site.py")
checks = {"E_checks/comb-fit.json": rd(W + r"\in\e_comb_fit.json"), "E_checks/validate-ap1.json": rd(W + r"\in\e_validate_ap1.json"), "E_checks/validate-mw4.json": rd(W + r"\in\e_validate_mw4.json"),
          "E_checks/drawer-statics.json": rd(W + r"\in\e_statics.json"), "E_checks/rail-stiffness.json": rd(W + r"\in\e_rail_check.json"),
          "E_checks/rhino7-build.log": rd(W + r"\rh_build_e.log"), "E_checks/export.json": rd(W + r"\in\e_export\export_E.json"),
          "E_checks/site-covers.json": rd(W + r"\e_site_assets\covers_E.json"),
          "E_checks/print-audit.json": rd(W + r"\in\e_print_audit.json"), "E_checks/helical-gears.json": rd(W + r"\in\e_helical_check.json")}
sources = {"E_source/" + f: rd(os.path.join(W, f)) for f in ESRC}
readme = rd(os.path.join(EDIR, "README_E.md"))
images = {"E_images/" + f: rd(os.path.join(EDIR, "images", f)) for f in os.listdir(os.path.join(EDIR, "images"))}
DROP = re.compile(r"^(history/source/input/.*\.brep|history/source/v41/.*\.brep|history/v44/.*\.step|history/source/v42/.*\.step|"
                  r"v4[3-7]_native_parts/.*|Meloprint_PF2_v47.*\.3dm|SHA256\.json|3dm_checks\.json|print_stl/06_CrankRoller_AP1\.stl)$")
PS = os.path.join(EDIR, "Print_STL")
for tag, zname, pk in (("current", "Meloprint_PF2_Print_Package.zip", "AP1"), ("makerworld", "Meloprint_PF2_MW4_Print_Package.zip", "MW4")):
    zin = zipfile.ZipFile(os.path.join(S47, "downloads", zname))
    sub = "" if pk == "AP1" else "MW4"
    repl = {"print_stl/01_Base_%s_PRINT.stl" % pk: rd(os.path.join(PS, sub, "01_Base_%s.stl" % pk)),
            "print_stl/02_Cover_%s_PRINT.stl" % pk: rd(os.path.join(PS, sub, "02_Cover_%s.stl" % pk)),
            "print_stl/03_MainGear_AP1.stl": rd(os.path.join(PS, "03_MainGear.stl")), "print_stl/04_Handle_AP1.stl": rd(os.path.join(PS, "04_Handle.stl")),
            "print_stl/05_Yoke_AP1.stl": rd(os.path.join(PS, "05_Yoke.stl")),
            "print_stl/10_MainRetainer_AP1.stl": rd(os.path.join(PS, "10_MainRetainer.stl")),
            "print_stl/11_HandleRetainer_AP1.stl": rd(os.path.join(PS, "11_Dial.stl")),
            "print_stl/23_RearGuideRail.stl": rd(os.path.join(PS, "23_RearGuideRail.stl"))}
    entries = []
    for i in zin.infolist():
        n = i.filename
        if DROP.match(n):
            continue
        if n == "README_KO.md":
            entries.append(("history/v47/README_KO.md", zin.read(n))); entries.append((n, readme)); continue
        if n.startswith("coupons/"):                 # v41 fit coupons: history, the E2 coupons are in E_test_coupons/
            entries.append(("history/v41_coupons/" + n[len("coupons/"):], zin.read(n))); continue
        entries.append((n, repl.pop(n, zin.read(n))))
    assert not repl, repl
    entries.append(("print_stl/24_SyncAxle.stl", rd(os.path.join(PS, "24_SyncAxle.stl"))))
    TC = os.path.join(PS, "Test_Coupons")
    for f in sorted(os.listdir(TC)):
        entries.append(("E_test_coupons/" + f, rd(os.path.join(TC, f))))
    src3, dst3, faces = CADF[tag]
    b3 = rd(os.path.join(W, "pfc_out", src3))
    entries.append((dst3, b3))
    stepd = os.path.join(EDIR, "CAD", "STEP")
    for f in sorted(os.listdir(stepd)):
        if pk == "AP1" and "_MW4" in f or pk == "MW4" and "_AP1" in f:
            continue
        entries.append(("E_native_parts/" + f, rd(os.path.join(stepd, f))))
    entries += sorted(checks.items()) + sorted(sources.items()) + sorted(images.items())
    desc = {"file": "cad/" + dst3, "filename": dst3, "bytes": len(b3), "sha256": sha(b3), "parts": 11,
            "hardware": "6x M3x5 DIN912 only (cover 4, dial 1, rail 23 1), threaded into printed pilots; no bearing, no nuts", "revision": "PF2", "fixedSample": True,
            "faces": faces, "assemblyRevision": "PF2-E", "combStyle": tag, "rhinoArchiveVersion": 7}
    entries.append(("3dm_checks.json", json.dumps({tag: desc}, indent=2).encode()))
    names = [n for n, _ in entries]
    assert len(names) == len(set(names)), [n for n in names if names.count(n) > 1]
    nstl = len([n for n in names if re.match(r"^print_stl/\d{2}_.*\.stl$", n) and not re.match(r"^print_stl/(02|15|16)_", n)])
    assert nstl == 8, nstl
    entries.append(("SHA256.json", json.dumps({n: sha(b) for n, b in entries}, indent=2).encode()))
    zp = os.path.join(D, "downloads", zname)
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for n, b in entries:
            z.writestr(n, b)
    print(zname, len(entries), "MB %.2f" % (os.path.getsize(zp) / 1e6), flush=True)
    json.dump(desc, open(os.path.join(D, "cad", "pf2-surface.json" if tag == "current" else "pf2-surface-mw4.json"), "w"), indent=2)

# print plates (3MF, 220 mm beds) as their own download: inside the packages they would push the artifact copy over 16 MB
PL = os.path.join(EDIR, "Print_Plates")
with zipfile.ZipFile(os.path.join(D, "downloads", "Meloprint_PF2_E2_Print_Plates.zip"), "w", zipfile.ZIP_DEFLATED) as z:
    for f in sorted(os.listdir(PL)):
        z.write(os.path.join(PL, f), f)
print("plates zip MB %.2f" % (os.path.getsize(os.path.join(D, "downloads", "Meloprint_PF2_E2_Print_Plates.zip")) / 1e6), flush=True)


# ---------------------------------------------------------------- texts and viewer motion
def esc(t):
    return "".join(c if ord(c) < 128 else ("\\x%02X" % ord(c) if ord(c) < 256 else "\\u%04X" % ord(c)) for c in t)


def patch(rel, reps):
    p = os.path.join(D, rel)
    s = open(p, encoding="utf-8").read()
    for old, new, n in reps:
        c = s.count(old)
        assert c == n, (rel, old[:80], c, n)
        s = s.replace(old, new)
    open(p, "w", encoding="utf-8", newline="").write(s)
    print("patched", rel, len(reps))


s = open(os.path.join(D, "app.js"), encoding="utf-8").read()
lb_reps = []
for style, info in ((k.split("_PF2_")[1].replace("_PRINT.stl", ""), v) for k, v in covers.items() if k.startswith("02_Cover")):
    m = re.search(r'%s:\{label:"[^"]*",file:"models/02_Cover_PF2_%s_PRINT\.stl"[^}]*?volume:([\d.]+),faces:(\d+)' % (style, style), s)
    assert m, style
    old = "volume:%s,faces:%s" % (m.group(1), m.group(2))
    lb_reps.append((m.group(0), m.group(0).replace(old, "volume:%s,faces:%d" % (info["after"], info["faces"])), 1))
patch("app.js", lb_reps + [
    ('{key:"rearRail",name:"23_RearGuideRail",file:"assets/pf2/23_RearGuideRail.stl",motion:"fixed"},',
     '{key:"rearRail",name:"23_RearGuideRail",file:"assets/pf2/23_RearGuideRail.stl",motion:"fixed"},{key:"axle",name:"24_SyncAxle",file:"assets/pf2/24_SyncAxle.stl",motion:"axle"},', 1),
    ("{yoke:15700563,cover:7702163,", "{axle:2056144,yoke:15700563,cover:7702163,", 1),
    ('(g==="handle"||g==="handleRetainer")&&(e.translate(-LM.cx,-LM.handleY,0),N.position.set(LM.cx,LM.handleY,0)),',
     '(g==="handle"||g==="handleRetainer")&&(e.translate(-LM.cx,-LM.handleY,0),N.position.set(LM.cx,LM.handleY,0)),g==="axle"&&(e.translate(0,0,-13.3),N.position.set(0,0,13.3)),', 1),
    ("GE&&(GE.position.x=A.x),", "GE&&(GE.position.x=A.x),VU.axle&&(VU.axle.position.x=A.x,VU.axle.rotation.y=A.x/4),", 1),
    ('c.startsWith("coupons/")&&(E[c]=g)', 'c.startsWith("E_test_coupons/")&&(E["coupons/"+c.slice(15)]=g)', 1),
    (esc("PF2 전체 11부품 + 608 베어링 + M3 나사·너트 5세트"), esc("PF2 E 전체 11부품(24 동기축 포함, 롤러는 메인기어와 한 몸) + M3×5 나사 6개 (베어링·너트 없음)"), 1),
    ("mm_11_Parts_M3.zip", "mm_12_Parts_M3x5.zip", 1),
    (esc("전체 11부품 저장 완료"), esc("전체 11부품 저장 완료"), 1),
    (esc("현재 11부품 3DM 생성 중"), esc("현재 11부품 3DM 생성 중"), 1),
        (esc("출력 부품 11개 + 608 베어링·M3 나사·너트 서피스 솔리드"), esc("출력 부품 11개 + M3×5 나사 서피스 솔리드"), 2),
    ('"v47 ' + esc("기본"), '"E ' + esc("기본"), 1),
    ('"v47 MW4 ', '"E MW4 ', 1),
])
_pp = open(os.path.join(D, "pf2-parts.js"), encoding="utf-8").read()
open(os.path.join(D, "pf2-parts.js"), "w", encoding="utf-8").write(_pp.replace(
    '{"key": "rearRail", "name": "23_RearGuideRail", "file": "assets/pf2/23_RearGuideRail.stl", "motion": "fixed"}',
    '{"key": "rearRail", "name": "23_RearGuideRail", "file": "assets/pf2/23_RearGuideRail.stl", "motion": "fixed"}, '
    '{"key": "axle", "name": "24_SyncAxle", "file": "assets/pf2/24_SyncAxle.stl", "motion": "axle"}'))
assert "24_SyncAxle" in open(os.path.join(D, "pf2-parts.js"), encoding="utf-8").read()
# no roller part: the crank pin is part of the main gear
_pp = open(os.path.join(D, "pf2-parts.js"), encoding="utf-8").read()
_r = '{"key": "roller", "name": "06_CrankRoller_AP1", "file": "assets/pf2/06_CrankRoller_AP1.stl", "motion": "roller"}, '
assert _pp.count(_r) == 1
open(os.path.join(D, "pf2-parts.js"), "w", encoding="utf-8").write(_pp.replace(_r, ""))
patch("app.js", [('{key:"roller",name:"06_CrankRoller_AP1",file:"assets/pf2/06_CrankRoller_AP1.stl",motion:"roller"},', "", 1)])
# 10-19/20 comb fit, generated from e_layout (same numbers as the CAD combs, e_parts.comb_e). No side fingers, no hook:
# the rails along the tines (with the v47 latch tab) are gone and the slot is closed, so the side is one solid block
# from F (59.584) to the shoulder. Rows of small half-round
# bumps (r 0.5) on the side rails press into the channel walls, no hook; the lower comb also gets a thin root band that
# presses the base crush rib at y 63.6. Pluck depth: default 0.50, max 0.55 (E yoke front face at y 28.0).
import json as _json
import e_layout as _L
def _comb_js():
    d = {}
    for row, up in (("lower", False), ("upper", True)):
        e = {}
        for key, sgn, face, wall in (("p", 1, _L.COMB_FACE[1], _L.CHANNEL_WALL[up][1]), ("n", -1, _L.COMB_FACE[0], _L.CHANNEL_WALL[up][0])):
            e[key] = [[y, round(sgn * (wall - face) + i_, 4)] for y, i_ in _L.COMB_BUMPS[up]]
        if not up:
            e["b"] = [[y, w] for pr in _L.LOWER_BANDS for y, w in pr]
            e["bn"] = [[y, round(w + (_L.PRESS_LOWER_NEG_EXTRA if 0 < k < len(pr) - 1 else 0.0), 4)]
                       for pr in _L.LOWER_BANDS for k, (y, w) in enumerate(pr)]
        d[row] = e
    return d
MBB = ('const mpD=' + _json.dumps(_comb_js(), separators=(",", ":")) + ';'
       'function mpB(f,s,w){let D=mpD[w],o=[],r=' + repr(_L.COMB_BUMP_R) + ';for(let[y,p]of(s>0?D.p:D.n)){let cx=f+s*(p-r),a=Math.acos((r-p)/r);'
       'for(let k=0;k<=10;k++){let t=-a+2*a*k/10;o.push([cx+s*r*Math.cos(t),y+r*Math.sin(t)])}}'
       'if(D.b)for(let[y,q]of(s>0?D.b:D.bn))o.push([f+s*q,y]);return s>0?o:o.reverse()}')
patch("app.js", [
    ("function PI(B,A){", MBB + "function PI(B,A){", 1),
    ("Q=[[E-I,e],[E-g,e],[E-g,N],[E-c,N],[E-c,F]];", "Q=[[E-I,F],[E-c,F]];", 1),
    ("let Y=[[E+c,F],[E+c,N],[E+g,N],[E+g,e],[E+I,e],[E+I+.75,51],[E+I+.75,52.2],[E+I,52.2],[E+I,oA.shoulderY]],i=[[E-I,oA.shoulderY],[E-I,52.2],[E-I-.75,52.2],[E-I-.75,51],[E-I,e]];",
     "let Y=[[E+c,F],[E+I,F],...mpB(E+I,1,A),[E+I,oA.shoulderY]],i=[[E-I,oA.shoulderY],...mpB(E-I,-1,A),[E-I,F]];", 1),
    ("let e=Number(A.pluckDepth??.35);if(!Number.isFinite(e)||e<.3||e>2)", "let e=Number(A.pluckDepth??.5);if(!Number.isFinite(e)||e<.3||e>.55)", 1),
    ("let U=Number(M.options?.pluckDepth??.35);", "let U=Number(M.options?.pluckDepth??.5);", 1),
])
_ap = open(os.path.join(D, "app.js"), encoding="utf-8").read()
_i = _ap.index("e>.55)throw Error(\"")
_j = _ap.index("\")", _i + 18)
patch("app.js", [(_ap[_i:_j + 2], 'e>.55)throw Error("\\uBB3C\\uB9BC \\uAE4A\\uC774\\uB294 0.30~0.55mm \\uBC94\\uC704\\uB85C \\uC785\\uB825\\uD558\\uC138\\uC694.")', 1)])
patch("index.html", [
    ('<output id="pluckDepthValue" for="pluckDepth">0.35 mm</output>', '<output id="pluckDepthValue" for="pluckDepth">0.50 mm</output>', 1),
    ('<input id="pluckDepth" type="range" min="0.30" max="2.00" step="0.01" value="0.35"', '<input id="pluckDepth" type="range" min="0.30" max="0.55" step="0.01" value="0.50"', 1),
    ('<button type="button" class="quiet" data-depth="0.35">기본 0.35</button><button type="button" class="quiet" data-depth="1.00">중간 1.00</button>'
     '<button type="button" class="quiet" data-depth="2.00">깊게 2.00</button>',
     '<button type="button" class="quiet" data-depth="0.35">얕게 0.35</button><button type="button" class="quiet" data-depth="0.50">기본 0.50</button>'
     '<button type="button" class="quiet" data-depth="0.55">깊게 0.55</button>', 1),
    ('<p class="hint" id="pluckDepthHint">0.30~2.00 mm · 0.01 mm 단위.', '<p class="hint" id="pluckDepthHint">0.30~0.55 mm · 0.01 mm 단위. E는 요크 앞면(y 28.0)이 빗살 끝 앞에 있어 0.55까지만 됩니다(실제 출력 후 기본값을 0.35에서 0.50으로 올림).', 1),
    ('0.35mm는 비교 출력용 시작값이며 참고 사진에서 측정한 치수가 아닙니다.', '빗에 날개(옆 레일)와 걸쇠가 없고, 머리 아래 옆면이 홈 벽(위 빗은 볼록 돌기, 아래 빗은 베이스 리브)에 눌려 꽉 끼워집니다. 세게 밀어 넣으세요.', 1),
])
E_HINT = ('<p class="hint"><strong>E · 동기축으로 화살표가 틀어지지 않습니다.</strong> 화살표(요크) 양 끝을 한 축에 붙은 피니언 2개가 '
          '앞 레일과 23번 레일의 랙에 물려 같이 움직입니다. 좌우로 움직이는 내내 비틀림은 최대 ±0.24°(v47 ±1.54°), 빗살 물림 깊이는 '
          '0.40~0.60mm로 일정합니다. 비트는 힘을 88.6mm 떨어진 두 기어가 받으므로 서랍처럼 걸리지 않습니다. 메인기어 아래 받침 링으로 '
          '축 기울기를 2.15°에서 0.41°로 줄였습니다. 사서 쓰는 부품은 M3×5 나사 6개(상판 4·다이얼 1·레일 1)뿐이고, 나사는 출력물 구멍에 직접 박힙니다. 608 베어링 대신 베이스의 출력 축 기둥에서 손잡이 기어가 돕니다. 손잡이·메인 기어는 조용한 25° 헬리컬입니다. '
          '화살표 대신 빗살을 튕기는 피크가 윗면까지 올라온 날개로 상판 창에서 바로 보이고, 창과 빗 사이 상판 띠를 없애 튕기는 순간이 보입니다. 요크는 뒤집어 출력해 롤러 홈과 축 받침이 수직 벽으로 정확하게 나옵니다. '
          '크랭크 핀은 메인기어와 한 몸인 굵은 Ø6.9 핀이라 빠지거나 흔들리지 않습니다(따로 끼우는 롤러 없음). 서포트는 03 메인기어 바깥 링 아래만 필요합니다. 바뀐 부품: 01 베이스, 02 상판(상판 7종 모두), '
          '03 메인기어(크랭크 핀 일체), 04 손잡이 기어, 05 요크(튕김 날개), 11 다이얼, 23 레일, 새 24 동기축. 06 롤러는 없어졌습니다. '
          '<strong>10-19 빗:</strong> 실제 출력 후 빗이 헐겁고 소리가 작아서, 이미 뽑은 케이스는 그대로 두고 15·16 빗만 고쳤습니다. '
          '빗 양옆의 날개(옆 레일)와 걸쇠를 없애고 머리 아래 옆면을 통째로 채워, 후크 없이 옆면으로만 꽉 낍니다. 위 빗은 옆면의 작은 반원 돌기 4개(볼록볼록)가 상판 벽을 0.20 누르고, 아래 빗은 베이스 리브가 옆면을 0.25 누릅니다. 세게 밀어 넣어야 들어갑니다. '
          '빗 턱을 0.15 깎아 피크 쪽으로 옮겨 물림 깊이가 0.35에서 0.50으로 깊어졌습니다(음은 그대로).</p>')
OLD_ASM = ('<p class="hint"><strong>v47 조립 순서:</strong> 손잡이 기어 아래 통로로 M3 너트를 밀어 넣고 → 608 베어링을 기어 아래에 눌러 넣고 → '
           '04 기어를 베이스 짧은 기둥에 → 23 레일 → 03 메인기어·10 클립 → 06 롤러 → 05 화살표 → 화살표를 가운데 두고 02 상판, 바닥 너트 4개 + M3×20 4개 → '
           '<strong>11 다이얼을 육각에 끼우고 M3×8 둥근머리 볼트로 조임</strong> → 화살표를 끝으로 옮기고 15/16 빗. 빗을 뺄 때는 나사 4개를 풀고 상판을 엽니다. '
           '23 레일은 뒤집힌 방향 그대로 서포트 없이 출력합니다. 03 메인기어 외곽 링 아래는 서포트가 필요합니다.</p>')
NEW_ASM = ('<p class="hint"><strong>E 조립 순서:</strong> 축 기둥에 그리스를 조금 바르고 04 기어를 베이스 축 기둥에 끼움 → '
           '03 메인기어·10 클립 → 23 레일 핀 2개를 베이스 구멍에 꽂은 뒤, 베이스를 옆으로 세워 바닥에서 M3×5으로 고정(나사가 레일에 직접 박힘) → '
           '크랭크를 약 45°로 돌리고 크랭크 핀에 그리스를 조금 바름 → <strong>24 동기축을 두 랙 위에 올려 크랭크 핀 바로 위로 굴림</strong> → 05 요크를 위에서 내려 축 위에 얹음 → '
           '요크를 가운데 두고 02 상판, M3×5 4개(베이스 모서리 기둥에 직접 박힘) → '
           '11 다이얼을 육각에 끼우고 M3×5로 조임 → 요크를 끝으로 옮기고 15 아래 빗, 16 위 빗 순서로 뒤에서 끝까지 세게 밀어 넣음(홈에 꽉 끼는 압입). '
           '빗을 뺄 때는 나사 4개를 풀고 상판을 엽니다. 05 요크는 뒤집어서(윗면이 바닥), 23 레일은 빗 반대쪽 긴 면을 바닥에, '
           '24 동기축은 뒤 링을 바닥에 세워(브림 8~10mm) 출력합니다. 서포트는 03 메인기어 바깥 링 아래만 필요합니다.</p>')
patch("index.html", [
    ("<strong>PF2 32 Stable · v47</strong>", "<strong>PF2 32 Stable · E</strong>", 1),
    ("<strong>v47 · 608 베어링.</strong>", "<strong>v47 · 608 베어링 (이전 기록: E2에서는 출력 축 기둥으로 바뀌어 베어링을 쓰지 않습니다).</strong>", 1),
    ('<p class="eyebrow">PF2 v47 · 11 PRINTED PARTS + 608 BEARING + M3</p>', '<p class="eyebrow">PF2 E · 11 PRINTED PARTS · SYNC AXLE + HELICAL · ONLY 6 × M3×5 BOUGHT</p>', 1),
    ("<h2>전체 모델링 다운로드</h2>", "<h2>전체 모델링 다운로드</h2>" + E_HINT, 1),
    ("선택 상판·현재 멜로디 ZIP · 11부품 + M3", "선택 상판·현재 멜로디 ZIP · 11부품 + M3×5", 1),
        ("v47 기본 상판 고정 샘플 · 서피스 3DM (Rhino 7)", "E 기본 상판 고정 샘플 · 서피스 3DM (Rhino 7)", 1),
    ("출력 부품 11개의 닫힌 서피스 솔리드와 608 베어링·M3 나사·너트(별도 레이어)가 들어 있습니다(Rhino 7 형식, 출력 부품 면 수 일반 2,573 / MW4 2,214).",
     "출력 부품 11개의 닫힌 서피스 솔리드와 M3×5 나사(별도 레이어)가 들어 있습니다(Rhino 7 형식, 출력 부품 면 수 일반 3,251 / MW4 2,884).", 1),
    ("PF2는 상판의 중앙 가이드와 화살표 홈으로 정렬하므로 상판을 닫고 사용합니다.",
     "E는 동기축과 두 랙이 화살표를 정렬하고, 상판이 화살표가 들리지 않게 위를 막으므로 상판을 닫고 사용합니다.", 1),
    ("v47 현재형 고정 샘플 전체 ZIP · STEP·3DM·설명서", "E 현재형 고정 샘플 전체 ZIP · STEP·3DM·설명서", 1),
    ("v47 MW4 33음 고정 샘플 전체 ZIP · STEP·3DM", "E MW4 33음 고정 샘플 전체 ZIP · STEP·3DM", 1),
    ("E MW4 33음 고정 샘플 전체 ZIP · STEP·3DM</a>",
     'E MW4 33음 고정 샘플 전체 ZIP · STEP·3DM</a> <a class="outline" href="downloads/Meloprint_PF2_E2_Print_Plates.zip" download>'
     '출력 판 3MF · 220mm 판 4장 (AP1·MW4, 03 바깥 링 아래만 서포트)</a>', 1),
    (OLD_ASM, NEW_ASM, 1),
    ("외형 크기는 유지하고 출력 부품은 11개 + M3 나사 5세트입니다. 기존 3종도 v47 일반형 베이스·상판을 사용합니다.",
     "외형 크기는 유지하고 출력 부품은 11개 + M3×5 나사 6개입니다. 기존 3종도 E 일반형 베이스·상판을 사용합니다.", 1),
    ("PF2 11부품 + 608 베어링 + M3 나사 구조(v47)를 사용하며", "PF2 11부품 + M3×5 나사 6개 구조(E, 베어링·너트 없음)를 사용하며", 1),
    ("v46에서 롤러 클립을 없애 출력 부품은 11개입니다.", "v46에서 롤러 클립을 없애 11개, E에서 24번 동기축을 더하고 06 롤러를 메인기어에 합쳐 출력 부품은 11개입니다.", 1),
])
tot = sum(os.path.getsize(os.path.join(r, f)) for r, _, fs in os.walk(D) for f in fs)
big = sorted(((os.path.getsize(os.path.join(r, f)), os.path.relpath(os.path.join(r, f), D)) for r, _, fs in os.walk(D) for f in fs), reverse=True)[:6]
print("site_E files", sum(len(fs) for _, _, fs in os.walk(D)), "MB %.1f" % (tot / 1e6), [(round(a / 1e6, 2), b) for a, b in big])
