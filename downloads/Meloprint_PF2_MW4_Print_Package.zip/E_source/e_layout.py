# -*- coding: utf-8 -*-
# Concept E constants: v47 crank + yoke, yaw locked by a sync axle (two m0.8 pinions on racks at the front rail and
# rail 23, rolling rings on pitch-line strips), main gear tilt pad, M3x5 hardware. Yoke coordinates are "resting".
import math

YOKE_FILE_DZ = 0.248                 # stored yoke B-rep = resting + 0.248 (same convention as v47 / D)

# sync axle and pinions
M = 0.8
Z = 10
X_SHIFT = 0.42
PA = 20.0
RP = M * Z / 2.0                     # 4.0 pitch radius = rolling ring radius
RA = RP + M * (1.0 + X_SHIFT)        # 5.136
RF = RP - M * (1.25 - X_SHIFT)       # 3.336
THIN_PINION = 0.08                   # tooth thickness reduction at the pitch circle (total, both flanks)
THIN_RACK = 0.08                     # -> circumferential backlash 0.16
AXLE_R = 3.0
AXLE_Z = 13.3                        # axle centre (resting)
STRIP_Z = AXLE_Z - RP                # 9.3 rolling strip top = working pitch line
RACK_REF = STRIP_Z - X_SHIFT * M     # 8.964 rack reference line
RACK_TIP = RACK_REF + M              # 9.764
RACK_ROOT = RACK_REF - 1.25 * M      # 7.964
PITCH = math.pi * M                  # 2.5133
RACK_X = 41.9                        # teeth centres within |x| <= RACK_X

# axle stations along y (rear -> front)
R_RING = (-70.7, -69.55)
R_PIN = (-69.15, -67.25)
F_RING = (17.85, 19.0)
F_PIN = (19.4, 21.3)

# front rail (base): strip / groove / solid bands
FR_Y0, FR_Y1 = 17.65, 23.6
FR_GROOVE = (19.15, 21.55)
FR_TEETH = (19.25, 21.45)
# rail 23
R23_Y0, R23_Y1 = -70.9, -64.6
R23_GROOVE = (-69.4, -67.0)
R23_TEETH = (-69.3, -67.1)
R23_X = 43.2

# yoke
CRADLE_R = 3.1
CRADLE_Z = AXLE_Z - 0.1              # yoke rests on the axle top
CRADLE_OPEN = 3.05                   # half width of the downward opening
CEILING_Z = 17.4                     # cover underside (measured)
TOP_Z = 17.3                         # hold-down / roll stop, 0.1 under the cover ceiling
CHEEK_X = 5.45
FRONT_CRADLE = (5.0, 17.75)
REAR_CRADLE = (-67.15, -58.0)
LIP = (-71.65, -71.0)

# main gear tilt pad (annulus under the gear, 0.1 below its underside z -1.8)
MAIN_PAD = (12.0, 14.0, -1.9)

R23_PIN_Y = -69.325                  # v47 pin / base hole position
# rail 23 screw (M3x5 from the base underside into a nut in the rail)
R23_SCREW = (31.0, -67.5)
R23_NUT_Z = (2.85, 5.35)                # M3x5 from the head seat 0.3 ends at 5.3: full 2.4 mm nut engagement
SCREW_HEAD_SEAT = 0.3

# front block (y 21.85: 0.3 ahead of the front pinion at its +0.25 groove play) and the 25 arrow
FRONT_BLOCK = (21.85, 28.0)          # 0.34 short of the comb tips (y 28.34)
ARROW_Z = (20.952, 22.952)           # arrow plate, 0.22 over the cover top
ARROW_PLATE = [(3.0, 9.0), (3.0, 18.0), (7.0, 18.0), (0.0, 27.0), (-7.0, 18.0), (-3.0, 18.0), (-3.0, 9.0)]
_xe = lambda y: 7.0 * (27.0 - y) / 9.0      # arrow head half width
ARROW_HEAD_STEM = [(-3.0, 21.95), (3.0, 21.95), (3.0, 22.757), (_xe(25.3) - 0.3, 25.3), (-(_xe(25.3) - 0.3), 25.3), (-3.0, 22.757)]
ARROW_PEG = [(-(_xe(22.95) - 0.75), 22.95), (_xe(22.95) - 0.75, 22.95), (_xe(24.6) - 0.75, 24.6), (-(_xe(24.6) - 0.75), 24.6)]
ARROW_PEG_Z = (11.4, 17.3)           # 5.9 deep, socket floor 1.1 thick
# rear lip back profile (y, z): hub r 7.0 between its cones z 8.75..15.5 (r 9.1 at 6.5, r 8.6 at 17.0)
LIP_BACK = [(-71.4, 16.45), (-71.65, 16.45), (-72.9, 15.2), (-72.9, 8.95), (-71.65, 7.7), (-71.4, 7.7)]
# crank pin on the roller (06), blind hole in the main gear (03)
CRANK_PIN = (0.0, -23.218 + 36.064)
GEAR_TOP = 5.5                       # main gear flat top (print bed when printed upside down)
PIN_HOLE_R = 2.2                     # 0.2 radial clearance on the pin (same as the v47 roller bore)
PIN_HOLE_Z = (2.1, 5.5)              # floor 0.5 over the ring underside z 1.6
ROLLER_R = 3.5
ROLLER_Z = (5.6, 9.9)                # 0.1 over the gear top; 0.4 under the axle (main gear up-play to the clip 0.2)
PIN_R = 2.0
PIN_Z = (2.25, 5.6)
# no arrow (E3): the pick rises as a fin to the top plane; the cover bar between the window and the comb opening is
# removed so the pick and the tine tips show from above
FRONT_END_Y = 28.0                   # cheeks, legs, floor and the fin top end 0.34 short of the comb tips (y 28.34)
COVER_BAR_CUT = (-39.6, 26.0, 39.6, 30.2)
# no bought parts except the 6 M3x5 screws: the 608 is replaced by a printed journal (base post in the handle gear's
# bore, thrust ring under the hub) and the M3 nuts by pilot holes the screws thread into
HANDLE_C = (0.0, -80.544)
POST_R = 4.5                         # base post (journal) D9.0
POST_TOP = 19.0                      # 0.4 under the gear's core (up-play 0.2)
GEAR_BORE_R = 4.7                    # 0.2 radial clearance, journal length z -1.8..19.0
THRUST_R = 7.0                       # thrust ring r 4.5..7.0 under the gear hub
THRUST_TOP = -1.85                   # gear hub bottom -1.8: 0.05 down-play
PILOT_R = 1.3                        # D2.6 pilot for M3 thread-forming in PLA
# crank pin integral with the main gear again (the separate pin-roller was too weak): solid D6.9 pin slides in the
# yoke slot (walls at +-3.65: 0.2 per side), 45 deg root flare; no part 06
CRANK_PIN_R = 3.45
CRANK_PIN_TOP = 9.9                  # 0.4 under the sync axle (main gear up-play to the clip 0.2)
# real-print fixes (2026-10-19): deeper pluck, comb press fit with side bumps, rail 23 located by upright base pins
PICK_EXTRA = 0.35                    # pick tip 0.35 closer to the comb: pluck depth 0.35 -> 0.70 with the standard comb
BUMP_YS = (53.2, 55.6, 58.0, 60.4, 62.8)   # half-round bumps on the comb channel walls (comb side rails x +-34.131)
BUMP_WALL_X, BUMP_R, BUMP_PROUD = 34.381, 0.6, 0.45   # gap 0.25 -> 0.20 squeeze per side
BUMP_Z_LOWER = (4.9, 7.7)            # base wall, lower comb
BUMP_Z_UPPER = (8.9, 11.5)           # cover wall, upper comb
PAD_SQUEEZE = 0.20                   # vertical pads 0.05 -> 0.20 (AP1 base + cover), MW4 cover press 0.25 -> 0.40
R23_KEY = (36.0, -67.75)             # base pins D3.0 (printed upright) into D3.3 holes in rail 23, mid-width of the rail
R23_KEY_R, R23_HOLE_R, R23_KEY_TOP = 1.5, 1.65, 4.4
# 2026-10-19 (2): the user keeps the printed E2 case ("it works") -> the case goes back to the printed geometry and the
# fixes move into the combs only: the comb sits 0.15 closer to the pick and grips the old walls with side bumps.
CASE_GRIP = False                    # wall bumps / stronger pads on base + cover (dropped: the case is already printed)
RAIL_KEY = False                     # base pins for rail 23 (dropped: needs a new base)
PICK_EXTRA = 0.0                     # yoke as printed
COMB_SHIFT = 0.15                    # comb shoulder trimmed 0.15: tines 28.336 -> 28.186, pluck depth 0.35 -> 0.50
COMB_FACE = (-34.069, 34.131)        # comb side-rail outer faces (comb is 0.031 off centre); walls +-34.381
OLD_RIB_X, OLD_RIB_R, OLD_RIB_YS, OLD_RIB_Z = 34.681, 0.6, (56.0, 63.6), (4.9, 7.7)   # v46 crush ribs in the printed base
DETENT_P, DETENT_DY = 0.25, 0.62     # lower comb: bumps 0.25 proud, seated 0.62 in front of each rib (snap past it)
UPPER_BUMP_YS, UPPER_BUMP_REACH, UPPER_BUMP_Z = (53.2, 58.0, 62.8), (-34.519, 34.581), (8.9, 11.5)   # cover walls -34.319 / +34.381: 0.20 squeeze each
# 2026-10-19 (3): the user wants no snap/hook, just a tight press fit in the channel. The side rails are cantilever
# fingers (free front end, root at the head y 63.6), so they are widened outward with an interference that tapers from the
# free end (flexes) to the root (must crush). Profile (y, widening of the +x face); the -x face gets the extra offset below.
PRESS_LOWER = ((53.0, 0.0), (54.5, 0.2796), (64.3, 0.0862), (64.8, 0.0))   # base ribs: 0.30 at y 56, 0.15 at y 63.6; walls ~0
PRESS_LOWER_NEG_EXTRA = 0.062        # -x face is 0.062 further from its rib/wall (comb 0.031 off centre)
PRESS_UPPER = ((53.0, 0.0), (54.5, 0.50), (64.3, 0.30), (64.8, 0.0))       # cover walls: 0.25 at the front -> 0.05 at the root
PRESS_UPPER_NEG_EXTRA = 0.0          # cover walls -34.319 / +34.381: both 0.25 from the comb faces
RAIL_Z = {False: (4.722, 7.922), True: (8.722, 11.922)}                      # side rail z range (lower / upper comb)
# 2026-10-19 (4): the user's photo: rows of small round bumps on the comb sides ("볼록볼록"), pressing it tight, no hook.
# Half-round bumps r 0.5, 1.1 apart, full rail height, interference measured against the channel wall (never > r proud,
# so the bump never undercuts). Lower comb: one front group (the base crush ribs at y 56 / 63.6 are kept clear when seated)
# plus a 0.10 root band that presses the rib at y 63.6 by 0.15. Upper comb: front / middle / root groups into the cover walls.
COMB_BUMP_R = 0.5
CHANNEL_WALL = {False: (-34.319, 34.381), True: (-34.319, 34.381)}          # base and cover walls (-x, +x), measured
COMB_BUMPS = {False: [(52.4, 0.15), (53.5, 0.15), (54.6, 0.15)],
              True: [(52.4, 0.22), (53.5, 0.22), (54.6, 0.22), (57.4, 0.16), (58.5, 0.16), (59.6, 0.16),
                     (62.0, 0.10), (63.1, 0.10), (64.2, 0.10)]}
ROOT_BAND_LOWER = ((62.2, 0.0), (62.7, 0.10), (64.5, 0.10), (64.8, 0.0))   # +x widening; -x adds PRESS_LOWER_NEG_EXTRA
