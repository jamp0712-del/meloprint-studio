# -*- coding: utf-8 -*-
# Rhino 7: Meloprint PF2 E assembly 3DMs (AP1 and MW4 combs), every part a NURBS B-rep from STEP.
import json, traceback
import Rhino
import Rhino.Geometry as G
import scriptcontext as sc
import rhinoscriptsyntax as rs
import System.Drawing as SD

W = r"C:\Users\Public\mbx_work"
SRC = W + r"\in\e_export"
OUT = W + r"\pfc_out"
LOG = open(W + r"\rh_build_e.log", "w")
def L(*a):
    LOG.write(" ".join(str(x) for x in a) + "\n"); LOG.flush()
REV = "PF2-E2: sync axle, helical gears, pick visible, all printed except 6 x M3x5 screws; combs refitted to the printed case"
COL = {"01": (200, 202, 206), "02": (236, 236, 230), "03": (225, 140, 30), "04": (220, 175, 40), "05": (215, 50, 45),
       "06": (230, 90, 160), "10": (150, 150, 150), "11": (50, 54, 60), "15": (150, 120, 205), "16": (210, 140, 185),
       "23": (40, 40, 40), "24": (30, 90, 200), "25": (215, 50, 45), "HW": (110, 110, 115)}
INFO = {"01": ("front rail: rolling strip + m0.8 rack + guide faces 0.10; rail-23 ledges; main gear tilt pad; D9 journal post + thrust ring for 04 (no bearing); D2.6 pilots for the M3x5 case screws (no nuts)", "as modelled"),
        "02": ("middle and rear ribs removed, relief over the rear pinion, bar between window and comb opening removed (pluck visible); M3x5 counterbores", "upside down"),
        "03": ("helical 60T (25 deg left hand); solid D6.9 crank pin integral (slides in the yoke slot), no separate roller", "as modelled, support under the outer ring only"),
        "04": ("helical 40T (25 deg right hand); runs on the base post in a D9.4 bore (no bearing); dial M3x5 threads into a D2.6 pilot (no nut)", "as modelled"),
        "05": ("hangs on the sync axle in two open cradles; full-height slot walls; the pick rises as a fin to the top (visible, no arrow); guide faces 0.10 at both rails", "upside down (top face on the bed)"),
        "06": ("roller r 3.5 with its own crank pin (turns in the gear hole); v47 flange removed", "upside down (roller top on the bed)"), "10": ("unchanged", "as modelled"), "11": ("M3 counterbore", "upside down"),
        "15": ("fits the printed E2 case: shoulder trimmed 0.15 (pluck 0.50); press fit, no hook: 3 small half-round bumps r0.5 per side 0.15 into the base walls + root band pressing the base rib 0.15", "as v47"),
        "16": ("fits the printed E2 case: shoulder trimmed 0.15; press fit, no hook: 9 small half-round bumps r0.5 per side (0.22 front, 0.16 middle, 0.10 root) into the cover walls", "upside down"),
        "23": ("new: rolling strip + m0.8 rack, keel over the handle gear, 2 pins + M3x5 from below into a D2.6 pilot (no nut)", "on its -y face"),
        "24": ("new: D6 sync axle, two 10T m0.8 pinions (x+0.42) + D8 rolling rings", "standing on the rear ring, brim"),
        "25": ("arrow (v47 plate) on two stems, tapered peg pressed into the yoke front block (2 crush ribs)", "face down")}


def import_step(path):
    doc = sc.doc
    before = set(o.Id for o in doc.Objects)
    for attempt in range(3):                      # the first import after start-up can fail while the STEP plug-in loads
        rs.Command('_-Import "' + path + '" _Enter', False)    # backslashes only: forward slashes give 'Directory "" does not exist'
        if any(o.Id not in before for o in doc.Objects):
            break
        Rhino.RhinoApp.Wait()
    new = [o for o in doc.Objects if o.Id not in before]
    for o in new:
        if isinstance(o, Rhino.DocObjects.InstanceObject):
            rs.ExplodeBlockInstance(o.Id, True)
    new = [o for o in doc.Objects if o.Id not in before and not isinstance(o, Rhino.DocObjects.InstanceObject)]
    out = [o.Geometry.DuplicateBrep() for o in new if isinstance(o.Geometry, G.Brep)]
    for o in new:
        doc.Objects.Delete(o.Id, True)
    return out


def vol(b):
    mp = G.VolumeMassProperties.Compute(b)
    if mp is None:
        m = G.Mesh()
        for x in G.Mesh.CreateFromBrep(b, G.MeshingParameters.QualityRenderMesh):
            m.Append(x)
        mp = G.VolumeMassProperties.Compute(m)
    return mp.Volume if mp else float("nan")


def naked(b):
    return sum(1 for e in b.Edges if e.Valence == G.EdgeAdjacency.Naked)


HC = (0.0, -80.544)


def hexprism(af, z0, z1, rot=30.0):
    import math
    rr = af / 2.0 / math.cos(math.radians(30))
    pts = [G.Point3d(HC[0] + rr * math.cos(math.radians(rot + 60 * k)), HC[1] + rr * math.sin(math.radians(rot + 60 * k)), z0) for k in range(7)]
    b = G.Surface.CreateExtrusion(G.PolylineCurve(pts), G.Vector3d(0, 0, z1 - z0)).ToBrep().CapPlanarHoles(0.001)
    if b.SolidOrientation == G.BrepSolidOrientation.Inward:
        b.Flip()
    return b


def gear_rhino():
    """v47 handle gear as built in Rhino, dial nut pocket raised (same as D)."""
    f0 = Rhino.FileIO.File3dm.Read(W + r"\pf2_out\Meloprint_PF2_v47_Assembly.3dm")
    g = [o.Geometry for o in f0.Objects if o.Attributes.Name == "04_Handle_AP1"][0].DuplicateBrep()
    for tool in (hexprism(5.75, 19.40, 21.50), hexprism(5.60, 21.45, 24.00)):
        r = G.Brep.CreateBooleanDifference(g, tool, 0.001)
        if not r:
            raise RuntimeError("gear boolean failed")
        g = sorted(r, key=lambda x: -vol(x))[0]
    return g


def inter(a, b):
    r = G.Brep.CreateBooleanIntersection(a, b, 0.001)
    return "none" if not r else "%.4f" % sum(vol(x) for x in r)


try:
    exp = json.load(open(SRC + r"\export_E.json"))["stl"]
    common = ["03_MainGear", "04_Handle", "05_Yoke", "10_MainRetainer", "11_Dial", "23_RearGuideRail", "24_SyncAxle"]
    shared = {}
    for n in common:
        b = import_step(SRC + "\\" + n + ".step")[0]
        if not b.IsSolid:                         # OCC STEP: re-join naked edges within tolerance
            jb = G.Brep.JoinBreps([b], 0.01)
            if jb and jb[0].IsSolid:
                b = jb[0]
            else:
                b.Repair(0.01)
        shared[n] = b
        L("%-18s solid=%s valid=%s naked=%d faces=%d vol=%.2f (STL %.2f)" % (n, b.IsSolid, b.IsValid, naked(b), b.Faces.Count, vol(b), exp["Print_STL/%s.stl" % n]["volume"]))
    centers = json.load(open(SRC + r"\hw_centers.json"))
    hw = []
    for hb in import_step(SRC + r"\Hardware_M3x5.step"):
        bb = hb.GetBoundingBox(True)
        q = [bb.Center.X, bb.Center.Y, bb.Center.Z, bb.Max.X - bb.Min.X, bb.Max.Y - bb.Min.Y, bb.Max.Z - bb.Min.Z]
        hw.append((min(centers, key=lambda k: sum((centers[k][i] - q[i]) ** 2 for i in range(6))), hb))
    for var in ("AP1", "MW4"):
        objs = list(shared.items())
        for n in ("01_Base", "02_Cover", "15_CombLower", "16_CombUpper"):
            b = import_step(SRC + "\\%s_%s.step" % (n, var))[0]
            objs.append(("%s_%s" % (n, var), b))
            sub = ("Print_STL/%s_%s.stl" if var == "AP1" else "Print_STL/MW4/%s_%s.stl") % (n, var)
            L("%s %-16s solid=%s valid=%s naked=%d vol=%.2f (STL %.2f)" % (var, n, b.IsSolid, b.IsValid, naked(b), vol(b), exp[sub]["volume"]))
        if var == "AP1":
            base = [b for n, b in objs if n.startswith("01_")][0]
            cover = [b for n, b in objs if n.startswith("02_")][0]
            yoke, axle, rail = shared["05_Yoke"], shared["24_SyncAxle"], shared["23_RearGuideRail"]
            L("rhino yoke x base: %s   yoke x rail23: %s   yoke x cover: %s" % (inter(yoke, base), inter(yoke, rail), inter(yoke, cover)))
            L("rhino axle x base (rings tangent to the strip): %s   axle x rail23: %s" % (inter(axle, base), inter(axle, rail)))
            a2 = axle.DuplicateBrep(); a2.Translate(G.Vector3d(0.3, 0, 0))
            L("rhino positive control: axle slid 0.3 in x without turning vs base racks: %s, vs rail 23: %s" % (inter(a2, base), inter(a2, rail)))
            y2 = yoke.DuplicateBrep(); y2.Translate(G.Vector3d(0, 0.25, 0))
            L("rhino positive control: yoke +0.25 y vs base: %s" % inter(y2, base))
        f = Rhino.FileIO.File3dm()
        f.Settings.ModelUnitSystem = Rhino.UnitSystem.Millimeters
        f.Settings.ModelAbsoluteTolerance = 0.001
        for name, c in (("E_Case", (190, 192, 196)), ("E_Drive", (230, 140, 30)), ("E_SyncAxle_Racks", (30, 90, 200)),
                        ("E_Combs", (150, 110, 200)), ("E_Hardware_M3x5", (90, 90, 95))):
            ly = Rhino.DocObjects.Layer(); ly.Name = name; ly.Color = SD.Color.FromArgb(*c)
            f.AllLayers.Add(ly)
        idx = dict((l.Name, l.Index) for l in f.AllLayers)
        for n, b in objs:
            k = n[:2]
            a = Rhino.DocObjects.ObjectAttributes(); a.Name = n
            lay = "E_Combs" if k in ("15", "16") else ("E_Case" if k in ("01", "02", "11") else ("E_SyncAxle_Racks" if k in ("23", "24") else "E_Drive"))
            a.LayerIndex = idx[lay]
            a.ColorSource = Rhino.DocObjects.ObjectColorSource.ColorFromObject; a.ObjectColor = SD.Color.FromArgb(*COL[k])
            a.SetUserString("Revision", REV); a.SetUserString("Change", INFO[k][0]); a.SetUserString("PrintOrientation", INFO[k][1])
            a.SetUserString("Printable", "Yes")
            f.Objects.AddBrep(b, a)
        for hn, hb in hw:
            a = Rhino.DocObjects.ObjectAttributes(); a.Name = hn; a.LayerIndex = idx["E_Hardware_M3x5"]
            a.ColorSource = Rhino.DocObjects.ObjectColorSource.ColorFromObject; a.ObjectColor = SD.Color.FromArgb(*COL["HW"])
            a.SetUserString("Printable", "No")
            f.Objects.AddBrep(hb, a)
        f.Strings.SetString("MeloprintRevision", "PF2-E")
        dst = OUT + r"\Meloprint_PF2_E_%s_Assembly.3dm" % var
        f.Write(dst, 7)
        back = Rhino.FileIO.File3dm.Read(dst)
        bad = [o.Attributes.Name for o in back.Objects if not (isinstance(o.Geometry, G.Brep) and o.Geometry.IsSolid)]
        L("%s saved archive=%d objects=%d not-solid=%s" % (var, Rhino.FileIO.File3dm.ReadArchiveVersion(dst), len(back.Objects), bad))
except Exception:
    L("ERR", traceback.format_exc())
L("##DONE##")
LOG.close()
