# -*- coding: utf-8 -*-
# E2 fit test coupons: chunks cut from the real parts (same geometry and print orientation), so the critical fits can
# be checked in about 30 minutes of printing before the full set: arrow socket, crank pin hole, rack + pinion, cradle.
import sys, os, json
sys.path.insert(0, r"C:\Users\Public\mbx_work")
import numpy as np, manifold3d as m3
from ap1_view import load_cache
from ap1_tool import moved
from mf_tool import to_manifold
_argv = sys.argv
sys.argv = [sys.argv[0], r"C:\Users\Public\mbx_work\pf2_out"]
from ap1_export import write_stl
sys.argv = _argv
import e_layout as L

SESSION = r"C:\Users\호준\AppData\Roaming\Claude\scratch-workspaces\2484390f-f0f2-4f82-bbfe-32b4ca171b18\68694043-e7ab-4f63-8fec-837dd5148705\scratch-2026-10-12-dfb134"
OUT = os.path.join(SESSION, "Meloprint_PF2_E", "Print_STL", "Test_Coupons")
os.makedirs(OUT, exist_ok=True)
FLIP_X = np.diag([1.0, -1.0, -1.0])
R_X90 = np.array([[1, 0, 0], [0, 0, -1], [0, 1, 0]], float)
S = load_cache(r"C:\Users\Public\mbx_work\in\e_brep_ap1")
Y = to_manifold(moved(S["05_Yoke"], 0, 0, -L.YOKE_FILE_DZ), 0.003)
G = to_manifold(S["03_MainGear"], 0.003)
RL = to_manifold(S["23_RearGuideRail"], 0.003)
AX = to_manifold(S["24_SyncAxle"], 0.002)


def box(x0, y0, z0, x1, y1, z1):
    return m3.Manifold.cube([x1 - x0, y1 - y0, z1 - z0]).translate([x0, y0, z0])


def save(name, m, R, note):
    mm = m.to_mesh()
    V = np.array(mm.vert_properties)[:, :3].astype(float) @ R.T
    V -= np.array([(V[:, 0].min() + V[:, 0].max()) / 2, (V[:, 1].min() + V[:, 1].max()) / 2, V[:, 2].min()])
    F = np.array(mm.tri_verts).astype(np.int64)
    write_stl(os.path.join(OUT, name + ".stl"), V, F, name)
    rep[name] = {"volume_mm3": round(m.volume(), 1), "size_mm": [round(float(v), 1) for v in V.max(axis=0) - V.min(axis=0)],
                 "pieces": len(m.decompose()), "test": note}
    print(name, rep[name], flush=True)


rep = {}
px, py = L.CRANK_PIN
_c2 = sorted((G ^ m3.Manifold.cylinder(4.8, 6.0, 6.0, 64).translate([px, py, 1.3])).decompose(), key=lambda k: -k.volume())[0]
save("C2_PinHole", _c2, FLIP_X,
     "main gear chunk around the crank pin hole; the real 06 roller's pin must turn freely")
save("C3_RackSegment", RL ^ box(-12.0, -80.0, -5.0, 12.0, -60.0, 20.0), R_X90,
     "24 mm of rail 23 (rolling strip + m0.8 rack); roll C3b on it")
save("C3b_PinionStub", AX ^ box(-10.0, L.R_RING[0] - 0.5, 0.0, 10.0, -63.0, 25.0), R_X90,
     "rear ring + rear pinion + 4 mm of shaft from 24; must roll on C3 with the ring on the strip, and sit in C4")
save("C4_Cradle", Y ^ box(-7.5, L.REAR_CRADLE[0] - 0.2, 9.9, 7.5, L.REAR_CRADLE[1] + 0.2, 17.5), FLIP_X,
     "yoke rear cradle (downward-open, r 3.1 on the D6 shaft); the C3b shaft must drop in and turn")
import c_case as CC
BA = to_manifold(S["01_Base"], 0.003)
CV = to_manifold(S["02_Cover"], 0.003)
HA = to_manifold(S["04_Handle"], 0.003)
big = lambda m: sorted(m.decompose(), key=lambda k: -k.volume())[0]
cx, cy = CC.CORNERS[0]
save("C5a_ScrewBoss_Base", big(BA ^ m3.Manifold.cylinder(5.75, 6.0, 6.0, 64).translate([cx, cy, 9.0])), np.eye(3),
     "base corner column with the D2.6 pilot; drive an M3x5 through C5b into it: it must bite firmly and not strip")
save("C5b_ScrewBoss_Cover", big(CV ^ m3.Manifold.cylinder(6.2, 6.0, 6.0, 64).translate([cx, cy, 14.6])), FLIP_X,
     "cover corner with the counterbore and the D3.4 clearance hole")
hx, hy = L.HANDLE_C
save("C6a_JournalPost", big(BA ^ m3.Manifold.cylinder(24.0, 8.0, 8.0, 64).translate([hx, hy, -4.9])), np.eye(3),
     "base post (D9 journal) on a disc of floor with the thrust ring")
save("C6b_JournalHub", big(HA ^ m3.Manifold.cylinder(8.0, 10.0, 10.0, 64).translate([hx, hy, -1.9])), np.eye(3),
     "handle gear hub with its D9.4 bore; it must slide down the post and turn freely with no wobble you can feel")
json.dump(rep, open(os.path.join(OUT, "coupons.json"), "w", encoding="utf-8"), indent=1, ensure_ascii=False)
