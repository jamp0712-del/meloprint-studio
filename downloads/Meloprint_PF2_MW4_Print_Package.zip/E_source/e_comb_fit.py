# -*- coding: utf-8 -*-
# Comb fit in the printed E2 case: seated contacts (designed squeeze only), the whole insertion stroke (only the bumps
# and the v46 ribs/pads may touch), and pick clearance to the yoke front face. Writes in\e_comb_fit.json.
import sys, json
sys.path.insert(0, r"C:\Users\Public\mbx_work")
import numpy as np, manifold3d as m3
from ap1_view import load_cache
from ap1_tool import moved
from mf_tool import to_manifold
import e_layout as L


def box(x0, y0, z0, x1, y1, z1):
    return m3.Manifold.cube([x1 - x0, y1 - y0, z1 - z0]).translate([x0, y0, z0])


def comps(m, tol=1e-4):
    return [(round(q.volume(), 4), [round(float(v), 2) for v in q.bounding_box()]) for q in m.decompose() if q.volume() > tol]


R = {}
for var in ("ap1", "mw4"):
    E = load_cache(r"C:\Users\Public\mbx_work\in\e_brep_" + var)
    D = load_cache(r"C:\Users\Public\mbx_work\in\d_brep_" + var)
    case = to_manifold(E["01_Base"], 0.003) + to_manifold(E["02_Cover"], 0.003)
    Y = to_manifold(moved(E["05_Yoke"], 0, 0, 0), 0.003)
    r = {}
    for k in ("15_CombLower", "16_CombUpper"):
        new = to_manifold(E[k], 0.003)
        old = to_manifold(D[k], 0.003)
        seat = new ^ case
        # stroke: comb pulled back by d (it slides in along -y); the old comb's contacts are the v46 ribs/pads
        worst, extra = 0.0, []
        for d in list(np.arange(0.0, 3.0, 0.05)) + list(np.arange(3.0, 20.0, 0.25)):
            i_new = new.translate([0, d, 0]) ^ case
            i_old = old.translate([0, d - L.COMB_SHIFT, 0]) ^ case
            x = i_new - old.translate([0, d - L.COMB_SHIFT, 0])          # contacts made by the new material only
            for v, bb in comps(x):
                inside = min(abs(bb[0]), abs(bb[3])) > 33.9          # only at the side walls / ribs (the widened rails)
                if not inside:
                    extra.append((round(float(d), 2), v, bb))
            worst = max(worst, i_new.volume())
        # pick: tine tips vs the yoke front face (x +-7 at y 28.0) and pick depth over the guide play +-0.10
        tips = new ^ box(-45, 27.5, -5, 45, 29.0, 30)
        tip_y = tips.bounding_box()[1]
        # side squeeze along the rail: overlap depth in x at a few y stations (walls and ribs)
        sq = {}
        for yy in (54.5, 56.0, 58.0, 60.0, 62.0, 63.6, 64.3):
            for sd in (1, -1):
                q = seat ^ box(30 if sd > 0 else -40, yy - 0.05, -5, 40 if sd > 0 else -30, yy + 0.05, 30)
                if q.volume() > 1e-6:
                    bq = q.bounding_box(); sq["%s%.1f" % ("+" if sd > 0 else "-", yy)] = round(bq[3] - bq[0], 3)
        r_sq = sq
        # no hook: pulling the comb back out must never need MORE overlap than it has when seated
        pull = {str(d): round((new.translate([0, d, 0]) ^ case).volume(), 3) for d in (0.05, 0.1, 0.2, 0.3, 0.5, 0.8, 1.2, 2.0)}
        r_hook = max(pull.values()) <= seat.volume() + 0.02
        r[k] = {"no_hook": r_hook, "pull_out_overlap_mm3": pull, "side_overlap_x_mm": r_sq, "seated_contacts": comps(seat, 1e-3), "seated_volume": round(seat.volume(), 3),
                "stroke_max_volume": round(worst, 3), "stroke_unexpected": extra[:10], "tine_tip_y": round(tip_y, 3)}
    yb = Y ^ box(-20, 27.0, -5, 20, 28.05, 30)
    face = Y ^ box(-20, 27.9, -5, 20, 28.01, 30)
    pick_tip = Y.bounding_box()[4]
    tip = min(r[k]["tine_tip_y"] for k in r)
    r["pick"] = {"pick_tip_y": round(pick_tip, 3), "yoke_face_y": 28.0, "depth_nominal": round(pick_tip - tip, 3),
                 "depth_range": [round(pick_tip - tip - 0.10, 3), round(pick_tip - tip + 0.10, 3)],
                 "face_clearance_nominal": round(tip - 28.0, 3), "face_clearance_worst": round(tip - 28.0 - 0.10, 3)}
    R[var] = r
    print(var, json.dumps(r, indent=1), flush=True)
json.dump(R, open(r"C:\Users\Public\mbx_work\in\e_comb_fit.json", "w"), indent=1)
