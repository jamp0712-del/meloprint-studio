# -*- coding: utf-8 -*-
# Print layout sheet: every printed part in its print orientation (red = down-facing > 45 deg not on the bed, blue = bed),
# from the e_print_audit renders, with the orientation and the support verdict.
import sys, os, json
sys.path.insert(0, r"C:\Users\Public\mbx_work")
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt, matplotlib.image as mpimg
plt.rcParams["font.family"] = "Malgun Gothic"
SESSION = r"C:\Users\호준\AppData\Roaming\Claude\scratch-workspaces\2484390f-f0f2-4f82-bbfe-32b4ca171b18\68694043-e7ab-4f63-8fec-837dd5148705\scratch-2026-10-12-dfb134"
IMG = os.path.join(SESSION, "Meloprint_PF2_E", "images")
A = json.load(open(r"C:\Users\Public\mbx_work\in\e_print_audit.json"))
NOTE = {"01_Base": ("그대로", "서포트 없음 (너트 포켓·구멍 위는 짧은 브리지)"),
        "02_Cover": ("뒤집어서", "서포트 없음 (빗 앞 1.7mm 턱)"),
        "03_MainGear": ("뒤집어서 (윗면이 바닥)", "서포트 없음 (핀 구멍 바닥·이빨 끝 작은 턱만)"),
        "04_Handle": ("그대로", "서포트 없음 (608 자리 지붕 Ø22 브리지)"),
        "05_Yoke": ("뒤집어서 (윗면이 바닥)", "서포트 없음: 롤러 홈·축 받침이 모두 수직 벽"),
        "06_CrankRoller": ("뒤집어서 (롤러 윗면이 바닥, 핀이 위)", "서포트 없음"), "10_MainRetainer": ("그대로", "서포트 없음"),
        "11_Dial": ("뒤집어서", "서포트 없음 (장식 홈 0.9mm 브리지)"),
        "15_CombLower": ("그대로", "서포트 없음"), "16_CombUpper": ("뒤집어서", "서포트 없음"),
        "23_RearGuideRail": ("옆으로 (-y 면이 바닥)", "서포트 없음 (랙 이빨이 출력면에)"),
        "24_SyncAxle": ("세워서 (뒤 링이 바닥)", "서포트 없음, 브림 8~10mm"),
        "25_Arrow": ("뒤집어서 (화살표 윗면이 바닥)", "서포트 없음, 윗면이 매끈하게 나옴")}
names = list(NOTE)
fig, axs = plt.subplots(4, 4, figsize=(24, 21), dpi=90)
for ax in axs.flat:
    ax.axis("off")
for ax, n in zip(axs.flat, names):
    p = os.path.join(r"C:\Users\Public\mbx_work\img\audit", n + ("_below.png" if n in ("04_Handle",) else "_above.png"))
    im = mpimg.imread(p)
    ax.imshow(im[60:-60, 80:-80])
    r = A[n]
    o, v = NOTE[n]
    ax.set_title("%s\n%s · %s\n%s" % (n, o, "×".join("%.0f" % x for x in r["size_mm"]), v), fontsize=12.5, loc="left",
                 color="#222")
axs.flat[-3].text(0.0, 0.7, "파랑: 바닥에 닿는 면\n빨강: 45°보다 누운 아래쪽 면\n(짧은 브리지 또는 서포트)", fontsize=15, transform=axs.flat[-3].transAxes)
fig.suptitle("E2 출력 방향 (13부품): 서포트 없이 모두 출력", fontsize=19, x=0.01, ha="left")
fig.tight_layout(rect=(0, 0, 1, 0.97))
fig.savefig(os.path.join(IMG, "E_print_layout.png"))
print("saved")
