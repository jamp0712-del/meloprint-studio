# -*- coding: utf-8 -*-
# E: (1) yoke freedom at every crank angle over the whole sideways stroke, (2) rail 23 deflection / twist estimates.
import sys, math, json
sys.path.insert(0, r"C:\Users\Public\mbx_work")
src = open(r"C:\Users\Public\mbx_work\e_validate.py", encoding="utf-8-sig").read()
exec(src.split("# ---------------------------------------------------------------- 1.")[0].replace('sys.argv[1] if len(sys.argv) > 1 else "ap1"', '"ap1"'))
exec("def freedom" + src.split("def freedom")[1].split("R[\"freedom\"] = {}")[0])
out = {"stroke": []}
for th in range(0, 360, 15):
    f = freedom(E, th)
    x = ECC * math.sin(math.radians(th))
    out["stroke"].append({"th": th, "x": round(x, 1), "+y": f["+y"], "-y": f["-y"], "yaw+": f["yaw+"], "yaw-": f["yaw-"],
                          "lift": f["lift"], "yoke yaw vs axle": f["yoke yaw vs axle +"]})
    print(out["stroke"][-1], flush=True)

# ---------------------------------------------------------------- rail 23 beam estimates (PLA)
EM, GM = 3500.0, 1300.0
def sect(rects):
    A = sum((y1 - y0) * (z1 - z0) for y0, z0, y1, z1 in rects)
    yc = sum((y1 - y0) * (z1 - z0) * (y0 + y1) / 2 for y0, z0, y1, z1 in rects) / A
    zc = sum((y1 - y0) * (z1 - z0) * (z0 + z1) / 2 for y0, z0, y1, z1 in rects) / A
    Iy = sum((y1 - y0) * (z1 - z0) ** 3 / 12 + (y1 - y0) * (z1 - z0) * ((z0 + z1) / 2 - zc) ** 2 for y0, z0, y1, z1 in rects)   # vertical bending
    Iz = sum((z1 - z0) * (y1 - y0) ** 3 / 12 + (y1 - y0) * (z1 - z0) * ((y0 + y1) / 2 - yc) ** 2 for y0, z0, y1, z1 in rects)   # sideways bending
    J = 0.0
    for y0, z0, y1, z1 in rects:
        b, h = max(y1 - y0, z1 - z0), min(y1 - y0, z1 - z0)
        J += b * h ** 3 * (1 / 3 - 0.21 * h / b * (1 - h ** 4 / (12 * b ** 4)))
    return A, Iy, Iz, J, zc
MID = sect([(-70.9, 6.85, -69.4, 9.3), (-69.4, 6.85, -67.0, 7.964), (-67.0, 6.85, -64.6, 9.3)])
KEEL = sect([(-70.9, 1.6, -69.4, 9.3), (-69.4, 1.6, -67.0, 7.964), (-67.0, 1.6, -64.6, 9.3)])
SPAN = 26.0          # supported on the base ledges for |x| >= 26 (pins at +-36, screw at +31): simply supported there (conservative)


def EI(x, k):
    s = MID if abs(x) < 10.5 else KEEL
    return EM * s[k]


def deflection(a, P, k):
    """Mohr integral for a simply supported beam (-SPAN..SPAN), point load P at a, deflection under the load."""
    Lb = 2 * SPAN
    xs = [-SPAN + Lb * i / 4000 for i in range(4001)]
    ra = P * (SPAN - a) / Lb
    d = 0.0
    for i in range(4000):
        xm = 0.5 * (xs[i] + xs[i + 1]); dx = xs[i + 1] - xs[i]
        M = ra * (xm + SPAN) - (P * (xm - a) if xm > a else 0.0)
        m = ((SPAN - a) / Lb) * (xm + SPAN) - ((xm - a) if xm > a else 0.0)
        d += M * m / EI(xm, k) * dx
    return d


Fp = 2.0                                    # generous pluck force (N)
F1 = Fp * (28.5 + 59.3) / 88.55             # pinion couple force at the worst crank angle
P_down = F1 * math.tan(math.radians(20)) + 0.05
P_side = 0.3 * Fp                            # sideways guide force share at rail 23 (pick pushed off the tine)
worst_v = max(deflection(a, P_down, 1) for a in [i * 0.5 for i in range(-50, 51)])
worst_s = max(deflection(a, P_side, 2) for a in [i * 0.5 for i in range(-50, 51)])
T = P_side * abs(8.3 - MID[4])              # guide contact height ~8.3 vs section centroid
phi = T * SPAN / (4 * GM * MID[3])          # torque at mid span, ends held
out["rail23"] = {"pluck_force_N": Fp, "pinion_force_N": round(F1, 2), "down_load_N": round(P_down, 2), "side_load_N": P_side,
                 "sections": {"mid": [round(v, 2) for v in MID], "keel": [round(v, 2) for v in KEEL]},
                 "max_down_deflection_mm": round(worst_v, 4), "max_side_deflection_mm": round(worst_s, 5),
                 "twist_deg": round(math.degrees(phi), 4),
                 "backlash_opening_mm": round(2 * worst_v * math.tan(math.radians(20)), 4),
                 "x_slip_needed_to_move_N": "pins D2.7 in base holes + M3x5 clamp (friction ~0.3 x clamp force)"}
# front rail: a wall of the base from the floor (z -3.31) to 9.3, 5.95 thick, joined to the floor along its length
FRONT = sect([(17.65, -3.31, 23.6, 9.3)])
out["front_rail"] = {"I_vertical": round(FRONT[1], 1), "I_side": round(FRONT[2], 1),
                     "note": "joined to the base floor and both side walls along its whole length; beam bending does not apply"}
print(json.dumps(out["rail23"], indent=1)); print(out["front_rail"])
json.dump(out, open(r"C:\Users\Public\mbx_work\in\e_rail_check.json", "w"), indent=1)
