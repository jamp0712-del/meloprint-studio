# -*- coding: utf-8 -*-
# Concept E: replace the spur teeth of 03 (60T) and 04 (40T) by a helical pair with the SAME transverse profile
# (m_t 1.14652, 20 deg, standard addendum, same tooth thinning -> same 0.32 mm backlash), same diameters, centres and
# tooth band (z -1.8 .. 1.2). Helix 25 deg: handle gear right-hand, main gear left-hand. Teeth are lofted B-spline
# surfaces (three rotated transverse sections), so the parts stay NURBS B-rep.
import sys, math, os
sys.path.insert(0, r"C:\Users\Public\mbx_work")
import numpy as np
from OCP.gp import gp_Pnt
from OCP.GC import GC_MakeSegment, GC_MakeArcOfCircle
from OCP.TColgp import TColgp_HArray1OfPnt
from OCP.GeomAPI import GeomAPI_Interpolate
from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeEdge, BRepBuilderAPI_MakeWire
from OCP.BRepOffsetAPI import BRepOffsetAPI_ThruSections
from ap1_tool import cyl, valid, n_solids
from occ_conv import volume
from e_parts import vcut, vfuse
from pf2_kin import MAIN_C, HANDLE_C

M_T = 1.14652
PA = math.radians(20.0)
BETA = math.radians(25.0)
Z0, Z1 = -1.8, 1.25                              # 1.25: a cut exactly at the old tooth top (1.2) fails in OCC
FACE = Z1 - Z0
ARC = FACE * math.tan(BETA)                     # helix advance at the pitch circle over the face (1.399 mm)
GEARS = {"03": dict(z=60, c=MAIN_C, thin=0.102, hand=-1),      # left-hand
         "04": dict(z=40, c=HANDLE_C, thin=0.216, hand=+1)}    # right-hand
inv = lambda a: math.tan(a) - a


def radii(z):
    rp = M_T * z / 2.0
    return rp, rp * math.cos(PA), rp + M_T, rp - 1.25 * M_T


def profile_wire(z, cx, cy, zz, thin, phase):
    """Closed transverse outline at height zz, tooth k centred at phase + k * 2pi/z (CCW)."""
    rp, rb, ra, rf = radii(z)
    s = M_T * math.pi / 2.0 - thin
    half_b = s / (2.0 * rp) + inv(PA)
    pitch = 2.0 * math.pi / z
    r0 = max(rb, rf)
    rr = np.linspace(r0, ra, 13)
    th = [half_b - inv(math.acos(min(1.0, rb / r))) for r in rr]
    P = lambda r, a: gp_Pnt(cx + r * math.cos(a), cy + r * math.sin(a), zz)
    w = BRepBuilderAPI_MakeWire()

    def spline(pts):
        arr = TColgp_HArray1OfPnt(1, len(pts))
        for i, q in enumerate(pts):
            arr.SetValue(i + 1, q)
        it = GeomAPI_Interpolate(arr, False, 1e-7); it.Perform()
        return BRepBuilderAPI_MakeEdge(it.Curve()).Edge()
    th_r0 = th[0]                       # angular half width where the flank starts (rb or rf)
    for k in range(z):
        c = phase + k * pitch
        if rf < rb:
            w.Add(BRepBuilderAPI_MakeEdge(GC_MakeSegment(P(rf, c - half_b), P(rb, c - half_b)).Value()).Edge())
        w.Add(spline([P(r, c - t) for r, t in zip(rr, th)]))
        w.Add(BRepBuilderAPI_MakeEdge(GC_MakeArcOfCircle(P(ra, c - th[-1]), P(ra, c), P(ra, c + th[-1])).Value()).Edge())
        w.Add(spline([P(r, c + t) for r, t in zip(rr[::-1], th[::-1])]))
        if rf < rb:
            w.Add(BRepBuilderAPI_MakeEdge(GC_MakeSegment(P(rb, c + half_b), P(rf, c + half_b)).Value()).Edge())
        a0, a1 = c + (half_b if rf < rb else th_r0), c + pitch - (half_b if rf < rb else th_r0)
        w.Add(BRepBuilderAPI_MakeEdge(GC_MakeArcOfCircle(P(rf, a0), P(rf, 0.5 * (a0 + a1)), P(rf, a1)).Value()).Edge())
    assert w.IsDone()
    return w.Wire()


def helical_band(key, phase_mid):
    g = GEARS[key]
    z, (cx, cy) = g["z"], g["c"]
    rp, rb, ra, rf = radii(z)
    dphi = g["hand"] * ARC / rp                   # total twist over the face; right-hand: CCW with rising z
    loft = BRepOffsetAPI_ThruSections(True, False, 1e-6)
    for t in (0.0, 0.5, 1.0):
        zz = Z0 + t * FACE
        loft.AddWire(profile_wire(z, cx, cy, zz, g["thin"], phase_mid + (t - 0.5) * dphi))
    loft.CheckCompatibility(False)
    loft.Build()
    s = loft.Shape()
    assert valid(s) and volume(s) > 0, key
    ring = vcut(cyl(cx, cy, ra + 2.0, Z0, Z1), cyl(cx, cy, rf - 0.3, Z0 - 0.1, Z1 + 0.1))
    from OCP.BRepAlgoAPI import BRepAlgoAPI_Common
    from ap1_tool import _bool
    band = _bool(BRepAlgoAPI_Common, s, ring, 1e-5)
    return band


def tooth_phase(shape_mf, key, zz=-0.3):
    """Angle of a tooth centre on the pitch circle of the existing spur gear at height zz."""
    import matplotlib.path as mp
    g = GEARS[key]
    z, (cx, cy) = g["z"], g["c"]
    rp = radii(z)[0]
    P = [np.array(p) for p in shape_mf.slice(zz).to_polygons()]
    ang = np.linspace(0, 2 * np.pi, 36000, endpoint=False)
    pts = np.c_[cx + rp * np.cos(ang), cy + rp * np.sin(ang)]
    inside = np.zeros(len(ang), bool)
    for p in P:
        inside ^= mp.Path(p).contains_points(pts)
    d = np.diff(inside.astype(int))
    starts, ends = np.where(d == 1)[0] + 1, np.where(d == -1)[0] + 1
    if ends[0] < starts[0]:
        ends = ends[1:]
    return float(0.5 * (ang[starts[0]] + ang[ends[0] - 1]))


def make_helical(shape, key):
    from mf_tool import to_manifold
    g = GEARS[key]
    cx, cy = g["c"]
    rp, rb, ra, rf = radii(g["z"])
    ph = tooth_phase(to_manifold(shape, 0.002), key)
    band = helical_band(key, ph)
    body = vcut(shape, vcut(cyl(cx, cy, ra + 2.0, Z0 - 0.05, Z1), cyl(cx, cy, rf - 0.3, Z0 - 0.2, Z1 + 0.1)))
    out = vfuse(body, band)
    print(key, "phase %.4f rad  twist %.3f deg  solids %d valid %s vol %.2f (spur %.2f)" % (
        ph, math.degrees(g["hand"] * ARC / rp), n_solids(out), valid(out), volume(out), volume(shape)), flush=True)
    return out


if __name__ == "__main__":
    from ap1_view import load_cache
    from OCP.BRepTools import BRepTools
    import shutil
    for tag in ("ap1", "mw4"):
        d = r"C:\Users\Public\mbx_work\in\e_brep_%s" % tag
        bk = d + "_spur"
        if not os.path.exists(bk):
            shutil.copytree(d, bk)
    S = load_cache(r"C:\Users\Public\mbx_work\in\e_brep_ap1_spur")
    new = {"03_MainGear": make_helical(S["03_MainGear"], "03"), "04_Handle": make_helical(S["04_Handle"], "04")}
    for tag in ("ap1", "mw4"):
        d = r"C:\Users\Public\mbx_work\in\e_brep_%s" % tag
        for n, s in new.items():
            BRepTools.Write_s(s, os.path.join(d, n + ".brep"))
    eps_b = ARC / (math.pi * M_T)
    print("overlap ratio %.3f, axial/tangential force %.3f" % (eps_b, math.tan(BETA)))
