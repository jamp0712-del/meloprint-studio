# -*- coding: utf-8 -*-
# Concept E constants: v47 crank + yoke, yaw locked by a sync axle (two m0.8 pinions on racks at the front rail and
# rail 23, rolling rings on pitch-line strips), main gear tilt pad, M3x5 hardware. Yoke coordinates are "resting".
import math

YOKE_FILE_DZ = 0.248                 # stored yoke B-rep = resting + 0.248 (same convention as v47 / D)

# sync axle and pinions
M = 0.8
Z = 10
X_SHIFT = 0.42
PA = 20.0
RP = M * Z / 2.0                     # 4.0 pitch radius = rolling ring radius
RA = RP + M * (1.0 + X_SHIFT)        # 5.136
RF = RP - M * (1.25 - X_SHIFT)       # 3.336
THIN_PINION = 0.08                   # tooth thickness reduction at the pitch circle (total, both flanks)
THIN_RACK = 0.08                     # -> circumferential backlash 0.16
AXLE_R = 3.0
AXLE_Z = 13.3                        # axle centre (resting)
STRIP_Z = AXLE_Z - RP                # 9.3 rolling strip top = working pitch line
RACK_REF = STRIP_Z - X_SHIFT * M     # 8.964 rack reference line
RACK_TIP = RACK_REF + M              # 9.764
RACK_ROOT = RACK_REF - 1.25 * M      # 7.964
PITCH = math.pi * M                  # 2.5133
RACK_X = 41.9                        # teeth centres within |x| <= RACK_X

# axle stations along y (rear -> front)
R_RING = (-70.7, -69.55)
R_PIN = (-69.15, -67.25)
F_RING = (17.85, 19.0)
F_PIN = (19.4, 21.3)

# front rail (base): strip / groove / solid bands
FR_Y0, FR_Y1 = 17.65, 23.6
FR_GROOVE = (19.15, 21.55)
FR_TEETH = (19.25, 21.45)
# rail 23
R23_Y0, R23_Y1 = -70.9, -64.6
R23_GROOVE = (-69.4, -67.0)
R23_TEETH = (-69.3, -67.1)
R23_X = 43.2

# yoke
CRADLE_R = 3.1
CRADLE_Z = AXLE_Z - 0.1              # yoke rests on the axle top
CRADLE_OPEN = 3.05                   # half width of the downward opening
CEILING_Z = 17.4                     # cover underside (measured)
TOP_Z = 17.3                         # hold-down / roll stop, 0.1 under the cover ceiling
CHEEK_X = 5.45
FRONT_CRADLE = (5.0, 17.75)
REAR_CRADLE = (-67.15, -58.0)
LIP = (-71.65, -71.0)

# main gear tilt pad (annulus under the gear, 0.1 below its underside z -1.8)
MAIN_PAD = (12.0, 14.0, -1.9)

R23_PIN_Y = -69.325                  # v47 pin / base hole position
# rail 23 screw (M3x5 from the base underside into a nut in the rail)
R23_SCREW = (31.0, -67.5)
R23_NUT_Z = (2.85, 5.35)                # M3x5 from the head seat 0.3 ends at 5.3: full 2.4 mm nut engagement
SCREW_HEAD_SEAT = 0.3

# front block (y 21.85: 0.3 ahead of the front pinion at its +0.25 groove play) and the 25 arrow
FRONT_BLOCK = (21.85, 28.0)          # 0.34 short of the comb tips (y 28.34)
ARROW_Z = (20.952, 22.952)           # arrow plate, 0.22 over the cover top
ARROW_PLATE = [(3.0, 9.0), (3.0, 18.0), (7.0, 18.0), (0.0, 27.0), (-7.0, 18.0), (-3.0, 18.0), (-3.0, 9.0)]
_xe = lambda y: 7.0 * (27.0 - y) / 9.0      # arrow head half width
ARROW_HEAD_STEM = [(-3.0, 21.95), (3.0, 21.95), (3.0, 22.757), (_xe(25.3) - 0.3, 25.3), (-(_xe(25.3) - 0.3), 25.3), (-3.0, 22.757)]
ARROW_PEG = [(-(_xe(22.95) - 0.75), 22.95), (_xe(22.95) - 0.75, 22.95), (_xe(24.6) - 0.75, 24.6), (-(_xe(24.6) - 0.75), 24.6)]
ARROW_PEG_Z = (11.4, 17.3)           # 5.9 deep, socket floor 1.1 thick
# rear lip back profile (y, z): hub r 7.0 between its cones z 8.75..15.5 (r 9.1 at 6.5, r 8.6 at 17.0)
LIP_BACK = [(-71.4, 16.45), (-71.65, 16.45), (-72.9, 15.2), (-72.9, 8.95), (-71.65, 7.7), (-71.4, 7.7)]
# crank pin on the roller (06), blind hole in the main gear (03)
CRANK_PIN = (0.0, -23.218 + 36.064)
GEAR_TOP = 5.5                       # main gear flat top (print bed when printed upside down)
PIN_HOLE_R = 2.2                     # 0.2 radial clearance on the pin (same as the v47 roller bore)
PIN_HOLE_Z = (2.1, 5.5)              # floor 0.5 over the ring underside z 1.6
ROLLER_R = 3.5
ROLLER_Z = (5.6, 9.9)                # 0.1 over the gear top; 0.4 under the axle (main gear up-play to the clip 0.2)
PIN_R = 2.0
PIN_Z = (2.25, 5.6)
