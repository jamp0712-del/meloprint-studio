# -*- coding: utf-8 -*-
# Apply the E cover changes (M3x5 counterbores, comb-side corner reliefs, middle + rear ribs removed, rear pinion
# relief) to the site's 14 decorative cover print meshes. Print frame -> assembly: (x + cx, cy - y, z0 - z).
import sys, os, json
sys.path.insert(0, r"C:\Users\Public\mbx_work")
import numpy as np, trimesh, manifold3d as m3
from ap1_view import load_cache
from mf_tool import to_manifold
import c_case as CC
import e_layout as L
SRC = r"C:\Users\Public\mbx_work\site_v47\models"
OUT = r"C:\Users\Public\mbx_work\e_site_assets\models"
os.makedirs(OUT, exist_ok=True)
CX, CY = 0.030805587768554688, -30.558719635009766
Z0 = {"base": 20.73442268371582}


def tools_assembly():
    T = []
    box = lambda x0, y0, z0, x1, y1, z1: m3.Manifold.cube((x1 - x0, y1 - y0, z1 - z0)).translate((x0, y0, z0))
    cyl = lambda cx, cy, r, z0, z1: m3.Manifold.cylinder(z1 - z0, r, r, 96).translate((cx, cy, z0))
    for cx, cy in CC.CORNERS:
        T.append(cyl(cx, cy, 3.03, CC.CB_Z_NEW, 16.95))      # 0.03 over the old D3 hole: no coincident seam
        if cy > 0:
            sx = 1 if cx > 0 else -1
            xa, xb = cx - sx * 3.40, cx - sx * 2.55
            T.append(box(min(xa, xb), cy - 1.95, 8.0, max(xa, xb), cy + 1.95, 14.9))
    T.append(box(-43.2, -25.6, 13.5, 43.2, -20.8, L.CEILING_Z))
    T.append(box(-43.2, -71.3, 12.0, 43.2, -67.3, L.CEILING_Z))
    T.append(box(-41.6, L.R_PIN[0] - 0.3, L.CEILING_Z - 0.1, 41.6, L.R_PIN[1] + 0.3, 18.75))
    x0, y0, x1, y1 = L.COVER_BAR_CUT
    T.append(box(x0, y0, 17.0, x1, y1, 30.0))                 # bar between window and comb opening (pluck visible)
    u = T[0]
    for t in T[1:]:
        u = u + t
    return u


def to_print(M, z0):
    # inverse of (x + CX, CY - y, z0 - z): x' = x - CX, y' = CY - y, z' = z0 - z  (a 180 deg turn about x + shift)
    return M.transform([[1, 0, 0, -CX], [0, -1, 0, CY], [0, 0, -1, z0]])


def load_mf(p):
    t = trimesh.load(p)
    mf = m3.Manifold(m3.Mesh(vert_properties=np.asarray(t.vertices, np.float32), tri_verts=np.asarray(t.faces, np.uint32)))
    assert mf.status() == m3.Error.NoError, p
    return mf


def save(mf, p, name):
    for tol in (1e-5, 5e-5, 2e-4):
        mm = mf.simplify(tol).to_mesh()
        tt = trimesh.Trimesh(np.array(mm.vert_properties)[:, :3].astype(np.float32).astype(float), np.array(mm.tri_verts).astype(np.int64))
        if tt.is_watertight:
            break
    trimesh.Trimesh(np.array(mm.vert_properties)[:, :3].astype(float), np.array(mm.tri_verts).astype(np.int64), process=False).export(p, file_type='stl')


if __name__ == "__main__":
    TA = tools_assembly()
    styles = json.load(open(r"C:\Users\Public\mbx_work\e_site_cover_z.json"))       # style -> z0 (from app.js LB)
    rep = {}
    for f in sorted(os.listdir(SRC)):
        if not (f.endswith("_PRINT.stl") and "02_Cover" in f):
            continue
        style = f.split("_PF2_")[1].replace("_PRINT.stl", "")
        z0 = styles[style]
        V = load_mf(os.path.join(SRC, f))
        r = V - to_print(TA, z0)
        import e_parts as EP                               # comb press fit on the cover walls and pads (as the CAD cover)
        G = None
        for g in EP.comb_grip("cover_mw4" if f.startswith("mw4_") else "cover_ap1", inset=0.03):
            gm = to_manifold(g, 0.003)
            G = gm if G is None else G + gm
        if EP.L.CASE_GRIP:
            r = r + to_print(G, z0)
        p = os.path.join(OUT, f)
        save(r, p, f[:-4])
        t = trimesh.load(p)
        rep[f] = {"style": style, "before": round(V.volume(), 2), "after": round(float(t.volume), 2), "removed": round(V.volume() - float(t.volume), 2),
                  "faces": int(len(t.faces)), "watertight": bool(t.is_watertight), "genus_before": V.genus(), "genus_after": r.genus()}
        print(f, rep[f], flush=True)
    # check: base style vs the E CAD cover (AP1) in the assembly frame
    E = to_manifold(load_cache(r"C:\Users\Public\mbx_work\in\e_brep_ap1")["02_Cover"], 0.004)
    B = load_mf(os.path.join(OUT, "02_Cover_PF2_base_PRINT.stl")).transform([[1, 0, 0, CX], [0, -1, 0, CY], [0, 0, -1, styles["base"]]])
    d1, d2 = (B - E), (E - B)
    rep["check_base_vs_E_cover"] = {"base_minus_E": round(d1.volume(), 2), "E_minus_base": round(d2.volume(), 2),
                                    "parts_base_minus_E": [[round(v, 1) for v in c.bounding_box()] for c in d1.decompose() if c.volume() > 0.5][:12],
                                    "parts_E_minus_base": [[round(v, 1) for v in c.bounding_box()] for c in d2.decompose() if c.volume() > 0.5][:12]}
    print(rep["check_base_vs_E_cover"])
    json.dump(rep, open(os.path.join(OUT, "..", "covers_E.json"), "w"), indent=1)
