# -*- coding: utf-8 -*-
# Two distinguishable site versions: E2 (current build, site root) and E1 (previous commit a862c64, served at e1/).
# Each page gets a version bar at the top with a link to the other version. Run after build_E_site.py.
import os, io, shutil, tarfile, subprocess
W = r"C:\Users\Public\mbx_work"
E2, GH = W + r"\site_E", W + r"\gh_meloprint"
E1_COMMIT = "a862c64"
BAR = ('<div class="version-bar" style="display:flex;flex-wrap:wrap;align-items:center;gap:6px 16px;margin:0 0 16px;padding:10px 14px;'
       'border-radius:10px;background:%s;color:#fff;font-size:14px;line-height:1.45">'
       '<strong style="font-size:15px">%s</strong><span>%s</span>'
       '<a href="%s" style="margin-left:auto;color:#a9ecd2;font-weight:600;text-decoration:underline">%s</a></div>')
E2_BAR = BAR % ("#1f5f4a", "E2 · 최신 버전", "13부품 · 헬리컬 기어 · M3×5만 · 요크 뒤집어 출력 + 25 화살표 · 서포트 없이 모두 출력",
                "e1/", "이전 버전 E1 보기 →")
E1_BAR = BAR % ("#6b4a1f", "E1 · 이전 버전", "12부품 · 평기어 · 나사 M3×6 표기 · 요크 옆으로 눕혀 출력(서포트 필요)",
                "../", "최신 버전 E2로 →")
ANCHOR = '<section class="intro"><div>'


def mark(path, bar, title, eyebrow_old, eyebrow_new):
    s = open(path, encoding="utf-8").read()
    if "version-bar" in s:
        raise SystemExit("already marked: " + path)
    assert s.count(ANCHOR) == 1 and s.count(eyebrow_old) == 1, path
    s = s.replace(ANCHOR, ANCHOR + bar, 1).replace(eyebrow_old, eyebrow_new, 1)
    s = s.replace("<title>Meloprint Studio — ", "<title>%s — " % title, 1)
    s = s.replace("<strong>PF2 32 Stable · E</strong>", "<strong>PF2 32 Stable · %s</strong>" % title.split()[2], 1)
    open(path, "w", encoding="utf-8", newline="").write(s)


# E2 = the current build
mark(os.path.join(E2, "index.html"), E2_BAR, "Meloprint Studio E2", '<p class="eyebrow">PF2 E · 13 PRINTED', '<p class="eyebrow">PF2 E2 · 13 PRINTED')

# E1 = the previous published commit, unpacked into e1/ of the repo (site files only)
E1 = os.path.join(W, "site_E1")
shutil.rmtree(E1, ignore_errors=True)
os.makedirs(E1)
tar = subprocess.run(["git", "-C", GH, "archive", "--format=tar", E1_COMMIT], capture_output=True, check=True).stdout
with tarfile.open(fileobj=io.BytesIO(tar)) as t:
    t.extractall(E1)
for n in ("README.md", ".nojekyll"):
    p = os.path.join(E1, n)
    if os.path.exists(p):
        os.remove(p)
mark(os.path.join(E1, "index.html"), E1_BAR, "Meloprint Studio E1 (이전)", '<p class="eyebrow">PF2 E · 12 PRINTED', '<p class="eyebrow">PF2 E1 · 12 PRINTED')
print("marked E2 and E1")
