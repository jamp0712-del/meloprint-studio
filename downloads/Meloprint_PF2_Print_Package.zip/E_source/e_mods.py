# -*- coding: utf-8 -*-
# Concept E build: D parts -> E parts (B-rep cache in\e_brep_ap1|mw4, hardware in\e_hw).
import sys, os, time
sys.path.insert(0, r"C:\Users\Public\mbx_work")
from OCP.BRepTools import BRepTools
from ap1_view import load_cache
from ap1_tool import n_solids, valid
from occ_conv import volume
import e_parts as EP

t0 = time.time()
axle = EP.sync_axle()
rail = EP.rail23_e()
print("axle solids=%d valid=%s vol=%.2f   rail23 solids=%d valid=%s vol=%.2f  %.0fs" % (
    n_solids(axle), valid(axle), volume(axle), n_solids(rail), valid(rail), volume(rail), time.time() - t0), flush=True)
common = None
for tag in ("ap1", "mw4"):
    D = load_cache(r"C:\Users\Public\mbx_work\in\d_brep_%s" % tag)
    out = dict(D)
    out["01_Base"] = EP.base_e(D["01_Base"])
    out["02_Cover"] = EP.cover_e(D["02_Cover"])
    if common is None:
        import e_helical as EH
        common = {"03_MainGear": EH.make_helical(EP.main_gear_e(D["03_MainGear"]), "03"),
                  "04_Handle": EH.make_helical(EP.handle_heal(D["04_Handle"]), "04"), "05_Yoke": EP.yoke_e(D["05_Yoke"]),
                  "23_RearGuideRail": rail, "24_SyncAxle": axle, "25_Arrow": EP.arrow_e(),
                  "06_CrankRoller": EP.crank_roller_e()}
    out.update(common)
    d = r"C:\Users\Public\mbx_work\in\e_brep_%s" % tag
    os.makedirs(d, exist_ok=True)
    for f in os.listdir(d):
        os.remove(os.path.join(d, f))
    for n, s in out.items():
        print("%s %-16s solids=%d valid=%s vol=%.2f" % (tag, n, n_solids(s), valid(s), volume(s)), flush=True)
        BRepTools.Write_s(s, os.path.join(d, n + ".brep"))
hw = EP.hardware_e()
v47hw = load_cache(r"C:\Users\Public\mbx_work\in\pf2v47_hw")
for k in ("HW_608_Inner", "HW_608_Outer", "HW_608_Shield"):
    hw[k] = v47hw[k]
d = r"C:\Users\Public\mbx_work\in\e_hw"
os.makedirs(d, exist_ok=True)
for f in os.listdir(d):
    os.remove(os.path.join(d, f))
for n, s in hw.items():
    BRepTools.Write_s(s, os.path.join(d, n + ".brep"))
print("hardware", sorted(hw), "%.0fs" % (time.time() - t0))
