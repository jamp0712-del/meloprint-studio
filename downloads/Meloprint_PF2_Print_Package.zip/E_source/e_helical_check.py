# -*- coding: utf-8 -*-
# Helical pair check: interference over a full main-gear turn, backlash, positive control, spur comparison.
import sys, math, json
sys.path.insert(0, r"C:\Users\Public\mbx_work")
import numpy as np
from ap1_view import load_cache
from mf_tool import to_manifold, xf_rotate
from pf2_kin import part_xf, MAIN_C, HANDLE_C
R = {}
for tag, src in (("spur", r"in\e_brep_ap1_spur"), ("helical", r"in\e_brep_ap1")):
    S = load_cache("C:/Users/Public/mbx_work/" + src.replace("\\", "/"))
    G3, G4 = to_manifold(S["03_MainGear"], 0.002), to_manifold(S["04_Handle"], 0.002)
    worst, at = 0.0, None
    for th in np.arange(0, 360, 0.5):
        a, b = G3.transform(part_xf("03", th)), G4.transform(part_xf("04", th))
        v = (a ^ b).volume()
        if v > worst:
            worst, at = v, float(th)
    def free(th, s):
        a, b = G3.transform(part_xf("03", th)), G4.transform(part_xf("04", th))
        lo, hi = 0.0, 4.0
        for _ in range(26):
            mid = (lo + hi) / 2
            if (b.transform(xf_rotate(s * mid, (HANDLE_C[0], HANDLE_C[1], 0), (0, 0, 1))) ^ a).volume() > 1e-5:
                hi = mid
            else:
                lo = mid
        return lo
    bl = [(th, round(math.radians(free(th, 1) + free(th, -1)) * 22.930, 4)) for th in (0, 2.0, 4.0, 77.0, 181.0)]
    ctl = (G4.transform(part_xf("04", 0)).transform(xf_rotate(1.0, (HANDLE_C[0], HANDLE_C[1], 0), (0, 0, 1))) ^ G3.transform(part_xf("03", 0))).volume()
    R[tag] = {"max_interference_mm3": round(worst, 5), "at_theta": at, "backlash_mm_at_handle_pitch": bl, "control_rotate_1deg_mm3": round(ctl, 3)}
    print(tag, R[tag], flush=True)
json.dump(R, open(r"C:\Users\Public\mbx_work\in\e_helical_check.json", "w"), indent=1)
