# -*- coding: utf-8 -*-
# Make the claude.ai Artifact copy of site_E: page body without the document skeleton, a download bridge that routes
# every save through the `downloads` capability (STL / 3DM are wrapped in a zip, the allowed format), publish batches.
# Usage: make_E_artifact.py [E2|E1]  (E2: site_E -> site_E_art, E1: site_E1 -> site_E1_art)
import os, re, shutil, json, sys
W = r"C:\Users\Public\mbx_work"
VER = sys.argv[1] if len(sys.argv) > 1 else "E2"
ART = {"E1": "https://claude.ai/artifact/LuxVc9uLxL6HEggTvBCZE4", "E2": "https://claude.ai/artifact/G5M4E21gwZLiZ8KXDYFQ2t"}
CFG = {"E2": (W + r"\site_E", W + r"\site_E_art", "Meloprint Studio E2", 'href="e1/"', ART["E1"]),
       "E1": (W + r"\site_E1", W + r"\site_E1_art", "Meloprint Studio E1 (이전)", 'href="../"', ART["E2"])}
S, D, TITLE, LINK, OTHER = CFG[VER]
shutil.rmtree(D, ignore_errors=True)
shutil.copytree(S, D)

h = open(os.path.join(S, "index.html"), encoding="utf-8").read()
body = h.split("<body>", 1)[1].rsplit("</body>", 1)[0]
# version bar: on claude.ai each version is its own artifact, so the bar links to the other artifact
assert body.count(LINK) == 1
body = body.replace(LINK, 'href="%s" target="_blank" rel="noopener"' % OTHER)
desc = re.search(r'<meta name="description" content="([^"]*)">', h).group(1)
page = ('<title>%s</title>\n'
        '<meta name="description" content="%s">\n'
        '<link rel="stylesheet" href="style.css">\n'
        '<style>body{font:inherit;background:#eff3f6;color:#172d3c}</style>\n'
        '<script src="mp-dl.js"></script>\n' % (TITLE, desc)) + body.strip() + "\n"
open(os.path.join(D, "index.html"), "w", encoding="utf-8", newline="").write(page)

BRIDGE = r"""// Download bridge for the claude.ai viewer: pages there cannot start downloads themselves, so every save goes through
// the `downloads` capability (the viewer confirms each file). Formats outside the allowlist (STL, 3DM) are wrapped in a
// zip. Outside the viewer it falls back to an ordinary download.
(() => {
  const OK = /\.(zip|json|png|jpg|jpeg|webp|gif|txt|md|csv|pdf|svg|html)$/i;
  const inViewer = !!(window.claude && window.claude.use);
  const ready = inViewer ? window.claude.use("downloads").catch(() => null) : Promise.resolve(null);
  let T = null;
  const crc32 = (b) => {
    if (!T) { T = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; T[n] = c >>> 0; } }
    let x = 0xFFFFFFFF; for (let i = 0; i < b.length; i++) x = T[(x ^ b[i]) & 255] ^ (x >>> 8); return (x ^ 0xFFFFFFFF) >>> 0;
  };
  const zipOne = (name, data) => {
    const enc = new TextEncoder().encode(name), crc = crc32(data), n = data.length;
    const lh = new Uint8Array(30 + enc.length), a = new DataView(lh.buffer);
    a.setUint32(0, 0x04034b50, true); a.setUint16(4, 20, true); a.setUint16(6, 0x0800, true); a.setUint16(12, 0x21, true);
    a.setUint32(14, crc, true); a.setUint32(18, n, true); a.setUint32(22, n, true); a.setUint16(26, enc.length, true); lh.set(enc, 30);
    const ch = new Uint8Array(46 + enc.length), c = new DataView(ch.buffer);
    c.setUint32(0, 0x02014b50, true); c.setUint16(4, 20, true); c.setUint16(6, 20, true); c.setUint16(8, 0x0800, true); c.setUint16(14, 0x21, true);
    c.setUint32(16, crc, true); c.setUint32(20, n, true); c.setUint32(24, n, true); c.setUint16(28, enc.length, true); ch.set(enc, 46);
    const end = new Uint8Array(22), e = new DataView(end.buffer);
    e.setUint32(0, 0x06054b50, true); e.setUint16(8, 1, true); e.setUint16(10, 1, true); e.setUint32(12, ch.length, true); e.setUint32(16, lh.length + n, true);
    return new Blob([lh, data, ch, end]);
  };
  const toast = (msg) => {
    const t = document.getElementById("toast"); if (!t) return;
    t.textContent = msg; t.classList.add("show"); clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove("show"), 4000);
  };
  const legacy = (name, data, mime) => {
    const u = URL.createObjectURL(data instanceof Blob ? data : new Blob([data], { type: mime || "application/octet-stream" }));
    const a = document.createElement("a"); a.href = u; a.download = name; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(u), 1500);
  };
  const bytesOf = async (d) => d instanceof Uint8Array ? d : d instanceof ArrayBuffer ? new Uint8Array(d) : typeof d === "string" ? new TextEncoder().encode(d)
    : d instanceof Blob ? new Uint8Array(await d.arrayBuffer()) : new Uint8Array(d.buffer, d.byteOffset || 0, d.byteLength);
  window.__mpSave = async (name, data, mime) => {
    const dl = await ready;
    if (!dl) return legacy(name, data, mime);
    let file = name, blob;
    if (OK.test(name)) blob = data instanceof Blob ? data : new Blob([await bytesOf(data)]);
    else { blob = zipOne(name, await bytesOf(data)); file = name + ".zip"; }
    try { await dl.save({ filename: file, data: blob }); toast(file + " 저장을 시작했습니다."); }
    catch (err) {
      const code = err && err.code;
      if (code === "declined") toast("저장을 취소했습니다.");
      else if (code === "rate_limited") toast("다른 저장 창이 열려 있습니다. 잠시 후 다시 눌러 주세요.");
      else toast("이 화면에서는 파일을 저장할 수 없습니다 (" + (code || "unavailable") + ").");
    }
  };
  document.addEventListener("click", (ev) => {
    const a = ev.target && ev.target.closest && ev.target.closest("a[download]");
    if (!a || !inViewer) return;
    const href = a.getAttribute("href"); if (!href) return;
    ev.preventDefault();
    const name = a.getAttribute("download") || href.split("/").pop();
    toast(name + " 준비 중…");
    fetch(href).then((r) => { if (!r.ok) throw Error(r.status); return r.arrayBuffer(); })
      .then((b) => window.__mpSave(name, new Uint8Array(b)))
      .catch(() => toast(name + " 파일을 불러오지 못했습니다."));
  }, true);
})();
"""
open(os.path.join(D, "mp-dl.js"), "w", encoding="utf-8", newline="").write(BRIDGE)

p = os.path.join(D, "app.js")
s = open(p, encoding="utf-8").read()
old = 'function xI(B,A,M){let U=URL.createObjectURL(new Blob([A],{type:M})),F=document.createElement("a");F.href=U,F.download=B,F.click(),setTimeout(()=>URL.revokeObjectURL(U),1500)}'
assert s.count(old) == 1
s = s.replace(old, 'function xI(B,A,M){if(window.__mpSave)return void window.__mpSave(B,A,M);let U=URL.createObjectURL(new Blob([A],{type:M})),F=document.createElement("a");F.href=U,F.download=B,F.click(),setTimeout(()=>URL.revokeObjectURL(U),1500)}')
open(p, "w", encoding="utf-8", newline="").write(s)

# ---------------------------------------------------------------- binary files -> gzip + base64 text (.gz.txt)
# Artifacts serve only web types (no .stl / .3dm / .zip). The page and the CAD worker fetch the original names; a fetch
# wrapper loads "<name>.gz.txt" instead and inflates it in the browser.
import gzip, base64
for r, _, fs in os.walk(D):
    for f in fs:
        if f.lower().endswith((".stl", ".3dm", ".zip")):
            full = os.path.join(r, f)
            raw = open(full, "rb").read()
            open(full + ".gz.txt", "w", encoding="ascii", newline="").write(base64.b64encode(gzip.compress(raw, 9, mtime=0)).decode())
            os.remove(full)
FETCH = r"""
// Binary models are published as gzip+base64 text (<name>.gz.txt); restore them transparently for every fetch.
(() => {
  const BIN = /\.(stl|3dm|zip)$/i, f0 = self.fetch.bind(self);
  const unpack = async (txt) => {
    const s = atob(txt.trim()), b = new Uint8Array(s.length);
    for (let i = 0; i < s.length; i++) b[i] = s.charCodeAt(i);
    return new Response(new Blob([b]).stream().pipeThrough(new DecompressionStream("gzip"))).arrayBuffer();
  };
  self.fetch = async (input, init) => {
    const raw = typeof input === "string" ? input : (input && input.url) || String(input);
    let u = null;
    try { u = new URL(raw, self.document ? document.baseURI : self.location.href); } catch (_) {}
    if (u && u.origin === self.location.origin && BIN.test(u.pathname)) {
      const r = await f0(u.href.split(/[?#]/)[0] + ".gz.txt");
      if (r.ok) {
        const buf = await unpack(await r.text());
        return new Response(buf, { status: 200, headers: { "Content-Type": "application/octet-stream", "Content-Length": String(buf.byteLength) } });
      }
    }
    return f0(input, init);
  };
})();
"""
p = os.path.join(D, "mp-dl.js")
_b = open(p, encoding="utf-8").read()
open(p, "w", encoding="utf-8", newline="").write(FETCH + _b)
p = os.path.join(D, "cad-worker.js")
w = open(p, encoding="utf-8").read()
assert w.startswith("import rhino3dm")
open(p, "w", encoding="utf-8", newline="").write(w.replace("self.onmessage=", FETCH.strip() + "\nself.onmessage=", 1))

files = []
for r, _, fs in os.walk(D):
    for f in fs:
        full = os.path.join(r, f)
        rel = os.path.relpath(full, D).replace("\\", "/")
        if rel == "index.html":
            continue
        files.append((rel, os.path.getsize(full)))
batch1 = [f for f in files if not (f[0].startswith("models/") and ".stl" in f[0])]
batch2 = [f for f in files if f[0].startswith("models/") and ".stl" in f[0]]
out = {"batch1": [f[0] for f in batch1], "batch2": [f[0] for f in batch2],
       "mb1": round(sum(f[1] for f in batch1) / 1e6, 2), "mb2": round(sum(f[1] for f in batch2) / 1e6, 2),
       "max_file": max(files, key=lambda f: f[1])}
json.dump(out, open(D + "_batches.json", "w"), indent=1)
print(json.dumps({k: (v if k.startswith("mb") or k == "max_file" else len(v)) for k, v in out.items()}))
