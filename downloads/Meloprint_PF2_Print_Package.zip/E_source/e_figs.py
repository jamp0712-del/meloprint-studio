# -*- coding: utf-8 -*-
# Concept E figures: mechanism render, drawer-effect statics, mesh sections, v47 / D / E comparison.
import sys, os, json, math
sys.path.insert(0, r"C:\Users\Public\mbx_work")
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from matplotlib.patches import FancyArrowPatch
from ap1_view import load_cache, section_lines
from ap1_tool import moved, rotated
from mf_tool import to_manifold, xf_rotate, xf_translate, compose
from pf2_kin import part_xf, ECC, MAIN_C
from c_render import Scene
import e_layout as L

SESSION = r"C:\Users\호준\AppData\Roaming\Claude\scratch-workspaces\2484390f-f0f2-4f82-bbfe-32b4ca171b18\68694043-e7ab-4f63-8fec-837dd5148705\scratch-2026-10-12-dfb134"
IMG = os.path.join(SESSION, "Meloprint_PF2_E", "images")
os.makedirs(IMG, exist_ok=True)
TMP = r"C:\Users\Public\mbx_work\img"
plt.rcParams["font.family"] = "Malgun Gothic"; plt.rcParams["axes.unicode_minus"] = False
E = load_cache(r"C:\Users\Public\mbx_work\in\e_brep_ap1")
D = load_cache(r"C:\Users\Public\mbx_work\in\d_brep_ap1")
VA = json.load(open(r"C:\Users\Public\mbx_work\in\e_validate_ap1.json"))
ST = json.load(open(r"C:\Users\Public\mbx_work\in\e_statics.json"))
COL = {"01": "#8a8f96", "02": "#3a9a3a", "03": "#e08a10", "04": "#c9a000", "05": "#d03030", "06": "#e050a0", "10": "#06c",
       "15": "#8a5ac8", "16": "#d0609a", "23": "#111111", "24": "#1f5fd0", "25": "#d03030"}


def axle_xf(th):
    X = ECC * math.sin(math.radians(th))
    return compose(xf_translate(X, 0, 0), xf_rotate(math.degrees(X / L.RP), (0, 0, L.AXLE_Z), (0, 1, 0)))


# ---------------------------------------------------------------- 1. render
th = 40.0
M = {n: to_manifold(s, 0.006) for n, s in E.items()}
HW = {n: to_manifold(s, 0.01) for n, s in load_cache(r"C:\Users\Public\mbx_work\in\e_hw").items()}
P = {}
for n, m in M.items():
    if n.startswith("24"):
        P[n] = m.transform(axle_xf(th)); continue
    xf = part_xf(n, th)
    mm = m.transform(xf) if xf is not None else m
    P[n] = mm.translate((0, 0, -L.YOKE_FILE_DZ)) if n[:2] in ("05", "25") else mm
RC = {"01": (0.80, 0.81, 0.82), "02": (0.93, 0.93, 0.91), "03": (0.90, 0.56, 0.16), "04": (0.86, 0.70, 0.18), "05": (0.85, 0.20, 0.18),
      "06": (0.90, 0.40, 0.65), "10": (0.6, 0.6, 0.6), "11": (0.20, 0.22, 0.24), "15": (0.60, 0.48, 0.80), "16": (0.82, 0.55, 0.72),
      "23": (0.15, 0.15, 0.15), "24": (0.15, 0.40, 0.85), "25": (0.85, 0.20, 0.18)}


def render(names, path, cam, alpha_yoke=False):
    sc = Scene(1800, 1150); sc.lights()
    for n in names:
        mm = P[n].to_mesh()
        sc.add(np.array(mm.vert_properties)[:, :3], np.array(mm.tri_verts), RC[n[:2]])
    for n in ("HW_608_Outer", "HW_608_Inner", "HW_608_Shield", "HW_M3x5_Rail", "HW_M3_Nut_Rail"):
        mm = (HW[n].transform(part_xf("04", th)) if n in ("HW_608_Outer", "HW_608_Shield") else HW[n]).to_mesh()
        sc.add(np.array(mm.vert_properties)[:, :3], np.array(mm.tri_verts), (0.45, 0.45, 0.48))
    sc.camera(*cam)
    sc.save(path)
    return sc


X = ECC * math.sin(math.radians(th))
sc = render([n for n in P if n[:2] not in ("02", "11")], os.path.join(TMP, "e_r_mech.png"), ((165, -175, 190), (8, -25, 2)))
anchors = {"동기축 Ø6 (새 부품 24)": (X, -25, L.AXLE_Z + 3), "앞 피니언 + 랙\n(베이스 앞 레일)": (X, 20.3, 16), "뒤 피니언 + 랙\n(레일 23, 새로)": (X, -68.2, 16),
           "굴림 링이 띠 위를 구름": (X, 18.4, 10), "요크: 축에 얹힘\n(받침 2곳)": (X + 7, -40, 10.7), "메인기어 + 크랭크 (v47)": (-25, -23, 6)}
px = {k: sc.to_display(v) for k, v in anchors.items()}
offs = {"동기축 Ø6 (새 부품 24)": (-60, -190), "앞 피니언 + 랙\n(베이스 앞 레일)": (230, -150), "뒤 피니언 + 랙\n(레일 23, 새로)": (-260, -40),
        "굴림 링이 띠 위를 구름": (260, -40), "요크: 축에 얹힘\n(받침 2곳)": (240, 120), "메인기어 + 크랭크 (v47)": (-200, 150)}
fig, ax = plt.subplots(figsize=(18, 11.5), dpi=100)
ax.imshow(mpimg.imread(os.path.join(TMP, "e_r_mech.png"))); ax.axis("off")
for k, (x, y) in px.items():
    dx, dy = offs[k]
    ax.annotate(k, (x, y), (x + dx, y + dy), fontsize=13, ha="center", va="center", arrowprops=dict(arrowstyle="-", color="#333"),
                bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="#999"))
ax.set_title("E안 (상판·다이얼 제거): 요크 양 끝을 한 축의 피니언 2개가 랙에 물려 잡음 → 비틀림을 기어가 받음", fontsize=15, loc="left")
fig.tight_layout(); fig.savefig(os.path.join(IMG, "E_mechanism.png")); plt.close(fig)
print("render ok", flush=True)

# ---------------------------------------------------------------- 2. drawer effect
fig = plt.figure(figsize=(21, 9), dpi=100)
gs = fig.add_gridspec(1, 2, width_ratios=[1.05, 1])
ax = fig.add_subplot(gs[0, 0])
for nm, S, col_y in (("D", D, "#d03030"),):
    pass
zc = 9.0
for n, s in E.items():
    k = n[:2]
    if k not in ("01", "05", "23", "24", "03"):
        continue
    if k == "05":
        s = moved(s, 0, 0, -L.YOKE_FILE_DZ)
    zz = 13.3 if k == "24" else (8.7 if k in ("01", "23") else (10.0 if k == "05" else 3.0))
    for ln in section_lines(s, (0, 0, zz), (0, 0, 1)):
        ax.plot(ln[:, 1], ln[:, 0], color=COL[k], lw=0.6 if k == "03" else 1.2)
BB = dict(boxstyle="round,pad=0.2", fc="white", ec="none", alpha=0.85)
ax.annotate("", (28.5, 10.0), (28.5, 2.5), arrowprops=dict(arrowstyle="-|>", color="#7a3cc0", lw=2.5))
ax.text(28.5, 11.2, "빗살 저항", color="#7a3cc0", ha="center", fontsize=12, bbox=BB)
yr = -52.0
ax.annotate("", (yr, -10.0), (yr, -2.5), arrowprops=dict(arrowstyle="-|>", color="#e08a10", lw=2.5))
ax.text(yr, -13.8, "크랭크가 미는 힘 (되돌아올 때, 뒤쪽)", color="#b06000", ha="center", fontsize=11.5, bbox=BB)
for yy, lab in (((L.F_PIN[0] + L.F_PIN[1]) / 2, "앞 피니언"), ((L.R_PIN[0] + L.R_PIN[1]) / 2, "뒤 피니언")):
    ax.plot([yy], [0], "o", color="#1f5fd0", ms=11)
    ax.text(yy + (5 if yy < 0 else -5), 2.2, lab, color="#1f5fd0", ha="left" if yy < 0 else "right", fontsize=12, bbox=BB)
ax.annotate("", (20.35, 15.0), (-68.2, 15.0), arrowprops=dict(arrowstyle="<->", color="#1f5fd0", lw=1.8))
ax.text(-24, 16.3, "E: 비틀림을 받는 팔 88.6mm (기어, 구름 접촉)", color="#1f5fd0", ha="center", fontsize=12.5, bbox=BB)
ax.annotate("", (15.0, -7), (15.0, 7), arrowprops=dict(arrowstyle="<->", color="#d03030", lw=1.8))
ax.text(13.0, -10.5, "v47·D: 레일에 닿는 폭 14mm (미끄럼 접촉)", color="#d03030", fontsize=12, ha="right", bbox=BB)
ax.set_aspect("equal"); ax.set_xlim(-76, 33); ax.set_ylim(-16, 19); ax.grid(True, lw=0.3, alpha=0.4)
ax.set_xlabel("Y (mm)"); ax.set_ylabel("X (mm)")
ax.set_title("힘의 길: 빗살을 튕길 때 요크를 비트는 힘을 누가 받나", loc="left", fontsize=13.5)
ax = fig.add_subplot(gs[0, 1])
dd = ST["D"]; ee = ST["E"]
xs_fwd = [r[1] for r in dd if r[2] > MAIN_C[1]]; xs_ret = [r[1] for r in dd if r[2] <= MAIN_C[1]]
def val(r):
    return 30.0 if r[3] == "inf" else min(float(r[3]), 30.0)
fwd = sorted([(r[1], val(r)) for r in dd if r[2] > MAIN_C[1]]); ret = sorted([(r[1], val(r)) for r in dd if r[2] <= MAIN_C[1]])
efwd = sorted([(r[1], r[3]) for r in ee if r[2] > MAIN_C[1]]); eret = sorted([(r[1], r[3]) for r in ee if r[2] <= MAIN_C[1]])
ax.plot(*zip(*fwd), color="#d03030", lw=2, label="D (v47도 같은 구조): 갈 때")
ax.plot(*zip(*ret), color="#d03030", lw=2, ls="--", label="D: 되돌아올 때")
ax.fill_between([p[0] for p in ret], [p[1] for p in ret], 30, where=[p[1] >= 30 for p in ret], color="#d03030", alpha=0.12)
ax.plot(*zip(*efwd), color="#1f5fd0", lw=2.4, label="E: 갈 때")
ax.plot(*zip(*eret), color="#1f5fd0", lw=2.4, ls="--", label="E: 되돌아올 때")
ax.text(0, 27.5, "D 되돌아올 때: 이론상 서랍처럼 걸림 (힘 무한대)\n최악의 접촉 조합, 마찰계수 0.3", ha="center", color="#a02020", fontsize=12)
ax.text(0, 3.2, "E: 최대 %.2f배" % ST["summary"]["E_max"], ha="center", color="#1f5fd0", fontsize=13)
ax.set_ylim(0, 31); ax.set_xlim(-29, 29); ax.grid(True, lw=0.3)
ax.set_xlabel("화살표 위치 x (mm), 빗살 구간"); ax.set_ylabel("필요한 미는 힘 ÷ 빗살 저항")
ax.legend(loc="center left", fontsize=11)
ax.set_title("요크를 미는 데 필요한 힘 (정역학 계산)", loc="left", fontsize=13.5)
fig.tight_layout(); fig.savefig(os.path.join(IMG, "E_drawer_effect.png")); plt.close(fig)
print("drawer ok", flush=True)

# ---------------------------------------------------------------- 3. mesh sections
S = dict(E); S["05_Yoke"] = moved(E["05_Yoke"], 0, 0, -L.YOKE_FILE_DZ); S["25_Arrow"] = moved(E["25_Arrow"], 0, 0, -L.YOKE_FILE_DZ)
fig, axs = plt.subplots(2, 2, figsize=(20, 15), dpi=100)
jobs = [((0, (L.F_PIN[0] + L.F_PIN[1]) / 2, 0), (0, 1, 0), (0, 2), (-12, 12, 6, 23), "앞 피니언 단면 (y=20.35): 베이스 앞 레일의 랙에 물림, 백래시 0.16"),
        ((0, (L.F_RING[0] + L.F_RING[1]) / 2, 0), (0, 1, 0), (0, 2), (-12, 12, 6, 23), "앞 굴림 링 단면: Ø8 링이 피치선 높이의 띠(z 9.3) 위를 구름"),
        ((0, (L.R_PIN[0] + L.R_PIN[1]) / 2, 0), (0, 1, 0), (0, 2), (-14, 14, -0.5, 23), "뒤 피니언 단면: 레일 23의 랙, 아래는 손잡이 기어 (틈 0.45)"),
        ((0, -40, 0), (0, 1, 0), (0, 2), (-12, 12, 4, 23), "가운데 단면: 축은 롤러 위 0.3, 상판 아래 1.1")]
for ax, (o, nrm, a, w, t) in zip(axs.flat, jobs):
    for n, s in S.items():
        k = n[:2]
        if k not in COL:
            continue
        for ln in section_lines(s, o, nrm):
            ax.plot(ln[:, a[0]], ln[:, a[1]], color=COL[k], lw=1.3)
    ax.set_aspect("equal"); ax.set_xlim(w[0], w[1]); ax.set_ylim(w[2], w[3]); ax.grid(True, lw=0.3, alpha=0.5)
    ax.set_title(t, loc="left", fontsize=12.5)
fig.text(0.01, 0.005, "파랑: 동기축 · 빨강: 요크 · 회색: 베이스 · 검정: 레일 23 · 초록: 상판 · 주황/노랑: 기어 · 분홍: 롤러", fontsize=11)
fig.tight_layout(rect=(0, 0.02, 1, 1)); fig.savefig(os.path.join(IMG, "E_sections.png")); plt.close(fig)
print("sections ok", flush=True)

# ---------------------------------------------------------------- 4. comparison
F = VA["freedom"]
fv, fd, fe = F["v47"]["0"], F["D"]["0"], F["E"]["0"]
ye = max(F["E"][k]["yaw+"] for k in F["E"])
yr_ = F["E"]["0"]["yoke yaw vs axle +"]
fig, axs = plt.subplots(1, 4, figsize=(22, 6), dpi=100)
ax = axs[0]
ax.bar([0, 1], [fv["yaw+"], fd["yaw+"]], color=["#bbbbbb", "#e09090"], width=0.6)
ax.bar([2], [ye], color="#1f5fd0", width=0.6); ax.bar([2], [yr_], bottom=[ye], color="#8fb3ee", width=0.6)
for i, v in enumerate((fv["yaw+"], fd["yaw+"], ye + yr_)):
    ax.text(i, v + 0.03, "±%.2f°" % v, ha="center", fontsize=12)
ax.text(2, ye / 2, "기어", ha="center", color="white", fontsize=10); ax.text(2, ye + yr_ / 2, "받침", ha="center", fontsize=10)
ax.set_xticks([0, 1, 2]); ax.set_xticklabels(["v47", "D", "E"], fontsize=12); ax.set_title("요크 비틀림 (최대)", fontsize=13)
ax = axs[1]
ax.bar([0, 1, 2], [(fv["+y"] + fv["-y"]) / 2, (fd["+y"] + fd["-y"]) / 2, (fe["+y"] + fe["-y"]) / 2], color=["#bbbbbb", "#e09090", "#1f5fd0"], width=0.6)
for i, v in enumerate(((fv["+y"] + fv["-y"]) / 2, (fd["+y"] + fd["-y"]) / 2, (fe["+y"] + fe["-y"]) / 2)):
    ax.text(i, v + 0.004, "±%.2f" % v, ha="center", fontsize=12)
ax.set_xticks([0, 1, 2]); ax.set_xticklabels(["v47", "D", "E"], fontsize=12); ax.set_title("앞뒤 흔들림 (mm) → 물림 깊이", fontsize=13)
ax = axs[2]
gt = VA["main_gear_tilt_deg"]
gd, ge = max(gt["D"].values()), max(gt["E"].values())
ax.bar([0, 1], [gd, ge], color=["#e09090", "#1f5fd0"], width=0.6)
for i, v in enumerate((gd, ge)):
    ax.text(i, v + 0.04, "%.2f°" % v, ha="center", fontsize=12)
ax.set_xticks([0, 1]); ax.set_xticklabels(["v47 / D", "E"], fontsize=12); ax.set_title("메인기어 축 기울기 (최대)", fontsize=13)
ax = axs[3]
ax.bar([0], [10], color="#e09090", width=0.6, hatch="//"); ax.text(0, 10.3, "∞ (걸림 가능)", ha="center", fontsize=12, color="#a02020")
ax.bar([1], [ST["summary"]["E_max"]], color="#1f5fd0", width=0.6); ax.text(1, ST["summary"]["E_max"] + 0.3, "%.2f배" % ST["summary"]["E_max"], ha="center", fontsize=12)
ax.set_ylim(0, 12); ax.set_xticks([0, 1]); ax.set_xticklabels(["v47 / D", "E"], fontsize=12); ax.set_title("미는 힘 ÷ 빗살 저항 (최악)", fontsize=13)
fig.suptitle("v47 · D · E 비교 (CAD 실측 + 정역학 계산)", fontsize=14)
fig.tight_layout(); fig.savefig(os.path.join(IMG, "E_compare.png")); plt.close(fig)
print("figs done")
