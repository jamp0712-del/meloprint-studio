# -*- coding: utf-8 -*-
# Planar statics of the yoke while a tine is being plucked (drawer effect).
# D / v47: the yaw moment F_p*(y_pick - y_roller) is resisted by y-contacts at the yoke corners (x = +-7, arm 14 mm)
#          whose friction acts along x at the guide positions -> required drive force, or self-locking (jam).
# E:       the yaw moment is a couple of the two pinions on one axle (88.55 mm apart, rolling): no guide reaction;
#          losses are the cradle friction of the turning axle and the hold-down friction from the separating force.
import math, json, itertools
import numpy as np

MU = 0.30                      # PLA on PLA, dry (0.25..0.35)
Y_PICK = 28.5
MAIN_Y, ECC = -23.218, 36.064
HALF_W = 7.0
# D guide faces: (+y side of the yoke touches)  front beam ends 17.60, rear lip -70.95
#                (-y side of the yoke touches)  front legs 21.60,      rear step -67.40
PLUS_SIDE = {"front": 17.60, "rear": -70.95}
MINUS_SIDE = {"front": 21.60, "rear": -67.40}
Y_PIN_F, Y_PIN_R = 20.35, -68.20
RP, R_AXLE = 4.0, 3.0
TAN_PA = math.tan(math.radians(20.0))


def d_case(th_deg):
    """Worst drive-force ratio F_d/F_p over the possible guide-contact pairs (inf = self-locking)."""
    th = math.radians(th_deg)
    y_r = MAIN_Y + ECC * math.cos(th)
    v = 1.0 if math.cos(th) > 0 else -1.0          # forward stroke when the roller is in front of the main axle
    worst = 0.0
    for g1, g2 in itertools.product(("front", "rear"), repeat=2):
        # rotation sense of the applied moment decides which faces close
        if v > 0:      # CCW: +7 corner presses a +y-side face, -7 corner a -y-side face
            y1, y2 = PLUS_SIDE[g1], MINUS_SIDE[g2]
        else:          # CW
            y1, y2 = MINUS_SIDE[g1], PLUS_SIDE[g2]
        bracket = 2 * HALF_W - MU * ((y1 - y_r) + (y2 - y_r))
        if bracket <= 0:
            return float("inf"), y_r
        n = (Y_PICK - y_r) / bracket           # per unit pluck force
        worst = max(worst, 1.0 + 2 * MU * n)
    return worst, y_r


def e_case(th_deg):
    th = math.radians(th_deg)
    y_r = MAIN_Y + ECC * math.cos(th)
    f1 = abs(Y_PICK - y_r) / (Y_PIN_F - Y_PIN_R)          # pinion couple force per unit pluck force
    cradle = 2 * MU * f1 * R_AXLE / RP                      # axle turning in two loaded cradles
    holddown = 2 * MU * f1 * TAN_PA                          # separating force pressing the yoke on the cover
    return 1.0 + cradle + holddown, y_r, f1


out = {"mu": MU, "D": [], "E": []}
for th in np.arange(-180, 180.01, 1.0):
    x = ECC * math.sin(math.radians(th))
    if abs(x) > 28.7:                                       # tine zone only
        continue
    d, yr = d_case(th)
    e, _, f1 = e_case(th)
    out["D"].append((float(th), round(x, 2), round(yr, 2), d if d != float("inf") else "inf"))
    out["E"].append((float(th), round(x, 2), round(yr, 2), round(e, 3), round(f1, 3)))
fin = [r[3] for r in out["D"] if r[3] != "inf"]
out["summary"] = {"D_self_locking_angles": sum(1 for r in out["D"] if r[3] == "inf"),
                  "D_angles_checked": len(out["D"]), "D_max_finite": round(max(fin), 2) if fin else None,
                  "E_max": round(max(r[3] for r in out["E"]), 3),
                  "D_guide_arm_mm": 2 * HALF_W, "E_couple_arm_mm": round(Y_PIN_F - Y_PIN_R, 2)}
json.dump(out, open(r"C:\Users\Public\mbx_work\in\e_statics.json", "w"), indent=0)
print(out["summary"])
for mu in (0.2, 0.25, 0.3, 0.35):
    MU = mu
    dd = [d_case(th)[0] for th in np.arange(-180, 180.01, 1.0) if abs(ECC * math.sin(math.radians(th))) <= 28.7]
    ee = [e_case(th)[0] for th in np.arange(-180, 180.01, 1.0) if abs(ECC * math.sin(math.radians(th))) <= 28.7]
    print("mu %.2f  D: self-lock %d/%d, max finite %.1f   E max %.2f" % (mu, sum(1 for d in dd if d == float("inf")), len(dd),
                                                                       max(d for d in dd if d != float("inf")), max(ee)))
