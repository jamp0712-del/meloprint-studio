# -*- coding: utf-8 -*-
# Concept E validation: yoke freedom (v47 / D / E), rack-pinion mesh over the stroke, backlash, pluck depth, tines,
# crank sweep interference, main gear tilt (D vs E), fasteners, assembly paths, positive controls.
# Usage: e_validate.py <ap1|mw4> [quick]
import sys, math, json, time
sys.path.insert(0, r"C:\Users\Public\mbx_work")
import numpy as np
import manifold3d as m3
from ap1_view import load_cache
from mf_tool import to_manifold, xf_rotate, xf_translate, compose
from pf2_kin import part_xf, MAIN_C, ECC
import c_case as CC
import e_layout as L

t0 = time.time()
VAR = sys.argv[1] if len(sys.argv) > 1 else "ap1"
QUICK = len(sys.argv) > 2
YDZ = -L.YOKE_FILE_DZ
R = {}


def load(src, rename=None, defl=0.005):
    S = load_cache(src)
    return {(rename(n) if rename else n): to_manifold(s, defl) for n, s in S.items()}


E = load(r"C:\Users\Public\mbx_work\in\e_brep_%s" % VAR)
E["24_SyncAxle"] = to_manifold(load_cache(r"C:\Users\Public\mbx_work\in\e_brep_%s" % VAR)["24_SyncAxle"], 0.002)
# 25 arrow: press fit into the yoke front block (checked here), then it moves as one unit with the yoke
ARROW, YOKE_ONLY = E.pop("25_Arrow", None), E["05_Yoke"]
_fit = YOKE_ONLY ^ ARROW if ARROW is not None else None
R["arrow_press_fit"] = None if ARROW is None else {"interference_mm3 (2 crush ribs, expect ~0.4)": round(_fit.volume(), 3),
                        "interference bbox": [round(v, 2) for v in _fit.bounding_box()] if _fit.volume() > 0 else None,
                        "arrow lowered 0.05 more (seat on the yoke top) mm3": round((YOKE_ONLY ^ ARROW.translate((0, 0, -0.05))).volume(), 3),
                        "arrow lifted 0.3 mm3 (ribs only)": round((YOKE_ONLY ^ ARROW.translate((0, 0, 0.3))).volume(), 3)}
print("arrow press fit", R["arrow_press_fit"], flush=True)
if ARROW is not None:
    E["05_Yoke"] = YOKE_ONLY + ARROW
for k in ("01_Base", "23_RearGuideRail"):        # racks: finer tessellation not needed (planar), keep 0.005
    pass
HW = {n: to_manifold(s, 0.005) for n, s in load_cache(r"C:\Users\Public\mbx_work\in\e_hw").items()}
D = load(r"C:\Users\Public\mbx_work\in\d_brep_%s" % VAR)
V47 = load(r"C:\Users\Public\mbx_work\in\pf2v47_brep" if VAR == "ap1" else r"C:\Users\Public\mbx_work\in\pf2v47mw4_brep",
           lambda n: n.replace("_AP1", "").replace("_MW4", "").replace("11_HandleRetainer", "11_Dial").replace("04_Handle_AP1", "04_Handle"))
print("loaded %.0fs" % (time.time() - t0), flush=True)
ROT_HW = ("HW_M3x5_Dial",)
# the only bought parts are 6 x M3x5; each threads into a printed D2.6 pilot
THREAD = dict([("HW_M3x5_Case_%d" % i, "01_Base") for i in range(1, 5)] + [("HW_M3x5_Rail", "23_RearGuideRail"), ("HW_M3x5_Dial", "04_Handle")])


def axle_xf(th):
    X = ECC * math.sin(math.radians(th))
    return compose(xf_translate(X, 0, 0), xf_rotate(math.degrees(X / L.RP), (0, 0, L.AXLE_Z), (0, 1, 0)))


def pose(M, th, hw=True):
    P = {}
    for n, m in M.items():
        if n.startswith("24"):
            P[n] = m.transform(axle_xf(th))
            continue
        xf = part_xf(n, th)
        mm = m.transform(xf) if xf is not None else m
        if n.startswith("05"):
            mm = mm.translate((0, 0, YDZ))
        P[n] = mm
    if hw:
        for n, m in HW.items():
            P[n] = m.transform(part_xf("04", th)) if n in ROT_HW else m
    return P


def mbox(x0, y0, z0, x1, y1, z1):
    return m3.Manifold.cube((x1 - x0, y1 - y0, z1 - z0)).translate((x0, y0, z0))


def vol(a, b):
    A, B = a.bounding_box(), b.bounding_box()
    if not all(A[i] - 0.05 <= B[i + 3] and B[i] - 0.05 <= A[i + 3] for i in range(3)):
        return 0.0
    return (a ^ b).volume()


def bisect(hit, maxd, it=20):
    if not hit(maxd):
        return maxd
    lo, hi = 0.0, maxd
    for _ in range(it):
        mid = (lo + hi) / 2
        if hit(mid):
            hi = mid
        else:
            lo = mid
    return round(lo, 3)


# ---------------------------------------------------------------- 1. yoke freedom (moving unit = yoke [+ axle])
def freedom(M, th):
    P = pose(M, th, hw=False)
    unit = P["05_Yoke"] + P["24_SyncAxle"] if "24_SyncAxle" in P else P["05_Yoke"]
    others = [P[n] for n in P if n[:2] not in ("05", "15", "16", "24")]
    t = math.radians(th)
    rx, ry = ECC * math.sin(t), MAIN_C[1] + ECC * math.cos(t)
    X = rx

    def free(move, maxd):
        return bisect(lambda d: any(vol(move(d), o) > 1e-4 for o in others), maxd)
    r = {"+y": free(lambda d: unit.translate((0, d, 0)), 2.0), "-y": free(lambda d: unit.translate((0, -d, 0)), 2.0),
         "lift": free(lambda d: unit.translate((0, 0, d)), 2.0),
         "yaw+": free(lambda a: unit.transform(xf_rotate(a, (rx, ry, 9.0), (0, 0, 1))), 4.0),
         "yaw-": free(lambda a: unit.transform(xf_rotate(-a, (rx, ry, 9.0), (0, 0, 1))), 4.0)}
    if "24_SyncAxle" in P:
        # yoke alone relative to the axle (cradle play) and roll about the axle line, measured with the yoke lifted
        # 0.09 (up against the cover hold-down): resting on the axle the cradle top is tangent and any test hits at 0
        Y, A = P["05_Yoke"].translate((0, 0, 0.09)), P["24_SyncAxle"]
        oth_y = others + [A]
        r["yoke yaw vs axle +"] = bisect(lambda a: any(vol(Y.transform(xf_rotate(a, (X, -25.0, L.AXLE_Z), (0, 0, 1))), o) > 1e-4 for o in oth_y), 4.0)
        r["yoke x vs axle +"] = bisect(lambda d: any(vol(Y.translate((d, 0, 0)), o) > 1e-4 for o in oth_y), 1.0)
        r["roll about axle +"] = bisect(lambda a: any(vol(Y.transform(xf_rotate(a, (X, 0, L.AXLE_Z), (0, 1, 0))), o) > 1e-4 for o in oth_y), 4.0)
        r["roll about axle -"] = bisect(lambda a: any(vol(Y.transform(xf_rotate(-a, (X, 0, L.AXLE_Z), (0, 1, 0))), o) > 1e-4 for o in oth_y), 4.0)
    return r


R["freedom"] = {}
for nm, M in (("v47", V47), ("D", D), ("E", E)):
    R["freedom"][nm] = {th: freedom(M, th) for th in ((0,) if QUICK else (0, 90, 180))}
    print("freedom", nm, R["freedom"][nm], "%.0fs" % (time.time() - t0), flush=True)

# ---------------------------------------------------------------- 2. rack-pinion mesh over the whole stroke + backlash
mesh = {"max_interference": 0.0, "at": None, "ring_strip_max": 0.0}
for th in np.arange(0, 360, 2.0 if QUICK else 0.5):
    P = pose(E, th, hw=False)
    A = P["24_SyncAxle"]
    for n in ("01_Base", "23_RearGuideRail"):
        v = vol(A, P[n])
        if v > mesh["max_interference"]:
            mesh["max_interference"], mesh["at"] = round(v, 5), (float(th), n)
mesh["max_interference"] = round(mesh["max_interference"], 5)


def backlash(th):
    P = pose(E, th, hw=False)
    A = P["24_SyncAxle"]
    X = ECC * math.sin(math.radians(th))
    racks = [P["01_Base"], P["23_RearGuideRail"]]
    out = []
    for s in (1, -1):
        out.append(bisect(lambda a: any(vol(A.transform(xf_rotate(s * a, (X, 0, L.AXLE_Z), (0, 1, 0))), o) > 1e-4 for o in racks), 10.0))
    return round(math.radians(out[0] + out[1]) * L.RP, 3), out


mesh["backlash_linear_mm"] = {th: backlash(th) for th in ((0,) if QUICK else (0, 37, 90, 151, 222, 300))}
R["mesh"] = mesh
print("mesh", mesh, "%.0fs" % (time.time() - t0), flush=True)

# ---------------------------------------------------------------- 3. pluck depth for every tine under the y freedom
P0 = pose(E, 0.0)
yoke0 = P0["05_Yoke"]
cl, cu = P0["15_CombLower"], P0["16_CombUpper"]


def depth(M_yoke, dy):
    best = 0.0
    for x in np.linspace(-6, 6, 61):
        c = M_yoke.translate((x, dy, 0))
        for comb in (cl, cu):
            i = c ^ comb
            if i.volume() > 1e-6:
                b = i.bounding_box()
                best = max(best, b[4] - b[1])
    return round(best, 3)


fy = R["freedom"]["E"]
dyp = min(v["+y"] for v in fy.values()); dym = min(v["-y"] for v in fy.values())
R["pluck_depth"] = {"E": {"nominal": depth(yoke0, 0), "toward comb (+%.2f)" % dyp: depth(yoke0, dyp), "away (-%.2f)" % dym: depth(yoke0, -dym)}}
print("pluck depth", R["pluck_depth"], flush=True)

# ---------------------------------------------------------------- 4. every tine plucked over one crank turn
tip = yoke0 ^ mbox(-20, 28.0, -5, 20, 30, 30)
tb = tip.bounding_box()
cov = {}
for cn, comb in (("15_CombLower", cl), ("16_CombUpper", cu)):
    tines = comb ^ mbox(-45, 28.2, -5, 45, 28.9, 30)
    iv = sorted([(k.bounding_box()[0], k.bounding_box()[3]) for k in tines.decompose() if k.volume() > 1e-4])
    hit = set()
    for k in range(360):
        dx = ECC * math.sin(math.radians(k))
        it = yoke0.translate((dx, 0, 0)) ^ comb
        if it.volume() > 1e-5:
            for comp in it.decompose():
                b = comp.bounding_box(); xm = 0.5 * (b[0] + b[3])
                for j, (a0, a1) in enumerate(iv):
                    if a0 - 0.2 <= xm <= a1 + 0.2:
                        hit.add(j)
    cov[cn] = {"tines": len(iv), "plucked": len(hit), "pass_margin": [round(iv[0][0] - (-ECC + tb[0]), 2), round((ECC + tb[3]) - iv[-1][1], 2)]}
R["tines"] = cov
print("tines", cov, flush=True)

# ---------------------------------------------------------------- 5. crank sweep interference (all parts)
FIT = {("23_RearGuideRail", "HW_M3x5_Rail")}             # thread engagement (checked in section 7)
SAME = [{"04_Handle", "11_Dial", "HW_M3x5_Dial"}]
worst = {}
for th in range(0, 360, 6 if QUICK else 3):
    P = pose(E, th)
    names = sorted(P)
    for a_i in range(len(names)):
        for b_i in range(a_i + 1, len(names)):
            a, b = names[a_i], names[b_i]
            if any(a in s and b in s for s in SAME):
                continue
            if {a[:2], b[:2]} <= {"01", "02", "15", "16", "23"} or (a.startswith("HW_M3") and b.startswith("HW_M3")):
                continue
            if "Case" in a or "Case" in b:
                continue
            v = vol(P[a], P[b])
            if v > 1e-3:
                key = a + " x " + b
                if key not in worst or v > worst[key][0]:
                    worst[key] = (round(v, 4), th)
DES = {"05_Yoke x 15_CombLower": "pluck", "05_Yoke x 16_CombUpper": "pluck", "05_Yoke x 24_SyncAxle": "yoke rests on the axle (tangent line contact)"}
R["sweep"] = {"designed": {k: v for k, v in worst.items() if k in DES or tuple(k.split(" x ")) in FIT},
              "other": {k: v for k, v in worst.items() if k not in DES and tuple(k.split(" x ")) not in FIT}}
print("sweep designed", R["sweep"]["designed"])
print("sweep OTHER", R["sweep"]["other"], "%.0fs" % (time.time() - t0), flush=True)

# ---------------------------------------------------------------- 6. main gear tilt freedom, D vs E
def gear_tilt(M):
    P = pose(M, 0.0, hw=False)
    G = P["03_MainGear"]
    others = [P["01_Base"], P["10_MainRetainer"], P["04_Handle"]]
    out = {}
    for nm, ax in (("about x", (1, 0, 0)), ("about y", (0, 1, 0))):
        for s in (1, -1):
            out["%s %s" % (nm, "+" if s > 0 else "-")] = bisect(
                lambda a: any(vol(G.transform(xf_rotate(s * a, (MAIN_C[0], MAIN_C[1], 1.85), ax)), o) > 1e-4 for o in others), 4.0)
    return out


R["main_gear_tilt_deg"] = {"D": gear_tilt(D), "E": gear_tilt(E)}


def axial_play():
    P = pose(E, 0.0)
    main = P["03_MainGear"]                                 # crank pin is part of the gear
    unit = P["04_Handle"] + P["11_Dial"] + P["HW_M3x5_Dial"]
    fixed_m = [P[n] for n in ("01_Base", "10_MainRetainer", "02_Cover", "05_Yoke", "24_SyncAxle")]
    fixed_h = [P[n] for n in ("01_Base", "02_Cover", "23_RearGuideRail", "05_Yoke")]
    f = lambda mv, others, s: bisect(lambda d: any(vol(mv.translate((0, 0, s * d)), o) > 1e-4 for o in others), 2.0)
    return {"main gear up (clip)": f(main, fixed_m, 1), "main gear down (pad ring)": f(main, fixed_m, -1),
            "handle unit up (dial collar)": f(unit, fixed_h, 1), "handle unit down (printed thrust ring)": f(unit, fixed_h, -1)}


R["gear_axial_play_mm"] = axial_play()
print("gear axial play", R["gear_axial_play_mm"], flush=True)
print("main gear tilt", R["main_gear_tilt_deg"], flush=True)

# ---------------------------------------------------------------- 7. fasteners at home
P = pose(E, 0)
st, clash = {}, {}
for a, tp in THREAD.items():
    for b in ("01_Base", "02_Cover", "04_Handle", "11_Dial", "23_RearGuideRail"):
        k = P[a] ^ P[b]
        if k.volume() > 1e-3:
            bb = k.bounding_box()
            if b == tp:
                st[a] = {"threads into": b, "engagement_mm": round(bb[5] - bb[2], 2), "bite_mm3": round(k.volume(), 2)}
            else:
                clash[a + " x " + b] = round(k.volume(), 4)
R["fasteners"] = {"thread": st, "clash": clash}
print("fasteners thread", st, flush=True)
print("fasteners clash", clash if clash else "none", flush=True)
# printed journal of the handle gear: radial play and tilt on the base post
_g = P["04_Handle"]; _o = [P["01_Base"]]
R["handle_journal"] = {"x play +": bisect(lambda d: vol(_g.translate((d, 0, 0)), P["01_Base"]) > 1e-4, 1.0),
                       "tilt about x +": bisect(lambda a: vol(_g.transform(xf_rotate(a, (0.0, -80.544, 8.0), (1, 0, 0))), P["01_Base"]) > 1e-4, 4.0)}
print("handle journal", R["handle_journal"], flush=True)

# ---------------------------------------------------------------- 8. assembly paths
def path(mov, vec, inst, steps=40, tol=0.01):
    hits = []
    for k in range(steps + 1):
        t = 1.0 - k / float(steps)
        m2 = mov.translate((vec[0] * t, vec[1] * t, vec[2] * t))
        for n, o in inst.items():
            v = vol(m2, o)
            if v > tol:
                hits.append((round(t, 3), n, round(v, 3)))
    return hits


paths = {}
inst = {"01_Base": P["01_Base"]}
paths["04 gear onto the printed post"] = path(P["04_Handle"], (0, 0, 40), inst)
inst.update({"04_Handle": P["04_Handle"]})
import e_helical as HX
K_MAIN = HX.ARC / (HX.FACE * HX.radii(60)[0])          # rad per mm of descent (helical teeth screw in)


def path_screw(mov, height, inst, steps=80, tol=0.01):
    hits = []
    for k in range(steps + 1):
        t = 1.0 - k / float(steps)
        dz = height * t
        m2 = mov.transform(xf_rotate(math.degrees(-K_MAIN * dz), (MAIN_C[0], MAIN_C[1], 0), (0, 0, 1))).translate((0, 0, dz))
        for n, o in inst.items():
            v = vol(m2, o)
            if v > tol:
                hits.append((round(t, 3), n, round(v, 3)))
    return hits


paths["03 main gear (helical: turn %.2f deg per mm while lowering)" % math.degrees(K_MAIN)] = path_screw(P["03_MainGear"], 35, inst); inst["03"] = P["03_MainGear"]
paths["10 clip"] = path(P["10_MainRetainer"], (0, 0, 15), inst, tol=0.5); inst["10"] = P["10_MainRetainer"]
paths["23 rail lowered (pins into the base)"] = path(P["23_RearGuideRail"], (0, 0, 30), inst)
inst["23"] = P["23_RearGuideRail"]
paths["rail screw M3x5 from below (all but its own pilot)"] = path(P["HW_M3x5_Rail"], (0, 0, -12), {k: v for k, v in inst.items() if k != "23"})
inst["rscrew"] = P["HW_M3x5_Rail"]
Q = pose(E, 45.0)
inst45 = {k: v for k, v in inst.items()}
inst45["03"] = Q["03_MainGear"]
paths["24 sync axle lowered onto both racks (crank 45)"] = path(Q["24_SyncAxle"], (0, 0, 25), inst45); inst45["24"] = Q["24_SyncAxle"]
paths["05 yoke lowered onto the axle and roller (crank 45)"] = path(Q["05_Yoke"], (0, 0, 35), inst45)
inst["24"] = P["24_SyncAxle"]; inst["05"] = P["05_Yoke"]
paths["02 cover lowered (arrow centred)"] = path(P["02_Cover"], (0, 0, 35), inst); inst["02"] = P["02_Cover"]
if ARROW is not None:
    _ar = ARROW.translate((0, 0, YDZ))
    paths["25 arrow pressed in through the window (all but the yoke)"] = path(_ar, (0, 0, 15), {k: v for k, v in inst.items() if k != "05"})
    paths["25 arrow vs yoke along the press (ribs only, tol 0.6)"] = path(_ar, (0, 0, 15), {"05 alone": YOKE_ONLY.translate((0, 0, YDZ))}, tol=0.6)
for i in range(4):
    paths["case screw M3x5 %d (all but its own pilot)" % (i + 1)] = path(P["HW_M3x5_Case_%d" % (i + 1)], (0, 0, 20), {k: v for k, v in inst.items() if k != "01_Base"})
paths["11 dial onto the gear hex"] = path(P["11_Dial"], (0, 0, 30), {k: v for k, v in inst.items() if k != "04_Handle"})
paths["dial screw M3x5 (through the dial)"] = path(P["HW_M3x5_Dial"], (0, 0, 20), {"11": P["11_Dial"]})
R["paths"] = {k: (len(v), v[:3]) for k, v in paths.items()}
for k, v in paths.items():
    print("  path %-52s hits %d %s" % (k, len(v), v[:3]))

# ---------------------------------------------------------------- 9. positive controls
A, Y = P["24_SyncAxle"], P["05_Yoke"]
ctl = {"yoke+axle yawed 0.5 deg vs racks": round(sum(vol((Y + A).transform(xf_rotate(0.5, (0, -25, 9), (0, 0, 1))), P[n]) for n in ("01_Base", "23_RearGuideRail")), 3),
       "axle slid 0.3 in x without turning vs racks": round(sum(vol(A.translate((0.3, 0, 0)), P[n]) for n in ("01_Base", "23_RearGuideRail")), 3),
       "rail 23 shifted 0.3 in x vs axle": round(vol(P["23_RearGuideRail"].translate((0.3, 0, 0)), A), 3),
       "yoke 0.25 toward the comb vs front rail": round(vol(Y.translate((0, 0.25, 0)), P["01_Base"]), 3),
       "yoke 0.25 back vs rail 23": round(vol(Y.translate((0, -0.25, 0)), P["23_RearGuideRail"]), 3),
       "yoke lifted 0.2 vs cover": round(vol(Y.translate((0, 0, 0.2)), P["02_Cover"]), 3),
       "main gear tilted 1 deg vs base pad": round(vol(P["03_MainGear"].transform(xf_rotate(1.0, (MAIN_C[0], MAIN_C[1], 1.85), (1, 0, 0))), P["01_Base"]), 3),
       "main gear turned 3 deg vs handle gear": round(vol(P["03_MainGear"].transform(xf_rotate(3, (MAIN_C[0], MAIN_C[1], 0), (0, 0, 1))), P["04_Handle"]), 3)}
R["controls"] = ctl
print("controls", ctl)
json.dump(R, open(r"C:\Users\Public\mbx_work\in\e_validate_%s%s.json" % (VAR, "_quick" if QUICK else ""), "w"), indent=1, default=str)
print("done %.0fs" % (time.time() - t0))
