# -*- coding: utf-8 -*-
# Printability audit of the E printed parts in their print orientation: bed contact, unsupported down-facing area
# (overhang steeper than 45 deg, not on the bed) split into connected regions with their span, thin walls (inward ray
# thickness), slenderness. Writes in\e_print_audit.json and overhang maps (red = needs support / bridge).
import sys, os, json, math
sys.path.insert(0, r"C:\Users\Public\mbx_work")
import numpy as np, trimesh
from ap1_view import load_cache
from mf_tool import to_manifold
from c_render import Scene

I3 = np.eye(3)
FLIP_X = np.diag([1.0, -1.0, -1.0])
R_YOKE = np.array([[0, 0, 1], [0, 1, 0], [-1, 0, 0]], float)
R_X90 = np.array([[1, 0, 0], [0, 0, -1], [0, 1, 0]], float)
PR = {"01_Base": I3, "02_Cover": FLIP_X, "03_MainGear": I3, "04_Handle": I3, "05_Yoke": FLIP_X,
      "10_MainRetainer": I3, "11_Dial": FLIP_X, "15_CombLower": I3, "16_CombUpper": FLIP_X, "23_RearGuideRail": R_X90, "24_SyncAxle": R_X90, "25_Arrow": FLIP_X}
OUT = r"C:\Users\Public\mbx_work\img\audit"
os.makedirs(OUT, exist_ok=True)
CRIT = math.cos(math.radians(45.0))          # down-facing normal with nz < -cos45 -> unsupported
BED_TOL = 0.05


def audit(name, shape, R, render=True):
    mm = to_manifold(shape, 0.01).to_mesh()
    V = np.array(mm.vert_properties)[:, :3].astype(float) @ R.T
    V[:, 2] -= V[:, 2].min()
    F = np.array(mm.tri_verts).astype(np.int64)
    t = trimesh.Trimesh(V, F, process=True)
    n, a, c = t.face_normals, t.area_faces, t.triangles_center
    bed = (n[:, 2] < -0.999) & (c[:, 2] < BED_TOL)
    over = (n[:, 2] < -CRIT) & ~bed & (c[:, 2] > BED_TOL)
    horiz = over & (n[:, 2] < -0.985)                      # near-horizontal ceilings: bridges or floating islands
    # connected overhang regions
    regions = []
    if over.any():
        idx = np.where(over)[0]
        sub = t.submesh([idx], append=True)
        for comp in sub.split(only_watertight=False):
            ar = float(comp.area)
            if ar < 0.5:
                continue
            ext = comp.extents
            regions.append({"area_mm2": round(ar, 1), "z": round(float(comp.bounds[0][2]), 2),
                            "span_xy": [round(float(ext[0]), 1), round(float(ext[1]), 1)],
                            "min_span": round(float(min(ext[0], ext[1])), 1), "center": [round(float(v), 1) for v in comp.centroid]})
        regions.sort(key=lambda r: -r["area_mm2"])
    # wall thickness: inward rays from sampled face centres
    rng = np.random.default_rng(1)
    k = min(4000, len(F))
    pick = rng.choice(len(F), k, replace=False, p=a / a.sum())
    import vtk
    from c_render import polydata
    obb = vtk.vtkOBBTree(); obb.SetDataSet(polydata(t.vertices, t.faces)); obb.BuildLocator()
    pts, ids = vtk.vtkPoints(), vtk.vtkIdList()
    thick = np.full(k, np.inf)
    for j, fi in enumerate(pick):
        o = c[fi] - n[fi] * 1e-3
        e = o - n[fi] * 30.0
        if obb.IntersectWithLine(o.tolist(), e.tolist(), pts, ids) and pts.GetNumberOfPoints():
            thick[j] = float(np.linalg.norm(np.array(pts.GetPoint(0)) - o))
    thin = np.sort(thick[np.isfinite(thick)])
    res = {"size_mm": [round(float(v), 1) for v in t.extents], "bed_area_mm2": round(float(a[bed].sum()), 1),
           "overhang_area_mm2": round(float(a[over].sum()), 1), "horizontal_ceiling_mm2": round(float(a[horiz].sum()), 1),
           "regions": regions[:8], "thickness_p1_mm": round(float(thin[int(0.01 * len(thin))]), 2) if len(thin) else None,
           "share_below_0.8mm": round(float((thin < 0.8).mean()), 4) if len(thin) else None,
           "slenderness_h_over_sqrt_bed": round(float(t.extents[2] / max(math.sqrt(max(a[bed].sum(), 1e-6)), 1e-6)), 2)}
    if render:
        cols = np.tile(np.array([200, 205, 212], np.uint8), (len(F), 1))
        cols[over] = (225, 45, 40)
        cols[bed] = (60, 140, 220)
        sc = Scene(1000, 760); sc.lights()
        sc.add(t.vertices, t.faces, cell_colors=cols)
        ctr = t.bounds.mean(axis=0); dia = float(np.linalg.norm(t.extents))
        sc.camera(ctr + np.array([0.6, -1.1, -0.55]) * dia * 1.15, ctr, up=(0, 0, 1), angle=30)
        sc.save(os.path.join(OUT, "%s_below.png" % name))
        sc2 = Scene(1000, 760); sc2.lights(); sc2.add(t.vertices, t.faces, cell_colors=cols)
        sc2.camera(ctr + np.array([0.7, -1.0, 0.8]) * dia * 1.15, ctr, up=(0, 0, 1), angle=30)
        sc2.save(os.path.join(OUT, "%s_above.png" % name))
    return res


if __name__ == "__main__":
    S = load_cache(r"C:\Users\Public\mbx_work\in\e_brep_ap1")
    which = sys.argv[1:] or [n for n in PR if n in S]
    R = {}
    for n in which:
        R[n] = audit(n, S[n], PR[n])
        r = R[n]
        print("%-16s size %-20s bed %7.1f  overhang %7.1f (horiz %6.1f)  thin p1 %s (<0.8: %s)  slender %s" % (
            n, r["size_mm"], r["bed_area_mm2"], r["overhang_area_mm2"], r["horizontal_ceiling_mm2"], r["thickness_p1_mm"],
            r["share_below_0.8mm"], r["slenderness_h_over_sqrt_bed"]), flush=True)
        for g in r["regions"][:4]:
            print("      region area %6.1f  z %5.2f  span %s  centre %s" % (g["area_mm2"], g["z"], g["span_xy"], g["center"]))
    json.dump(R, open(r"C:\Users\Public\mbx_work\in\e_print_audit.json", "w"), indent=1)
