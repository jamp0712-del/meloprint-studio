# -*- coding: utf-8 -*-
# v47 exports (changed parts only): 01 base (AP1, MW4) and 04 handle gear; hardware viewer mesh now includes the 608.
import sys, os, json
sys.argv = [sys.argv[0], r"C:\Users\Public\mbx_work\pf2_out"]
sys.path.insert(0, r"C:\Users\Public\mbx_work")
import numpy as np, trimesh, manifold3d as m3
from ap1_view import load_cache
from mf_tool import to_manifold
from ap1_export import step_write, write_stl
OUT = r"C:\Users\Public\mbx_work\v47_assets"
STEP = r"C:\Users\Public\mbx_work\pf2_out\STEP_v47"
os.makedirs(STEP, exist_ok=True)
AP = load_cache(r"C:\Users\Public\mbx_work\in\pf2v47_brep")
MW = load_cache(r"C:\Users\Public\mbx_work\in\pf2v47mw4_brep")
HW = load_cache(r"C:\Users\Public\mbx_work\in\pf2v47_hw")
ROT = json.load(open(r"C:\Users\Public\mbx_work\print_rot.json"))
rep = {}


def mesh(s, defl=0.004):
    mm = to_manifold(s, defl)
    assert mm.status() == m3.Error.NoError
    mm = mm.to_mesh()
    return np.array(mm.vert_properties)[:, :3].astype(float), np.array(mm.tri_verts).astype(np.int64)


def put(rel, V, F, name):
    p = os.path.join(OUT, rel)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    write_stl(p, V, F, name)
    t = trimesh.load(p)
    rep[rel] = {"tris": int(len(F)), "watertight": bool(t.is_watertight), "volume": round(float(t.volume), 2), "size": [round(float(v), 2) for v in t.extents]}
    print("%-46s %s" % (rel, rep[rel]))


def center(W, y0=False):
    return W - np.array([(W[:, 0].min() + W[:, 0].max()) / 2, W[:, 1].min() if y0 else (W[:, 1].min() + W[:, 1].max()) / 2, W[:, 2].min()])


for n, s in (("01_Base_AP1", AP["01_Base_AP1"]), ("04_Handle_AP1", AP["04_Handle_AP1"]), ("01_Base_MW4", MW["01_Base_MW4"])):
    step_write([(n, s)], os.path.join(STEP, n + ".step"))
    V, F = mesh(s)
    put("assets/pf2/%s.stl" % n, V, F, n)
    if n == "01_Base_AP1":
        put("pkg/print_stl/01_Base_AP1_PRINT.stl", center(V.copy()), F, n)
    elif n == "01_Base_MW4":
        put("pkg_mw4/print_stl/01_Base_MW4_PRINT.stl", center(V.copy()), F, n)
        put("models/01_Base_MW4_PRINT.stl", center(V.copy(), y0=True), F, n)
    else:
        put("pkg/print_stl/04_Handle_AP1.stl", center(V @ np.array(ROT["print_stl/04_Handle_AP1.stl"]["R"], float).T), F, n)
Vs, Fs, off = [], [], 0
for n in sorted(HW):
    V, F = mesh(HW[n], 0.01)
    Vs.append(V); Fs.append(F + off); off += len(V)
put("assets/pf2/M3_Hardware.stl", np.vstack(Vs), np.vstack(Fs), "Hardware")
step_write([(n, HW[n]) for n in sorted(HW)], os.path.join(STEP, "Hardware_M3_608.step"))
json.dump(rep, open(os.path.join(OUT, "export_v47.json"), "w"), indent=1)
