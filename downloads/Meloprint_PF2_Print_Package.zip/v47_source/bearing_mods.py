# -*- coding: utf-8 -*-
# PF2 v47: one 608 skate bearing (8 x 22 x 7) carries the handle gear + dial unit.
#  - 01 base: the D8.8 post becomes a D7.95 stub (z -1.8..5.0) with 3 crush ribs for the inner race, on a 0.25 mm
#    support ring at z -1.8 that only touches the inner race. The post no longer runs through the gear.
#  - 04 handle gear: a D27.2 boss under the teeth disc holds the outer race (D22.2 bore + 6 crush ribs, 1.4 mm ledge on top);
#    above the bearing a 45 deg cone (no bridging) opens into a D7.2 passage for feeding the dial nut from below.
#    The gear's axis is set by the base post, i.e. the same part that carries the main gear, so the gear centre distance
#    does not depend on the cover fit.
#  - 11 dial, M3x8 screw, nut pocket, collar: unchanged from v46.
import sys, math
sys.path.insert(0, r"C:\Users\Public\mbx_work")
from ap1_tool import cyl, cut, fuse
from ap1_mods import revolve_rz, hexagon

CX, CY = 0.0, -80.544
B_ID, B_OD, B_W = 8.0, 22.0, 7.0
B_Z0 = -1.8                       # bearing bottom = gear bottom
B_Z1 = B_Z0 + B_W                 # 5.2
SEAT_R = 11.1                     # 0.1 mm radial clearance + crush ribs
RIB_N, RIB_R, RIB_PROUD = 6, 0.5, 0.15
BOSS_R, BOSS_TOP = 13.6, 6.4      # rail 23 bar bottom is 6.85 (0.45 above)
LEDGE_R = 9.7                     # outer race face is r 9.45-11.0; inner race + shields stay clear
CONE_TOP_R = 3.6                  # passage for the dial nut (corner r 3.18)
POST_R, POST_TOP = 3.975, 5.0
POST_RIBS, POST_RIB_R, POST_RIB_PROUD = 3, 0.4, 0.1
SUPPORT_R = 5.9                   # inner-race support ring (inner race OD ~12.1)
NUT_AF_SNUG = 5.6                 # dial nut pocket, snug so the nut stays put before the screw goes in


def base_v47(B):
    B = cut(B, cyl(CX, CY, 4.6, POST_TOP, 20.0))                                     # old post above the stub
    B = cut(B, cut(cyl(CX, CY, 4.6, B_Z0, POST_TOP + 0.01), cyl(CX, CY, POST_R, B_Z0 - 1, POST_TOP + 1)))
    B = fuse(B, cyl(CX, CY, SUPPORT_R, -3.0, B_Z0))                                  # fills the old post/ring groove too
    ribs = []
    for k in range(POST_RIBS):
        a = math.radians(90 + 120 * k)
        r = POST_R + POST_RIB_PROUD - POST_RIB_R
        ribs.append(cyl(CX + r * math.cos(a), CY + r * math.sin(a), POST_RIB_R, B_Z0 + 0.6, POST_TOP - 0.3))
    return fuse(B, *ribs)


RAIL_SAFE_R = 9.2                 # rail 23 bar starts 9.64 from the axis: inside r 9.2 the gear may rise above z 6.4
RELIEF_TOP = 5.8                  # 0.6 mm over the inner race; the roof is a 5.6 mm annular bridge (r 3.6-9.2)


def gear_v47(G):
    G = cut(G, cyl(CX, CY, 4.7, -2.5, 19.45))                                         # clear the old bore region
    # boss: flat top at z 6.4 out to r 13.6 (under the rail), rising at 45 deg inside r 9.2 into the hub
    G = fuse(G, revolve_rz([(0.0, B_Z0), (BOSS_R, B_Z0), (BOSS_R, BOSS_TOP), (RAIL_SAFE_R, BOSS_TOP),
                            (6.9, BOSS_TOP + RAIL_SAFE_R - 6.9), (0.0, BOSS_TOP + RAIL_SAFE_R - 6.9)], CX, CY))
    G = cut(G, cyl(CX, CY, SEAT_R, B_Z0 - 0.2, B_Z1))
    # relief over inner race and shields; 45 deg step from the outer-race ledge (r 9.7) to the bridge (r 9.2)
    G = cut(G, revolve_rz([(0.0, B_Z1 - 0.1), (LEDGE_R, B_Z1 - 0.1), (LEDGE_R, B_Z1 + 0.1), (RAIL_SAFE_R, RELIEF_TOP), (0.0, RELIEF_TOP)], CX, CY))
    G = cut(G, cyl(CX, CY, CONE_TOP_R, RELIEF_TOP - 0.1, 19.5))
    ribs = []
    for k in range(RIB_N):
        a = math.radians(30 + 60 * k)
        r = SEAT_R - RIB_PROUD + RIB_R
        ribs.append(cyl(CX + r * math.cos(a), CY + r * math.sin(a), RIB_R, B_Z0 + 0.8, B_Z1))
    G = fuse(G, *ribs)
    # snug dial-nut pocket (replaces the 5.75 AF pocket of v46)
    G = fuse(G, cut(hexagon(CX, CY, 5.75, 19.46, 22.09, 30.0), hexagon(CX, CY, NUT_AF_SNUG, 19.3, 22.2, 30.0)))
    return G


def bearing_608():
    """Simplified 608: outer ring (rotates with the gear) and inner ring (static on the post), shields in between."""
    outer = cut(cyl(CX, CY, B_OD / 2, B_Z0, B_Z1), cyl(CX, CY, 9.45, B_Z0 - 1, B_Z1 + 1))
    inner = cut(cyl(CX, CY, 6.05, B_Z0, B_Z1), cyl(CX, CY, B_ID / 2, B_Z0 - 1, B_Z1 + 1))
    shield = cut(cyl(CX, CY, 9.45, B_Z0 + 0.15, B_Z1 - 0.15), cyl(CX, CY, 6.05, B_Z0, B_Z1))
    return {"HW_608_Outer": outer, "HW_608_Inner": inner, "HW_608_Shield": shield}
