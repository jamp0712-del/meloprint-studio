# -*- coding: utf-8 -*-
# Build site_v47 from site_v46: 608 bearing (01 base stub, 04 gear seat), packages, CAD descriptors, texts.
import os, re, shutil, zipfile, hashlib, json
W = r"C:\Users\Public\mbx_work"
S46, D = W + r"\site_v46", W + r"\site_v47"
A = W + r"\v47_assets"
O = W + r"\pf2_out"
sha = lambda b: hashlib.sha256(b).hexdigest()
rd = lambda p: open(p, "rb").read()
shutil.rmtree(D, ignore_errors=True)
shutil.copytree(S46, D)
for n in ("01_Base_AP1", "01_Base_MW4", "04_Handle_AP1", "M3_Hardware"):
    shutil.copy2(os.path.join(A, "assets", "pf2", n + ".stl"), os.path.join(D, "assets", "pf2"))
shutil.copy2(os.path.join(A, "models", "01_Base_MW4_PRINT.stl"), os.path.join(D, "models"))
for f in os.listdir(os.path.join(D, "cad")):
    if f.endswith(".3dm"):
        os.remove(os.path.join(D, "cad", f))
for f in ("Meloprint_PF2_v47_Assembly.3dm", "Meloprint_PF2_v47_MW4_Assembly.3dm"):
    shutil.copy2(os.path.join(O, f), os.path.join(D, "cad", f))
checks = {"v47_checks/bearing-drive.json": rd(W + r"\v47_checks.json"), "v47_checks/assembly-path.json": rd(W + r"\v47_asm.json"),
          "v47_checks/motion-checks.json": rd(W + r"\val_v47.json"), "v47_checks/rhino7-build.log": rd(W + r"\rh_build_v47.log"),
          "v47_checks/export.json": rd(A + r"\export_v47.json")}
sources = {"v47_source/" + f: rd(os.path.join(W, f)) for f in ("bearing_mods.py", "t_v47_build.py", "t_v47_validate.py", "t_v47_assembly.py",
                                                                "export_v47.py", "rh_build_v47.py", "build_v47_site.py")}
readme = rd(W + r"\v47_doc\README_KO.md")
for tag, zname, d3dm, base, pk in (("current", "Meloprint_PF2_Print_Package.zip", "Meloprint_PF2_v47_Assembly.3dm", "01_Base_AP1", "pkg"),
                                   ("makerworld", "Meloprint_PF2_MW4_Print_Package.zip", "Meloprint_PF2_v47_MW4_Assembly.3dm", "01_Base_MW4", "pkg_mw4")):
    zin = zipfile.ZipFile(os.path.join(S46, "downloads", zname))
    repl = {"print_stl/%s_PRINT.stl" % base: rd(os.path.join(A, pk, "print_stl", base + "_PRINT.stl")),
            "print_stl/04_Handle_AP1.stl": rd(os.path.join(A, "pkg", "print_stl", "04_Handle_AP1.stl"))}
    entries = []
    for i in zin.infolist():
        n = i.filename
        if n in ("SHA256.json", "3dm_checks.json") or (n.endswith(".3dm") and "/" not in n):
            continue
        if n == "README_KO.md":
            entries.append(("history/v46/README_KO.md", zin.read(n))); entries.append((n, readme)); continue
        entries.append((n, repl.get(n, zin.read(n))))
    b3 = rd(os.path.join(O, d3dm))
    entries.append((d3dm, b3))
    for n, src in ((base, base + ".step"), ("04_Handle_AP1", "04_Handle_AP1.step"), ("Hardware_M3_608", "Hardware_M3_608.step")):
        entries.append(("v47_native_parts/%s.step" % n, rd(os.path.join(O, "STEP_v47", src))))
    entries += sorted(checks.items()) + sorted(sources.items())
    desc = {"file": "cad/" + d3dm, "filename": d3dm, "bytes": len(b3), "sha256": sha(b3), "parts": 11,
            "hardware": "1x 608 bearing, 4x M3x20 DIN912, 1x M3x8 ISO7380, 5x M3 DIN934", "revision": "PF2", "fixedSample": True,
            "faces": {"current": 2573, "makerworld": 2214}[tag], "assemblyRevision": "PF2-v47", "combStyle": tag, "rhinoArchiveVersion": 7}
    entries.append(("3dm_checks.json", json.dumps({tag: desc}, indent=2).encode()))
    names = [n for n, _ in entries]
    assert len(names) == len(set(names))
    entries.append(("SHA256.json", json.dumps({n: sha(b) for n, b in entries}, indent=2).encode()))
    with zipfile.ZipFile(os.path.join(D, "downloads", zname), "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for n, b in entries:
            z.writestr(n, b)
    print(zname, len(entries), "MB %.1f" % (os.path.getsize(os.path.join(D, "downloads", zname)) / 1e6))
    json.dump(desc, open(os.path.join(D, "cad", "pf2-surface.json" if tag == "current" else "pf2-surface-mw4.json"), "w"), indent=2)


def esc(t):
    return "".join(c if ord(c) < 128 else ("\\x%02X" % ord(c) if ord(c) < 256 else "\\u%04X" % ord(c)) for c in t)


def patch(rel, reps):
    p = os.path.join(D, rel)
    s = open(p, encoding="utf-8").read()
    for old, new, n in reps:
        c = s.count(old)
        assert c == n, (rel, old[:70], c, n)
        s = s.replace(old, new)
    open(p, "w", encoding="utf-8", newline="").write(s)
    print("patched", rel, len(reps))


patch("app.js", [
    (esc("PF2 전체 11부품 + M3 나사·너트 5세트"), esc("PF2 전체 11부품 + 608 베어링 + M3 나사·너트 5세트"), 1),
    (esc("출력 부품 11개 + M3 나사·너트 10개 서피스 솔리드"), esc("출력 부품 11개 + 608 베어링·M3 나사·너트 서피스 솔리드"), 2),
    ('"v46 ' + esc("기본"), '"v47 ' + esc("기본"), 1),
    ('"v46 MW4 ', '"v47 MW4 ', 1),
])
V47 = ('<p class="hint"><strong>v47 · 608 베어링.</strong> 손잡이 기어 아래에 608 스케이트 베어링 하나를 넣어 다이얼이 볼베어링 위에서 부드럽게 돕니다. '
       '기어 축은 메인기어와 같은 베이스가 잡아 맞물림 틈이 그대로 유지됩니다. 베어링 자리는 압착 리브로 출력 공차를 흡수합니다.</p>')
patch("index.html", [
    ('<p class="eyebrow">PF2 v46 · 11 PRINTED PARTS + M3 SCREWS</p>', '<p class="eyebrow">PF2 v47 · 11 PRINTED PARTS + 608 BEARING + M3</p>', 1),
    ("<h2>전체 모델링 다운로드</h2>", "<h2>전체 모델링 다운로드</h2>" + V47, 1),
    ("v46 기본 상판 고정 샘플 · 서피스 3DM (Rhino 7)", "v47 기본 상판 고정 샘플 · 서피스 3DM (Rhino 7)", 1),
    ("출력 부품 11개의 닫힌 서피스 솔리드와 M3 나사·너트 10개(별도 레이어)가 들어 있습니다(Rhino 7 형식, 출력 부품 면 수 일반 2,533 / MW4 2,174).",
     "출력 부품 11개의 닫힌 서피스 솔리드와 608 베어링·M3 나사·너트(별도 레이어)가 들어 있습니다(Rhino 7 형식, 출력 부품 면 수 일반 2,573 / MW4 2,214).", 1),
    ("v46 현재형 고정 샘플 전체 ZIP · STEP·3DM·설명서", "v47 현재형 고정 샘플 전체 ZIP · STEP·3DM·설명서", 1),
    ("v46 MW4 33음 고정 샘플 전체 ZIP · STEP·3DM", "v47 MW4 33음 고정 샘플 전체 ZIP · STEP·3DM", 1),
    ("<strong>v46 조립 순서:</strong> 손잡이 기어 구멍으로 M3 너트를 밀어 넣고 → 04 기어를 기둥에",
     "<strong>v47 조립 순서:</strong> 손잡이 기어 아래 통로로 M3 너트를 밀어 넣고 → 608 베어링을 기어 아래에 눌러 넣고 → 04 기어를 베이스 짧은 기둥에", 1),
    ("기존 3종도 v46 일반형 베이스·상판을 사용합니다.", "기존 3종도 v47 일반형 베이스·상판을 사용합니다.", 1),
    ("PF2 11부품 + M3 나사 구조(v46)를 사용하며", "PF2 11부품 + 608 베어링 + M3 나사 구조(v47)를 사용하며", 1),
    ("<strong>PF2 32 Stable · v46</strong>", "<strong>PF2 32 Stable · v47</strong>", 1),
])
