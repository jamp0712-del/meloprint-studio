# -*- coding: utf-8 -*-
import sys, os, shutil
sys.path.insert(0, r"C:\Users\Public\mbx_work")
from ap1_view import load_cache
from ap1_tool import n_solids, valid
from occ_conv import volume
from OCP.BRepTools import BRepTools
import bearing_mods as BM
W = r"C:\Users\Public\mbx_work\in"


def save(d, shapes):
    os.makedirs(d, exist_ok=True)
    for f in os.listdir(d):
        os.remove(os.path.join(d, f))
    for n, s in shapes.items():
        BRepTools.Write_s(s, os.path.join(d, n + ".brep"))


gear = BM.gear_v47(load_cache(W + r"\pf2v46_brep")["04_Handle_AP1"])
print("04_Handle_AP1 solids=%d valid=%s vol=%.2f" % (n_solids(gear), valid(gear), volume(gear)))
for src, dst, base in ((W + r"\pf2v46_brep", W + r"\pf2v47_brep", "01_Base_AP1"), (W + r"\pf2v46mw4_brep", W + r"\pf2v47mw4_brep", "01_Base_MW4")):
    S = load_cache(src)
    out = dict(S)
    out[base] = BM.base_v47(S[base])
    out["04_Handle_AP1"] = gear
    print("%-12s solids=%d valid=%s vol=%.2f (d=%.2f)" % (base, n_solids(out[base]), valid(out[base]), volume(out[base]), volume(out[base]) - volume(S[base])))
    save(dst, out)
    if "MW4" in base:
        A = {"01_Base_MW4": "01_Base_AP1", "02_Cover_MW4": "02_Cover_AP1", "15_CombLower_MW4": "15_CombLower_AP1", "16_CombUpper_MW4": "16_CombUpper_AP1"}
        save(W + r"\pf2v47mw4_valid", {A.get(n, n): s for n, s in out.items()})
HW = load_cache(W + r"\pf2v46_hw")
HW.update(BM.bearing_608())
save(W + r"\pf2v47_hw", HW)
for n, s in BM.bearing_608().items():
    print("%-14s solids=%d valid=%s vol=%.2f" % (n, n_solids(s), valid(s), volume(s)))
