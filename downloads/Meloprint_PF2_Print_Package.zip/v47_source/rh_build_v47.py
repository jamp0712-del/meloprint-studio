# -*- coding: utf-8 -*-
# Rhino 7: v47 surface 3DMs from the v46 files. 01 base from STEP, 04 handle gear rebuilt with Rhino booleans (same
# operations as bearing_mods.gear_v47), 608 bearing added to the hardware layer. Rhino-kernel cross-checks.
import math, json, traceback
import Rhino
import Rhino.Geometry as G
import scriptcontext as sc
import rhinoscriptsyntax as rs

W = r"C:\Users\Public\mbx_work"
O = W + r"\pf2_out"
LOG = open(W + r"\rh_build_v47.log", "w")
def L(*a):
    LOG.write(" ".join(str(x) for x in a) + "\n"); LOG.flush()
REV = "PF2-v47 608 bearing"
HC = (0.0, -80.544)
TOL = 0.001


def import_step(path):
    doc = sc.doc
    before = set(o.Id for o in doc.Objects)
    rs.Command('_-Import "' + path + '" _Enter', False)
    new = [o for o in doc.Objects if o.Id not in before]
    for o in new:
        if isinstance(o, Rhino.DocObjects.InstanceObject):
            rs.ExplodeBlockInstance(o.Id, True)
    new = [o for o in doc.Objects if o.Id not in before and not isinstance(o, Rhino.DocObjects.InstanceObject)]
    bs = [o.Geometry.DuplicateBrep() for o in new if isinstance(o.Geometry, G.Brep)]
    for o in new:
        doc.Objects.Delete(o.Id, True)
    if len(bs) != 1:
        raise RuntimeError("%s: %d breps" % (path, len(bs)))
    return bs[0]


def cyl(cx, cy, r, z0, z1):
    return G.Cylinder(G.Circle(G.Plane(G.Point3d(cx, cy, z0), G.Vector3d.ZAxis), r), z1 - z0).ToBrep(True, True)


def ring(cx, cy, r0, r1, z0, z1):
    return G.Brep.CreateBooleanDifference(cyl(cx, cy, r1, z0, z1), cyl(cx, cy, r0, z0 - 1, z1 + 1), TOL)[0]


def revolve(pts_rz):
    # profiles that start and end on the axis are revolved open (closing along the axis gives a degenerate face)
    closing = [] if (pts_rz[0][0] == 0.0 and pts_rz[-1][0] == 0.0) else [G.Point3d(HC[0] + pts_rz[0][0], HC[1], pts_rz[0][1])]
    pl = G.Polyline([G.Point3d(HC[0] + r, HC[1], z) for r, z in pts_rz] + closing)
    b = G.RevSurface.Create(pl.ToNurbsCurve(), G.Line(G.Point3d(HC[0], HC[1], 0), G.Point3d(HC[0], HC[1], 1))).ToBrep()
    if b.SolidOrientation == G.BrepSolidOrientation.Inward:
        b.Flip()
    return b


def hexprism(af, z0, z1, rot=30.0):
    rr = af / 2.0 / math.cos(math.radians(30))
    pts = [G.Point3d(HC[0] + rr * math.cos(math.radians(rot + 60 * k)), HC[1] + rr * math.sin(math.radians(rot + 60 * k)), z0) for k in range(7)]
    b = G.Surface.CreateExtrusion(G.PolylineCurve(pts), G.Vector3d(0, 0, z1 - z0)).ToBrep().CapPlanarHoles(0.001)
    if b.SolidOrientation == G.BrepSolidOrientation.Inward:
        b.Flip()
    return b


def one(res, what):
    if res is None or not all(x.IsSolid for x in res):
        raise RuntimeError("%s: %s" % (what, None if res is None else [x.IsSolid for x in res]))
    if len(res) > 1:
        vs = sorted(((vol(x), x) for x in res), key=lambda t: -t[0])
        L("  note %s: %d pieces, volumes %s -> keeping the largest" % (what, len(res), [round(v, 4) for v, _ in vs]))
        if vs[1][0] > 1.0:
            raise RuntimeError("%s: second piece too big" % what)
        return vs[0][1]
    return res[0]


def vol(b):
    m = G.VolumeMassProperties.Compute(b)
    return m.Volume if m else float("nan")


def ivol(a, b):
    if not G.BoundingBox.Intersection(a.GetBoundingBox(True), b.GetBoundingBox(True)).IsValid:
        return 0.0
    r = G.Brep.CreateBooleanIntersection(a, b, TOL)
    if r is None:
        return None
    return sum(abs(G.VolumeMassProperties.Compute(x).Volume) for x in r if G.VolumeMassProperties.Compute(x))


def gear_v47(g):
    B_Z0, B_Z1 = -1.8, 5.2
    g = one(G.Brep.CreateBooleanDifference(g, cyl(HC[0], HC[1], 4.7, -2.5, 19.45), TOL), "clear bore")
    g = one(G.Brep.CreateBooleanUnion([g, revolve([(0.0, B_Z0), (13.6, B_Z0), (13.6, 6.4), (9.2, 6.4), (6.9, 8.7), (0.0, 8.7)])], TOL), "boss")
    g = one(G.Brep.CreateBooleanDifference(g, cyl(HC[0], HC[1], 11.1, B_Z0 - 0.2, B_Z1), TOL), "seat")
    g = one(G.Brep.CreateBooleanDifference(g, revolve([(0.0, B_Z1 - 0.1), (9.7, B_Z1 - 0.1), (9.7, B_Z1 + 0.1), (9.2, 5.8), (0.0, 5.8)]), TOL), "relief")
    g = one(G.Brep.CreateBooleanDifference(g, cyl(HC[0], HC[1], 3.6, 5.7, 19.5), TOL), "nut passage")
    ribs = []
    for k in range(6):
        a = math.radians(30 + 60 * k); r = 11.1 - 0.15 + 0.5
        ribs.append(cyl(HC[0] + r * math.cos(a), HC[1] + r * math.sin(a), 0.5, B_Z0 + 0.8, B_Z1))
    g = one(G.Brep.CreateBooleanUnion([g] + ribs, TOL), "seat ribs")
    pocket_ring = one(G.Brep.CreateBooleanDifference(hexprism(5.75, 19.46, 22.09), hexprism(5.6, 19.3, 22.2), TOL), "pocket ring")
    return one(G.Brep.CreateBooleanUnion([g, pocket_ring], TOL), "snug pocket")


try:
    occ = json.load(open(W + r"\v47_assets\export_v47.json"))
    brg = [("608_Bearing_Outer", ring(HC[0], HC[1], 9.45, 11.0, -1.8, 5.2)), ("608_Bearing_Inner", ring(HC[0], HC[1], 4.0, 6.05, -1.8, 5.2)),
           ("608_Bearing_Shield", ring(HC[0], HC[1], 6.1, 9.4, -1.65, 5.05))]
    for tag, src, dst, base in (("AP1", O + r"\Meloprint_PF2_v46_Assembly.3dm", O + r"\Meloprint_PF2_v47_Assembly.3dm", "01_Base_AP1"),
                                ("MW4", O + r"\Meloprint_PF2_v46_MW4_Assembly.3dm", O + r"\Meloprint_PF2_v47_MW4_Assembly.3dm", "01_Base_MW4")):
        f0 = Rhino.FileIO.File3dm.Read(src)
        g46 = [o.Geometry for o in f0.Objects if o.Attributes.Name == "04_Handle_AP1"][0].DuplicateBrep()
        repl = {base: import_step(O + r"\STEP_v47\%s.step" % base), "04_Handle_AP1": gear_v47(g46)}
        L("%s gear rebuilt: solid=%s valid=%s vol=%.2f | base solid=%s vol=%.2f" % (tag, repl["04_Handle_AP1"].IsSolid, repl["04_Handle_AP1"].IsValid,
                                                                                  vol(repl["04_Handle_AP1"]), repl[base].IsSolid, vol(repl[base])))
        f = Rhino.FileIO.File3dm()
        f.Settings.ModelUnitSystem = f0.Settings.ModelUnitSystem
        f.Settings.ModelAbsoluteTolerance = f0.Settings.ModelAbsoluteTolerance
        lay0 = dict((l.Index, l.Name) for l in f0.AllLayers)
        for l in f0.AllLayers:
            nl = Rhino.DocObjects.Layer(); nl.Name = l.Name; nl.Color = l.Color
            f.AllLayers.Add(nl)
        idx = dict((l.Name, l.Index) for l in f.AllLayers)
        hwl = [l.Name for l in f.AllLayers if l.Name.startswith("M3_Hardware")][0]
        geo, faces = {}, 0
        for o in f0.Objects:
            n = o.Attributes.Name
            a = o.Attributes.Duplicate(); a.LayerIndex = idx[lay0[o.Attributes.LayerIndex]]
            b = repl[n].DuplicateBrep() if n in repl else o.Geometry.DuplicateBrep()
            if n in repl:
                a.SetUserString("Revision", REV)
                a.SetUserString("Change", "post stub D7.95 + 3 crush ribs for the 608 inner race, support ring at z -1.8" if n == base else
                                "608 outer race seat (D22.2 + 6 crush ribs) in a D27.2 boss, bridged relief, D7.2 nut passage")
            f.Objects.AddBrep(b, a); geo[n] = b
            if not n.startswith("M3"):
                faces += b.Faces.Count
        for n, b in brg:
            a = Rhino.DocObjects.ObjectAttributes(); a.Name = n; a.LayerIndex = idx[hwl]
            a.SetUserString("Printable", "No"); a.SetUserString("Part", "608ZZ / 608-2RS skate bearing 8x22x7"); a.SetUserString("Revision", REV)
            f.Objects.AddBrep(b, a); geo[n] = b
        f.Strings.SetString("MeloprintRevision", "PF2-v47")
        f.Strings.SetString("Changes", "v47 = v46 + one 608 bearing under the handle gear (outer race in the gear, inner race on the base post stub)")
        f.Write(dst, 7)
        back = Rhino.FileIO.File3dm.Read(dst)
        bad = [o.Attributes.Name for o in back.Objects if not (isinstance(o.Geometry, G.Brep) and o.Geometry.IsSolid and o.Geometry.IsValid)]
        L("%s saved archive=%d objects=%d printed-part faces=%d bad=%s" % (dst, Rhino.FileIO.File3dm.ReadArchiveVersion(dst), len(back.Objects), faces, bad))
        L("  occ volumes: base %s gear %s" % (occ.get("assets/pf2/%s.stl" % base, {}).get("volume"), occ["assets/pf2/04_Handle_AP1.stl"]["volume"]))
        rot = ["04_Handle_AP1", "11_HandleRetainer_AP1", "M3x8_ISO7380_Dial", "M3_Nut_DIN934_Dial", "608_Bearing_Outer", "608_Bearing_Shield"]
        for th in (0.0, 30.0, 45.0, 90.0, 180.0):
            xf = G.Transform.Rotation(math.radians(1.5 * th), G.Vector3d.ZAxis, G.Point3d(HC[0], HC[1], 0))
            mg = geo["03_MainGear_AP1"].DuplicateBrep(); mg.Transform(G.Transform.Rotation(math.radians(-th), G.Vector3d.ZAxis, G.Point3d(0.0, -23.218, 0)))
            stat = {base: geo[base], "02": [v for k, v in geo.items() if k.startswith("02_")][0], "03": mg, "23": geo["23_RearGuideRail"], "608in": geo["608_Bearing_Inner"]}
            row = []
            for mv in rot:
                m = geo[mv].DuplicateBrep(); m.Transform(xf)
                for sk, st in stat.items():
                    if (mv == "608_Bearing_Shield" and sk == "608in"):
                        continue
                    v = ivol(m, st)
                    if v is None or v > 1e-3:
                        row.append("%s-%s:%s" % (mv[:6], sk[:5], None if v is None else round(v, 3)))
            L("  handle %5.1f deg: %s" % (1.5 * th, "no overlaps" if not row else " ".join(row)))
        g = geo["04_Handle_AP1"].DuplicateBrep(); g.Translate(G.Vector3d(0, 0, 0.6))
        L("  positive control: gear raised 0.6 mm hits rail 23: %s mm3" % ivol(g, geo["23_RearGuideRail"]))
except Exception:
    L("ERR", traceback.format_exc())
L("##DONE##")
LOG.close()
