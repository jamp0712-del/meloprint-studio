# -*- coding: utf-8 -*-
# v47 checks: 608 fit (outer race in the gear, inner race on the post), rotating-unit clearances at many angles,
# lift/drop stops, section picture.
import sys, json, math
sys.path.insert(0, r"C:\Users\Public\mbx_work")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from ap1_view import load_cache, section_lines
from mf_tool import to_manifold, inter_vol
from pf2_kin import part_xf, HANDLE_C
src, out, img = sys.argv[1], sys.argv[2], sys.argv[3]
S = load_cache(src)
HW = load_cache(r"C:\Users\Public\mbx_work\in\pf2v47_hw")
M = {n: to_manifold(s, 0.005) for n, s in S.items()}
H = {n: to_manifold(s, 0.005) for n, s in HW.items()}
ROT = ("_Dial", "608_Outer", "608_Shield")
R = {}


def pose(th):
    P = {}
    for n, m in M.items():
        xf = part_xf(n, th)
        P[n] = m.transform(xf) if xf is not None else m
    xf = part_xf("04", th)
    for n, m in H.items():
        P[n] = m.transform(xf) if n.endswith(ROT) else m
    return P


# designed contacts (press fits / seats) are reported separately from real interferences
FIT = {("04_Handle_AP1", "HW_608_Outer"), ("01_Base_AP1", "HW_608_Inner"), ("HW_608_Inner", "HW_608_Shield"), ("HW_608_Outer", "HW_608_Shield")}
fits, bad = {}, []
for th in (0, 20, 45, 70, 90, 135, 180, 225, 270, 315):
    P = pose(th)
    names = sorted(P)
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            a, b = names[i], names[j]
            if (a[:2] in ("15", "16") and b.startswith("05")) or (b[:2] in ("15", "16") and a.startswith("05")):
                continue
            if {a[:2], b[:2]} <= {"01", "02", "15", "16"}:
                continue        # comb clamp squeeze (checked in v46)
            v, bb = inter_vol(P[a], P[b])
            if v > 1e-3:
                if (a, b) in FIT or (b, a) in FIT:
                    fits[a + " | " + b] = round(v, 4)
                else:
                    bad.append((th, a, b, round(v, 4)))
R["designed_press_fits_mm3"] = fits
R["interferences"] = bad
print("press fits (crush ribs):", fits)
print("interferences:", bad[:8], len(bad))
P = pose(0)
gp = lambda a, b, lim=3.0: round(P[a].min_gap(P[b], lim), 3)
R["gaps"] = {"gear-rail23": gp("04_Handle_AP1", "23_RearGuideRail"), "gear-base": gp("04_Handle_AP1", "01_Base_AP1"),
             "gear-yoke": gp("04_Handle_AP1", "05_Yoke_AP1"), "gear-maingear(mesh)": gp("04_Handle_AP1", "03_MainGear_AP1"),
             "gear collar-cover": gp("04_Handle_AP1", "02_Cover_AP1"), "dial-cover": gp("11_HandleRetainer_AP1", "02_Cover_AP1"),
             "gear-inner race": gp("04_Handle_AP1", "HW_608_Inner"), "gear-shield": gp("04_Handle_AP1", "HW_608_Shield"),
             "outer race-base": gp("HW_608_Outer", "01_Base_AP1"), "outer race-rail23": gp("HW_608_Outer", "23_RearGuideRail"),
             "dial nut-post": gp("HW_M3_Nut_Dial", "01_Base_AP1"), "post-gear": gp("01_Base_AP1", "04_Handle_AP1")}
print("gaps:", R["gaps"])
unit = P["04_Handle_AP1"] + P["11_HandleRetainer_AP1"] + P["HW_M3x8_Button_Dial"] + P["HW_M3_Nut_Dial"] + P["HW_608_Outer"] + P["HW_608_Shield"] + P["HW_608_Inner"]
others = {n: P[n] for n in P if n[:2] not in ("04", "11", "15", "16") and not n.endswith(ROT) and n != "HW_608_Inner"}


def free(move, maxd=3.0):
    lo, hi = 0.0, maxd
    def hit(d):
        m = move(d)
        for n, o in others.items():
            if inter_vol(m, o)[0] > 1e-3:
                return n
        return None
    if hit(maxd) is None:
        return None, maxd
    for _ in range(24):
        mid = (lo + hi) / 2
        if hit(mid):
            hi = mid
        else:
            lo = mid
    return hit(hi), round(lo, 4)


R["unit_lift"] = free(lambda d: unit.translate((0, 0, d)))
R["unit_drop"] = free(lambda d: unit.translate((0, 0, -d)))
print("unit lift", R["unit_lift"], "drop", R["unit_drop"])
json.dump(R, open(out, "w"), indent=1)
# section
COL = {"01": "#8a8f96", "02": "#3a9a3a", "03": "#e08a10", "04": "#c9a000", "05": "#d03030", "11": "#1f77b4", "23": "#111111", "HW": "#c0392b"}
plt.rcParams["font.family"] = "Malgun Gothic"; plt.rcParams["axes.unicode_minus"] = False
fig, axs = plt.subplots(1, 2, figsize=(20, 8), dpi=110)
shapes = dict(S); shapes.update(HW)
for ax, (o, nrm, a, win, t) in zip(axs, (((0, HANDLE_C[1], 0), (0, 1, 0), (0, 2), (-26, 26, -6, 31), "v47 XZ (손잡이 축)"),
                                          ((0, 0, 0), (1, 0, 0), (1, 2), (HANDLE_C[1] - 26, HANDLE_C[1] + 26, -6, 31), "v47 YZ (손잡이 축, 레일 23 포함)"))):
    for n, s in shapes.items():
        k = "HW" if n.startswith("HW") else n[:2]
        if k not in COL or (k == "HW" and "Screw" in n and "Dial" not in n):
            continue
        for ln in section_lines(s, o, nrm):
            ax.plot(ln[:, a[0]], ln[:, a[1]], color=COL[k], lw=1.2 if k in ("HW", "04") else 0.8)
    ax.set_aspect("equal"); ax.set_xlim(win[0], win[1]); ax.set_ylim(win[2], win[3]); ax.grid(True, lw=0.3, alpha=0.5); ax.set_title(t, loc="left")
fig.text(0.01, 0.01, "빨강: 608 베어링 · M3 볼트·너트 / 노랑: 04 손잡이 기어 / 회색: 01 베이스 / 검정: 23 레일 / 파랑: 11 다이얼", fontsize=10)
fig.tight_layout(rect=(0, 0.03, 1, 1)); fig.savefig(img)
