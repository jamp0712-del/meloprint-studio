﻿# -*- coding: utf-8 -*-
# v46 assembly path: every part lowered (or inserted) along its real path into the already-installed parts.
import sys, json
sys.path.insert(0, r"C:\Users\Public\mbx_work")
from pf2_kin import load, posed, part_xf
from ap1_view import load_cache
from mf_tool import to_manifold, inter_vol
src, out = sys.argv[1], sys.argv[2]
ML = load(src)
HW = {n: to_manifold(s, 0.005) for n, s in load_cache(r"C:\Users\Public\mbx_work\in\pf2v47_hw").items()}
M90 = posed(ML, 90)      # arrow parked at the end (combs)
M0 = posed(ML, 0)        # arrow centred (cover)
nm = lambda k: [n for n in ML if n.startswith(k)][0]


def path(mov, vec, installed, steps=40):
    hits = []
    for k in range(steps + 1):
        t = 1.0 - k / float(steps)
        m2 = mov.translate((vec[0] * t, vec[1] * t, vec[2] * t))
        for n, o in installed.items():
            v, bb = inter_vol(m2, o)
            if v > 0.01:
                hits.append((round(t, 3), n, round(v, 3)))
    return hits


inst = {nm("01"): M0[nm("01")]}
R = []
def step(label, mov, vec, extra_note=""):
    h = path(mov, vec, inst)
    R.append({"step": label, "hits": h[:6], "n": len(h), "note": extra_note})
    print("%-44s hits %3d %s %s" % (label, len(h), h[:3], extra_note))


gear_nut = HW["HW_M3_Nut_Dial"]
h0 = path(gear_nut, (0, 0, -25), {nm("04"): M0[nm("04")]})
R.append({"step": "dial nut pushed up the bore into the gear's pocket (gear on the bench)", "hits": h0[:6], "n": len(h0)})
print("%-44s hits %3d %s" % ("dial nut up the gear bore (gear on bench)", len(h0), h0[:3]))
hb = path(HW["HW_608_Outer"] + HW["HW_608_Shield"], (0, 0, -15), {nm("04"): M0[nm("04")]})
R.append({"step": "608 pressed into the gear seat from below (gear on the bench)", "hits": hb[-4:], "n": len(hb), "note": "crush ribs"})
print("%-44s hits %3d %s (crush ribs)" % ("608 pressed into gear seat (bench)", len(hb), hb[-2:]))
brg = HW["HW_608_Outer"] + HW["HW_608_Shield"] + HW["HW_608_Inner"]
step("04 gear + nut + 608 onto post stub", M0[nm("04")] + gear_nut + brg, (0, 0, 40), "(608 inner race over the 3 post crush ribs)")
inst[nm("04")] = M0[nm("04")]; inst["nut"] = gear_nut; inst["608"] = brg
step("23 rear guide rail", M0[nm("23")], (0, 0, 30)); inst[nm("23")] = M0[nm("23")]
step("03 main gear", M0[nm("03")], (0, 0, 35)); inst[nm("03")] = M0[nm("03")]
step("10 clip", M0[nm("10")], (0, 0, 15), "(snap clip: small contact expected)"); inst[nm("10")] = M0[nm("10")]
step("06 roller (no clip 12 any more)", M0[nm("06")], (0, 0, 20)); inst[nm("06")] = M0[nm("06")]
step("05 yoke / arrow", M0[nm("05")], (0, 0, 35)); inst[nm("05")] = M0[nm("05")]
step("02 cover (arrow centred)", M0[nm("02")], (0, 0, 35)); inst[nm("02")] = M0[nm("02")]
for i in range(1, 5):
    step("cover nut %d (from below)" % i, HW["HW_M3_Nut_%d" % i], (0, 0, -20)); inst["cn%d" % i] = HW["HW_M3_Nut_%d" % i]
    step("cover screw M3x20 %d (from above)" % i, HW["HW_M3x20_Screw_%d" % i], (0, 0, 30)); inst["cs%d" % i] = HW["HW_M3x20_Screw_%d" % i]
step("11 dial onto gear hex", M0[nm("11")], (0, 0, 30)); inst[nm("11")] = M0[nm("11")]
step("dial screw M3x8 (from above)", HW["HW_M3x8_Button_Dial"], (0, 0, 25)); inst["ds"] = HW["HW_M3x8_Button_Dial"]
# combs with the arrow parked: re-pose the moving parts at theta 90
for k in ("03", "04", "05", "06", "11"):
    inst[nm(k)] = M90[nm(k)]
inst["nut"] = gear_nut.transform(part_xf("04", 90)); inst["ds"] = HW["HW_M3x8_Button_Dial"].transform(part_xf("04", 90))
step("15+16 combs (-Y, arrow parked)", M90[nm("15")] + M90[nm("16")], (0, 45, 0), "(hooks + rail clamp pads/ribs: press-in expected)")
json.dump(R, open(out, "w"), indent=1)

