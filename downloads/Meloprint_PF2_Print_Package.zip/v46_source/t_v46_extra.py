# -*- coding: utf-8 -*-
# (a) Is clip 12 needed?  Roller free travel up the crank pin with and without it.
# (b) How well are the combs held?  Free play of the comb pair in +-X, +-Y, +-Z and small rotations, against base + cover.
import sys, json
sys.path.insert(0, r"C:\Users\Public\mbx_work")
from pf2_kin import load, posed, MAIN_C
from mf_tool import inter_vol, xf_rotate
src = sys.argv[1]
M = load(src)
R = {}


def free(P, mover_mf, others, move, maxd):
    lo, hi = 0.0, maxd
    def hit(d):
        m = move(mover_mf, d)
        for n in others:
            if inter_vol(m, P[n])[0] > 1e-4:
                return n
        return None
    if hit(maxd) is None:
        return None, maxd
    for _ in range(24):
        mid = (lo + hi) / 2
        if hit(mid):
            hi = mid
        else:
            lo = mid
    return hit(hi), round(lo, 4)


up = lambda m, d: m.translate((0, 0, d))
rows = []
for th in (0, 90, 180, 270):
    P = posed(M, th)
    oth = [n for n in P if n[:2] not in ("06", "12", "15", "16")]
    r_with = free(P, P["06_CrankRoller_AP1"], oth + ["12_RollerRetainer_AP1"], up, 3.0)
    r_without = free(P, P["06_CrankRoller_AP1"], oth, up, 3.0)
    # yoke resting on its rails: how far can it lift (adds to the roller's travel)?
    y_up = free(P, P["05_Yoke_AP1"], [n for n in P if n[:2] not in ("05", "15", "16")], up, 3.0)
    rows.append({"theta": th, "roller_lift_with_clip12": r_with, "roller_lift_without_clip12": r_without, "yoke_lift": y_up})
    print(rows[-1])
R["clip12"] = rows
# pin engagement: roller bore length on the crank pin
P = posed(M, 0)
pin_overlap = P["06_CrankRoller_AP1"].bounding_box()
R["roller_bbox"] = [round(v, 3) for v in pin_overlap]

# (b) comb play, arrow parked at the end (combs are inserted/used that way)
P = posed(M, 90)
comb = P[[n for n in P if n.startswith("15")][0]] + P[[n for n in P if n.startswith("16")][0]]
hold = [n for n in P if n[:2] in ("01", "02")]
cp = {}
for lab, vec in (("+X", (1, 0, 0)), ("-X", (-1, 0, 0)), ("+Y (out)", (0, 1, 0)), ("-Y (in)", (0, -1, 0)), ("+Z", (0, 0, 1)), ("-Z", (0, 0, -1))):
    cp[lab] = free(P, comb, hold, lambda m, d, v=vec: m.translate((v[0] * d, v[1] * d, v[2] * d)), 2.0)
c = comb.bounding_box(); cx, cy, cz = (c[0] + c[3]) / 2, (c[1] + c[4]) / 2, (c[2] + c[5]) / 2
for lab, axis in (("rot Z", (0, 0, 1)), ("rot X", (1, 0, 0)), ("rot Y", (0, 1, 0))):
    for s in (1, -1):
        cp["%s %+d" % (lab, s)] = free(P, comb, hold, lambda m, a, ax=axis, sg=s: m.transform(xf_rotate(sg * a, (cx, cy, cz), ax)), 3.0)
R["comb_play"] = cp
for k, v in cp.items():
    print("comb %-10s %s" % (k, v))
json.dump(R, open(sys.argv[2], "w"), indent=1)
