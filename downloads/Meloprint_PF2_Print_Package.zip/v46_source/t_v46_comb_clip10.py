# -*- coding: utf-8 -*-
# v46: comb play after the clamp, comb insertion (-Y) contacts, and whether clip 10 is still needed.
import sys, json
sys.path.insert(0, r"C:\Users\Public\mbx_work")
from pf2_kin import load, posed
from mf_tool import inter_vol, xf_rotate
src, out = sys.argv[1], sys.argv[2]
M = load(src)
R = {}
for n, m in M.items():
    if m.status().name != "NoError" if hasattr(m.status(), "name") else False:
        print("MESH PROBLEM", n)


def free(P, mover, others, move, maxd):
    lo, hi = 0.0, maxd
    def hit(d):
        m = move(mover, d)
        for n in others:
            if inter_vol(m, P[n])[0] > 1e-4:
                return n
        return None
    if hit(maxd) is None:
        return None, maxd
    for _ in range(24):
        mid = (lo + hi) / 2
        if hit(mid):
            hi = mid
        else:
            lo = mid
    return hit(hi), round(lo, 4)


P = posed(M, 90)
c15 = [n for n in P if n.startswith("15")][0]; c16 = [n for n in P if n.startswith("16")][0]
comb = P[c15] + P[c16]
hold = [n for n in P if n[:2] in ("01", "02")]
# seated overlap (the designed squeeze) and remaining play
R["seated_overlap_mm3"] = {n: round(inter_vol(comb, P[n])[0], 4) for n in hold}
print("seated squeeze overlap:", R["seated_overlap_mm3"])
# play: shrink-free test = how far the comb moves before the overlap grows by > 0.02 mm3
base_v = sum(inter_vol(comb, P[n])[0] for n in hold)


def grow(move, maxd):
    lo, hi = 0.0, maxd
    def hit(d):
        m = move(comb, d)
        return sum(inter_vol(m, P[n])[0] for n in hold) > base_v + 0.02
    if not hit(maxd):
        return maxd
    for _ in range(22):
        mid = (lo + hi) / 2
        if hit(mid):
            hi = mid
        else:
            lo = mid
    return round(lo, 4)


play = {}
for lab, v in (("+X", (1, 0, 0)), ("-X", (-1, 0, 0)), ("+Y", (0, 1, 0)), ("-Y", (0, -1, 0)), ("+Z", (0, 0, 1)), ("-Z", (0, 0, -1))):
    play[lab] = grow(lambda m, d, v=v: m.translate((v[0] * d, v[1] * d, v[2] * d)), 1.0)
R["comb_play_mm"] = play
print("comb play after clamp:", play)
# insertion: overlap volume along the -Y stroke
ins = []
for k in range(0, 46):
    d = 45.0 - k
    m = comb.translate((0, d, 0))
    v = {n[:2]: round(inter_vol(m, P[n])[0], 3) for n in hold}
    if any(x > 0.01 for x in v.values()):
        ins.append((d, v))
R["insertion_contacts"] = ins
print("insertion contacts (offset mm, overlap per part):", ins)

# clip 10: main-gear lift with and without it
rows = []
for th in (0, 90, 180, 270):
    P = posed(M, th)
    oth = [n for n in P if n[:2] not in ("03", "15", "16")]
    w = free(P, P["03_MainGear_AP1"], oth, lambda m, d: m.translate((0, 0, d)), 3.0)
    wo = free(P, P["03_MainGear_AP1"], [n for n in oth if not n.startswith("10")], lambda m, d: m.translate((0, 0, d)), 3.0)
    rows.append({"theta": th, "with_clip10": w, "without_clip10": wo})
    print(rows[-1])
R["clip10"] = rows
json.dump(R, open(out, "w"), indent=1)
