# -*- coding: utf-8 -*-
# Rhino 7: v46 surface 3DMs from the v45 files. 01/02/04/11 replaced, 12 removed, dial screw + nut added to the hardware layer.
# Cross-checks with the Rhino kernel: solids, volumes vs OCC, interference of the new drive at several handle angles.
import math, json, traceback
import Rhino
import Rhino.Geometry as G
import scriptcontext as sc
import rhinoscriptsyntax as rs

W = r"C:\Users\Public\mbx_work"
O = W + r"\pf2_out"
LOG = open(W + r"\rh_build_v46.log", "w")
def L(*a):
    LOG.write(" ".join(str(x) for x in a) + "\n"); LOG.flush()
REV = "PF2-v46 dial bolted to gear, comb clamp, clip 12 removed"
HC = (0.0, -80.544)
CHANGE = {"01": "post D8.8 plain axle (snap cap removed); comb rail pads + crush ribs",
          "02": "comb rail pads under the cover",
          "04": "bore D9.1 on the post, solid hub with M3 nut pocket, 45 deg collar under the cover (lift stop)",
          "11": "U window and snap arms removed; closed hex socket; one M3x8 button-head screw clamps it to the gear"}


def import_step(path):
    doc = sc.doc
    before = set(o.Id for o in doc.Objects)
    rs.Command('_-Import "' + path + '" _Enter', False)
    new = [o for o in doc.Objects if o.Id not in before]
    for o in new:
        if isinstance(o, Rhino.DocObjects.InstanceObject):
            rs.ExplodeBlockInstance(o.Id, True)
    new = [o for o in doc.Objects if o.Id not in before and not isinstance(o, Rhino.DocObjects.InstanceObject)]
    bs = [o.Geometry.DuplicateBrep() for o in new if isinstance(o.Geometry, G.Brep)]
    for o in new:
        doc.Objects.Delete(o.Id, True)
    if len(bs) != 1:
        raise RuntimeError("%s: %d breps" % (path, len(bs)))
    return bs[0]


def cyl(cx, cy, r, z0, z1):
    return G.Cylinder(G.Circle(G.Plane(G.Point3d(cx, cy, z0), G.Vector3d.ZAxis), r), z1 - z0).ToBrep(True, True)


def hexprism(cx, cy, af, z0, z1, rot):
    rr = af / 2.0 / math.cos(math.radians(30))
    pts = [G.Point3d(cx + rr * math.cos(math.radians(rot + 60 * k)), cy + rr * math.sin(math.radians(rot + 60 * k)), z0) for k in range(7)]
    b = G.Surface.CreateExtrusion(G.PolylineCurve(pts), G.Vector3d(0, 0, z1 - z0)).ToBrep().CapPlanarHoles(0.001)
    if b.SolidOrientation == G.BrepSolidOrientation.Inward:
        b.Flip()
    return b


def vol(b):
    m = G.VolumeMassProperties.Compute(b)
    if m:
        return m.Volume
    mm = G.Mesh()
    for x in G.Mesh.CreateFromBrep(b, G.MeshingParameters.QualityRenderMesh):
        mm.Append(x)
    return abs(G.VolumeMassProperties.Compute(mm).Volume)


def ivol(a, b):
    if not G.BoundingBox.Intersection(a.GetBoundingBox(True), b.GetBoundingBox(True)).IsValid:
        return 0.0
    r = G.Brep.CreateBooleanIntersection(a, b, 0.001)
    if r is None:
        return None
    return sum(abs(G.VolumeMassProperties.Compute(x).Volume) for x in r if G.VolumeMassProperties.Compute(x))


try:
    occ = json.load(open(W + r"\v46_assets\export_v46.json"))["files"]
    cb = 29.394 - 1.70
    scr = G.Brep.CreateBooleanUnion([cyl(HC[0], HC[1], 2.85, cb, cb + 1.65), cyl(HC[0], HC[1], 1.5, cb - 8.0, cb + 0.5)], 0.001)[0]
    nut = G.Brep.CreateBooleanDifference(hexprism(HC[0], HC[1], 5.5, 22.1 - 2.4, 22.1, 30.0), cyl(HC[0], HC[1], 1.5, 18.0, 23.0), 0.001)[0]
    newhw = [("M3x8_ISO7380_Dial", scr), ("M3_Nut_DIN934_Dial", nut)]
    for tag, src, dst, base, cover, stepdir in (
            ("AP1", O + r"\Meloprint_PF2_v45_M3_Assembly.3dm", O + r"\Meloprint_PF2_v46_Assembly.3dm", "01_Base_AP1", "02_Cover_AP1", "STEP_v46"),
            ("MW4", O + r"\Meloprint_PF2_v45_M3_MW4_Assembly.3dm", O + r"\Meloprint_PF2_v46_MW4_Assembly.3dm", "01_Base_MW4", "02_Cover_MW4", "STEP_v46")):
        repl = {}
        for n in (base, cover, "11_HandleRetainer_AP1"):
            repl[n] = import_step(O + "\\" + stepdir + "\\" + n + ".step")
        f0 = Rhino.FileIO.File3dm.Read(src)
        # handle gear: same operations as dial_mods.gear_v46, done with Rhino booleans on the v45 gear (a STEP round trip
        # of the OCC result leaves three open seam edges in Rhino)
        g = [o.Geometry for o in f0.Objects if o.Attributes.Name == "04_Handle_AP1"][0].DuplicateBrep()
        g = G.Brep.CreateBooleanDifference(g, cyl(HC[0], HC[1], 4.55, -2.5, 19.5), 0.001)[0]
        g = G.Brep.CreateBooleanUnion([g, cyl(HC[0], HC[1], 4.6, 19.49, 25.15)], 0.001)[0]
        prof = G.Polyline([G.Point3d(HC[0] + 6.7, HC[1], 15.1), G.Point3d(HC[0] + 6.99, HC[1], 15.1), G.Point3d(HC[0] + 6.99, HC[1], 15.4),
                           G.Point3d(HC[0] + 8.8, HC[1], 17.2), G.Point3d(HC[0] + 6.7, HC[1], 17.2), G.Point3d(HC[0] + 6.7, HC[1], 15.1)])
        rev = G.RevSurface.Create(prof.ToNurbsCurve(), G.Line(G.Point3d(HC[0], HC[1], 0), G.Point3d(HC[0], HC[1], 1))).ToBrep()
        if rev.SolidOrientation == G.BrepSolidOrientation.Inward:
            rev.Flip()
        g = G.Brep.CreateBooleanUnion([g, rev], 0.001)[0]
        g = G.Brep.CreateBooleanDifference([g], [cyl(HC[0], HC[1], 1.6, 19.4, 25.3), hexprism(HC[0], HC[1], 5.75, 19.45, 22.1, 30.0)], 0.001)[0]
        L("  gear rebuilt in Rhino: solid=%s valid=%s vol=%.2f" % (g.IsSolid, g.IsValid, vol(g)))
        repl["04_Handle_AP1"] = g
        f = Rhino.FileIO.File3dm()
        f.Settings.ModelUnitSystem = f0.Settings.ModelUnitSystem
        f.Settings.ModelAbsoluteTolerance = f0.Settings.ModelAbsoluteTolerance
        lay0 = dict((l.Index, l.Name) for l in f0.AllLayers)
        for l in f0.AllLayers:
            if l.Name.startswith("12_"):
                continue
            nl = Rhino.DocObjects.Layer(); nl.Name = l.Name; nl.Color = l.Color
            f.AllLayers.Add(nl)
        idx = dict((l.Name, l.Index) for l in f.AllLayers)
        hwl = [l.Name for l in f.AllLayers if l.Name.startswith("M3_Hardware")][0]
        geo, faces = {}, 0
        for o in f0.Objects:
            n = o.Attributes.Name
            if n.startswith("12_"):
                continue
            a = o.Attributes.Duplicate(); a.LayerIndex = idx[lay0[o.Attributes.LayerIndex]]
            b = repl[n].DuplicateBrep() if n in repl else o.Geometry.DuplicateBrep()
            if n in repl:
                a.SetUserString("Revision", REV); a.SetUserString("Change", CHANGE[n[:2]])
            f.Objects.AddBrep(b, a); geo[n] = b
            if not n.startswith("M3"):
                faces += b.Faces.Count
        for n, b in newhw:
            a = Rhino.DocObjects.ObjectAttributes(); a.Name = n; a.LayerIndex = idx[hwl]
            a.SetUserString("Printable", "No"); a.SetUserString("Part", n); a.SetUserString("Revision", REV)
            f.Objects.AddBrep(b, a); geo[n] = b
        f.Strings.SetString("MeloprintRevision", "PF2-v46")
        f.Strings.SetString("Changes", "v46 = v45 + dial bolted to the handle gear (no snap hooks), plain D8.8 post, comb rail clamp, clip 12 removed")
        f.Write(dst, 7)
        back = Rhino.FileIO.File3dm.Read(dst)
        bad = [o.Attributes.Name for o in back.Objects if not (isinstance(o.Geometry, G.Brep) and o.Geometry.IsSolid and o.Geometry.IsValid)]
        L("%s saved archive=%d objects=%d printed-part faces=%d bad=%s" % (dst, Rhino.FileIO.File3dm.ReadArchiveVersion(dst), len(back.Objects), faces, bad))
        for n in (base, "04_Handle_AP1", "11_HandleRetainer_AP1"):
            key = "assets/pf2/%s.stl" % n
            L("  %-22s rhino vol %.2f  occ-mesh vol %s" % (n, vol(geo[n]), occ.get(key, {}).get("volume")))
        # drive: gear + dial + screw + nut rotate together; check against post, cover, main gear, yoke at several angles
        for th in (0.0, 45.0, 90.0, 180.0):
            xf = G.Transform.Rotation(math.radians(1.5 * th), G.Vector3d.ZAxis, G.Point3d(HC[0], HC[1], 0))
            xm = G.Transform.Rotation(math.radians(-th), G.Vector3d.ZAxis, G.Point3d(0.0, -23.218, 0))
            mg = geo["03_MainGear_AP1"].DuplicateBrep(); mg.Transform(xm)
            stat = {base: geo[base], cover: geo[cover], "03_MainGear_AP1": mg, "23_RearGuideRail": geo["23_RearGuideRail"]}
            row = []
            for mv in ("04_Handle_AP1", "11_HandleRetainer_AP1", "M3x8_ISO7380_Dial", "M3_Nut_DIN934_Dial"):
                m = geo[mv].DuplicateBrep(); m.Transform(xf)
                for st in (base, cover, "03_MainGear_AP1", "23_RearGuideRail"):
                    v = ivol(m, stat[st])
                    if v is None or v > 1e-3:
                        row.append("%s-%s:%s" % (mv[:2], st[:2], v))
            L("  handle %3.0f deg: %s" % (1.5 * th, "no overlaps" if not row else " ".join(row)))
        pc = geo["11_HandleRetainer_AP1"].DuplicateBrep(); pc.Translate(G.Vector3d(0, 0, -0.8))
        L("  positive control: dial pushed 0.8 mm down overlaps cover by %s mm3" % ivol(pc, geo[cover]))
except Exception:
    L("ERR", traceback.format_exc())
L("##DONE##")
LOG.close()
