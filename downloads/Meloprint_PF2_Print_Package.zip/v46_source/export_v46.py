# -*- coding: utf-8 -*-
# v46 exports: STEP (B-rep) + viewer STLs (assembly frame) + print STLs (site orientation rules) for the changed parts,
# the 14 decorative cover STLs with the comb pads, and one viewer mesh for all M3 hardware.
import sys, os, json
sys.argv = [sys.argv[0], r"C:\Users\Public\mbx_work\pf2_out"]
sys.path.insert(0, r"C:\Users\Public\mbx_work")
import numpy as np, trimesh, manifold3d as m3
from ap1_view import load_cache
from mf_tool import to_manifold
from ap1_export import step_write, write_stl
import comb_clamp as CC
OUT = r"C:\Users\Public\mbx_work\v46_assets"
STEP = r"C:\Users\Public\mbx_work\pf2_out\STEP_v46"
os.makedirs(STEP, exist_ok=True)
AP = load_cache(r"C:\Users\Public\mbx_work\in\pf2v46_brep")
MW = load_cache(r"C:\Users\Public\mbx_work\in\pf2v46mw4_brep")
HW = load_cache(r"C:\Users\Public\mbx_work\in\pf2v46_hw")
ROT = json.load(open(r"C:\Users\Public\mbx_work\print_rot.json"))
FLIP = np.array([[1, 0, 0], [0, -1, 0], [0, 0, -1]], float)
rep = {}


def mesh(s, defl=0.004):
    mm = to_manifold(s, defl)
    assert mm.status() == m3.Error.NoError, "mesh"
    mm = mm.to_mesh()
    return np.array(mm.vert_properties)[:, :3].astype(float), np.array(mm.tri_verts).astype(np.int64)


def put(rel, V, F, name):
    p = os.path.join(OUT, rel)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    write_stl(p, V, F, name)
    t = trimesh.load(p)
    rep[rel] = {"tris": int(len(F)), "watertight": bool(t.is_watertight), "volume": round(float(t.volume), 2), "size": [round(float(v), 2) for v in t.extents]}
    print("%-50s %s" % (rel, rep[rel]))


def center(W, y0=False):
    return W - np.array([(W[:, 0].min() + W[:, 0].max()) / 2, W[:, 1].min() if y0 else (W[:, 1].min() + W[:, 1].max()) / 2, W[:, 2].min()])


jobs = [("01_Base_AP1", AP["01_Base_AP1"]), ("02_Cover_AP1", AP["02_Cover_AP1"]), ("04_Handle_AP1", AP["04_Handle_AP1"]),
        ("11_HandleRetainer_AP1", AP["11_HandleRetainer_AP1"]), ("01_Base_MW4", MW["01_Base_MW4"]), ("02_Cover_MW4", MW["02_Cover_MW4"])]
for n, s in jobs:
    step_write([(n, s)], os.path.join(STEP, n + ".step"))
    V, F = mesh(s)
    if n != "02_Cover_MW4":
        put("assets/pf2/%s.stl" % n, V, F, n)
    pk = "pkg_mw4" if "MW4" in n else "pkg"
    if n.startswith("01"):
        put("%s/print_stl/%s_PRINT.stl" % (pk, n), center(V.copy()), F, n)
        if "MW4" in n:
            put("models/01_Base_MW4_PRINT.stl", center(V.copy(), y0=True), F, n)
    elif n.startswith("02"):
        put("%s/print_stl/%s_PRINT.stl" % (pk, n), center(V @ FLIP.T), F, n)
    else:
        put("pkg/print_stl/%s.stl" % n, center(V @ np.array(ROT["print_stl/%s.stl" % n]["R"], float).T), F, n)
# hardware
Vs, Fs, off = [], [], 0
for n in sorted(HW):
    V, F = mesh(HW[n], 0.01)
    Vs.append(V); Fs.append(F + off); off += len(V)
put("assets/pf2/M3_Hardware.stl", np.vstack(Vs), np.vstack(Fs), "M3_Hardware")
step_write([(n, HW[n]) for n in sorted(HW)], os.path.join(STEP, "M3_Hardware.step"))
# decorative covers: v45 meshes (with M3 holes) + comb pads
LB = {"base": (0.030805587768554688, -30.558719635009766, 20.73442268371582)}
for k in ("chrome", "acid", "pink", "ice", "orange", "purple"):
    LB[k] = (0.030805587768554688, -30.558719635009766, 21.134403228759766)
cov = {}
for pre, ceil in (("", 12.442), ("mw4_", 13.422)):
    for k, (cx, cy, zz) in LB.items():
        fn = "%s02_Cover_PF2_%s_PRINT.stl" % (pre, k)
        t = trimesh.load(os.path.join(r"C:\Users\Public\mbx_work\site_v45\models", fn)); t.merge_vertices()
        V = np.c_[t.vertices[:, 0] + cx, cy - t.vertices[:, 1], zz - t.vertices[:, 2]]
        C0 = m3.Manifold(m3.Mesh(vert_properties=V.astype(np.float32), tri_verts=t.faces.astype(np.uint32)))
        C1 = CC.cover_clamp_mesh(m3, C0, ceil, mw4=(pre == "mw4_"))
        mm = C1.to_mesh()
        W = np.array(mm.vert_properties)[:, :3].astype(float); F = np.array(mm.tri_verts).astype(np.int64)
        P = np.c_[W[:, 0] - cx, cy - W[:, 1], zz - W[:, 2]]
        put("models/" + fn, P, F, fn[:-4])
        cov[pre + k] = round(C1.volume() - C0.volume(), 3)
print("cover pad volume added per design:", cov)
json.dump({"files": rep, "cover_pad_dV": cov}, open(os.path.join(OUT, "export_v46.json"), "w"), indent=1)
