# -*- coding: utf-8 -*-
# v46 checks: dial/gear unit (rotating with the screw and nut), lift/drop stops, wobble, assembly path, hardware.
import sys, json, math
sys.path.insert(0, r"C:\Users\Public\mbx_work")
from ap1_view import load_cache
from mf_tool import to_manifold, inter_vol, xf_rotate
from pf2_kin import part_xf, HANDLE_C
src = sys.argv[1]
out = sys.argv[2]
S = load_cache(src)
HW = load_cache(r"C:\Users\Public\mbx_work\in\pf2v46_hw")
M = {n: to_manifold(s, 0.005) for n, s in S.items()}
H = {n: to_manifold(s, 0.005) for n, s in HW.items()}
R = {}
UNIT = ["04_Handle_AP1", "11_HandleRetainer_AP1"]


def pose(th):
    P = {}
    for n, m in M.items():
        xf = part_xf(n, th)
        P[n] = m.transform(xf) if xf is not None else m
    xf = part_xf("04", th)
    for n, m in H.items():
        P[n] = m.transform(xf) if n.endswith("_Dial") else m
    return P


# 1) every pair (incl. hardware) at several handle angles: overlaps other than the designed pluck
bad = []
for th in (0, 30, 60, 90, 135, 180, 270):
    P = pose(th)
    names = sorted(P)
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            a, b = names[i], names[j]
            if (a[:2] in ("15", "16") and b.startswith("05")) or (b[:2] in ("15", "16") and a.startswith("05")):
                continue
            v, bb = inter_vol(P[a], P[b])
            if v > 1e-3:
                bad.append((th, a, b, round(v, 4)))
R["overlaps"] = bad
print("overlaps (excluding pluck):", bad[:10], len(bad))

# 2) clearances of the new drive
P = pose(0)
gp = lambda a, b, lim=3.0: round(P[a].min_gap(P[b], lim), 3)
R["gaps"] = {"gear-post": gp("04_Handle_AP1", "01_Base_AP1"), "gear(collar)-cover": gp("04_Handle_AP1", "02_Cover_AP1"),
             "dial-cover": gp("11_HandleRetainer_AP1", "02_Cover_AP1"), "gear-yoke": gp("04_Handle_AP1", "05_Yoke_AP1"),
             "gear-rail23": gp("04_Handle_AP1", "23_RearGuideRail"), "dial-gear": gp("11_HandleRetainer_AP1", "04_Handle_AP1"),
             "dialscrew-post": gp("HW_M3x8_Button_Dial", "01_Base_AP1"), "dialnut-post": gp("HW_M3_Nut_Dial", "01_Base_AP1")}
print("gaps:", R["gaps"])

# 3) the rotating unit as one body: free lift / drop and wobble (tilt about horizontal axes through the hub)
unit = P["04_Handle_AP1"] + P["11_HandleRetainer_AP1"] + P["HW_M3x8_Button_Dial"] + P["HW_M3_Nut_Dial"]
others = {n: P[n] for n in P if n not in UNIT and not n.endswith("_Dial") and n[:2] not in ("15", "16")}


def free(move, maxd=3.0):
    lo, hi = 0.0, maxd
    def hit(d):
        m = move(d)
        for n, o in others.items():
            if inter_vol(m, o)[0] > 1e-4:
                return n
        return None
    if hit(maxd) is None:
        return None, maxd
    for _ in range(24):
        mid = (lo + hi) / 2
        if hit(mid):
            hi = mid
        else:
            lo = mid
    return hit(hi), round(lo, 4)


R["unit_lift"] = free(lambda d: unit.translate((0, 0, d)))
R["unit_drop"] = free(lambda d: unit.translate((0, 0, -d)))
tilt = {}
for ax, axis in (("about X", (1, 0, 0)), ("about Y", (0, 1, 0))):
    for sgn in (1, -1):
        tilt["%s %+d" % (ax, sgn)] = free(lambda a: unit.transform(xf_rotate(sgn * a, (HANDLE_C[0], HANDLE_C[1], 10.0), axis)), 5.0)
R["unit_tilt_deg"] = tilt
print("unit lift", R["unit_lift"], "drop", R["unit_drop"])
print("unit tilt (deg, first contact):", tilt)
json.dump(R, open(out, "w"), indent=1)
