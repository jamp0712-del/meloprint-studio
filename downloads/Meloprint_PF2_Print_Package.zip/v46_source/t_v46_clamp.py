# -*- coding: utf-8 -*-
# Apply the comb clamp to the v46 caches and drop clip 12.  Run after t_v46_build.py (which restores the unclamped base/cover).
import sys, os
sys.path.insert(0, r"C:\Users\Public\mbx_work")
from ap1_view import load_cache
from ap1_tool import n_solids, valid
from occ_conv import volume
from OCP.BRepTools import BRepTools
import comb_clamp as CC
W = r"C:\Users\Public\mbx_work\in"
for tag, d, bn, cn in (("AP1", W + r"\pf2v46_brep", "01_Base_AP1", "02_Cover_AP1"), ("MW4", W + r"\pf2v46mw4_brep", "01_Base_MW4", "02_Cover_MW4")):
    S = load_cache(d)
    if tag == "AP1":
        B2, C2 = CC.base_clamp(S[bn], 4.302), CC.cover_clamp(S[cn], 12.442)
    else:
        B2, C2 = CC.base_ribs_only(S[bn]), CC.cover_clamp_mw4(S[cn])
    for n, s, s0 in ((bn, B2, S[bn]), (cn, C2, S[cn])):
        print("%s %-14s solids=%d valid=%s vol=%.2f (d=%.2f)" % (tag, n, n_solids(s), valid(s), volume(s), volume(s) - volume(s0)))
    BRepTools.Write_s(B2, os.path.join(d, bn + ".brep"))
    BRepTools.Write_s(C2, os.path.join(d, cn + ".brep"))
    for dd in (d,) + ((W + r"\pf2v46mw4_valid",) if tag == "MW4" else ()):
        p12 = os.path.join(dd, "12_RollerRetainer_AP1.brep")
        if os.path.exists(p12):
            os.remove(p12)
    if tag == "MW4":
        v = W + r"\pf2v46mw4_valid"
        BRepTools.Write_s(B2, os.path.join(v, "01_Base_AP1.brep")); BRepTools.Write_s(C2, os.path.join(v, "02_Cover_AP1.brep"))
