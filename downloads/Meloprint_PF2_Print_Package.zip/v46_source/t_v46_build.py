# -*- coding: utf-8 -*-
import sys, os, time
sys.path.insert(0, r"C:\Users\Public\mbx_work")
from ap1_view import load_cache
from ap1_tool import n_solids, valid
from occ_conv import volume
from OCP.BRepTools import BRepTools
import dial_mods as DM

W = r"C:\Users\Public\mbx_work\in"


def save(d, shapes):
    os.makedirs(d, exist_ok=True)
    for f in os.listdir(d):
        os.remove(os.path.join(d, f))
    for n, s in shapes.items():
        BRepTools.Write_s(s, os.path.join(d, n + ".brep"))


def rep(n, s, s0=None):
    print("%-22s solids=%d valid=%s vol=%.2f%s" % (n, n_solids(s), valid(s), volume(s), "" if s0 is None else " (d=%.2f)" % (volume(s) - volume(s0))))


t = time.time()
dial = DM.dial_v46(load_cache(W + r"\pf2m3_brep")["11_HandleRetainer_AP1"])
gear = DM.gear_v46(load_cache(W + r"\pf2m3_brep")["04_Handle_AP1"])
cap = None
for src, dst, base in ((W + r"\pf2m3_brep", W + r"\pf2v46_brep", "01_Base_AP1"), (W + r"\pf2m3mw4_brep", W + r"\pf2v46mw4_brep", "01_Base_MW4")):
    S = load_cache(src)
    out = dict(S)
    out[base] = DM.base_v46(S[base])
    out["04_Handle_AP1"] = gear
    out["11_HandleRetainer_AP1"] = dial
    for n in (base, "04_Handle_AP1", "11_HandleRetainer_AP1"):
        rep(n, out[n], S[n])
    save(dst, out)
    if "MW4" in base:
        A = {"01_Base_MW4": "01_Base_AP1", "02_Cover_MW4": "02_Cover_AP1", "15_CombLower_MW4": "15_CombLower_AP1", "16_CombUpper_MW4": "16_CombUpper_AP1"}
        save(W + r"\pf2v46mw4_valid", {A.get(n, n): s for n, s in out.items()})
HW = load_cache(W + r"\pf2m3_hw")
HW.update(DM.hardware_v46())
save(W + r"\pf2v46_hw", HW)
for n in DM.hardware_v46():
    rep(n, HW[n])
print("%.0fs" % (time.time() - t))
