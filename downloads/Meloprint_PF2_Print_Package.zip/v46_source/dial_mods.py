# -*- coding: utf-8 -*-
# PF2 v46 handle drive: the dial is screwed to the handle gear and turns with it as one rigid unit.
#  - 01 base post: plain solid D8.8 axle up to z 19.3 (old neck and 0.4 mm snap cap removed).
#  - 04 handle gear: bore D9.2 (0.2 mm on the post) up to z 19.5, solid hub above with an M3 nut pocket (nut fed up the bore)
#    and a 45 deg collar that stops the gear+dial unit 0.2 mm under the cover (replaces the snap hooks as lift stop).
#  - 11 dial: U window, spring arms and tongue filled; grooves continue; closed hex socket (AF 12.3) whose ceiling clamps on
#    the gear hex top; counterbore for one M3x8 ISO 7380 button-head screw (head flush with the top).
# No cap part, no washer: 13 -> 12 printed parts compared with a cap solution, and zero play between dial and gear.
import sys, math
sys.path.insert(0, r"C:\Users\Public\mbx_work")
from ap1_tool import box, cyl, cut, fuse
from ap1_mods import hexagon, revolve_rz, common

CX, CY = 0.0, -80.544
DIAL_BOT, DIAL_TOP = 21.4, 29.394
GROOVES = [(11.55, 12.45), (16.55, 17.45)]           # concentric rings crossing the filled window, 0.9 wide, to z 28.6
GROOVE_Z = 28.6
POST_R, POST_TOP = 4.4, 19.3
GEAR_BORE_R, BORE_TOP = 4.55, 19.5          # 0.15 mm on the D8.8 post
HEX_TOP = 25.2                                         # gear hex AF 12.0, z 21.4-25.2
HEX_AF = 12.3
NUT_AF, NUT_Z0, NUT_Z1, NUT_ROT = 5.75, 19.45, 22.1, 30.0
COLLAR_R, COLLAR_TOP, COVER_UNDER = 8.8, 17.2, 17.4
HUB_R = 7.0
SCREW_HOLE_R, CB_R = 1.7, 3.05                         # ISO 7380 M3: head D5.7 x 1.65
CB_SEAT = DIAL_TOP - 1.70
SCREW_L, HEAD_R, HEAD_H, NUT_T = 8.0, 2.85, 1.65, 2.4


def base_v46(B):
    B = cut(B, cyl(CX, CY, 4.6, POST_TOP, 28.5))
    return fuse(B, cyl(CX, CY, POST_R, -3.0, POST_TOP))


def gear_v46(G):
    G = cut(G, cyl(CX, CY, GEAR_BORE_R, -2.5, BORE_TOP))
    G = fuse(G, cyl(CX, CY, GEAR_BORE_R + 0.05, BORE_TOP - 0.01, HEX_TOP - 0.05))   # 0.05 below the hex top: no coplanar seam
    h = COLLAR_R - HUB_R
    collar = revolve_rz([(HUB_R - 0.3, COLLAR_TOP - h - 0.3), (HUB_R - 0.01, COLLAR_TOP - h - 0.3), (HUB_R - 0.01, COLLAR_TOP - h),
                         (COLLAR_R, COLLAR_TOP), (HUB_R - 0.3, COLLAR_TOP)], CX, CY)
    G = fuse(G, collar)
    return cut(G, cyl(CX, CY, 1.6, BORE_TOP - 0.1, HEX_TOP + 0.1), hexagon(CX, CY, NUT_AF, NUT_Z0, NUT_Z1, NUT_ROT))


DIAL_R = 41.223
ALL_GROOVES = [(11.55 + 5 * k, 12.45 + 5 * k) for k in range(6)]   # measured on the v43 dial: 0.9 wide, 0.794 deep, 5 mm pitch


def dial_v46(D=None):
    # Rebuilt from primitives with the measured v43 dimensions (filling the old window produced sliver faces):
    # plain disc, six concentric grooves, closed hex socket, one counterbored M3 screw. The old U window is gone.
    D = cyl(CX, CY, DIAL_R, DIAL_BOT, DIAL_TOP)
    D = cut(D, *[cut(cyl(CX, CY, ro, GROOVE_Z, DIAL_TOP + 0.3), cyl(CX, CY, ri, GROOVE_Z - 0.1, DIAL_TOP + 0.4)) for ri, ro in ALL_GROOVES])
    return cut(D,hexagon(CX, CY, HEX_AF, DIAL_BOT - 0.1, HEX_TOP, 30.0), cyl(CX, CY, SCREW_HOLE_R, HEX_TOP - 0.05, CB_SEAT + 0.01),
               cyl(CX, CY, CB_R, CB_SEAT, DIAL_TOP + 0.3))


def hardware_v46():
    scr = fuse(cyl(CX, CY, HEAD_R, CB_SEAT, CB_SEAT + HEAD_H), cyl(CX, CY, 1.5, CB_SEAT - SCREW_L, CB_SEAT + 0.01))
    nut = cut(hexagon(CX, CY, 5.5, NUT_Z1 - NUT_T, NUT_Z1, NUT_ROT), cyl(CX, CY, 1.5, NUT_Z1 - NUT_T - 1, NUT_Z1 + 1))
    return {"HW_M3x8_Button_Dial": scr, "HW_M3_Nut_Dial": nut}
