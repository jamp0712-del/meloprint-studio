# -*- coding: utf-8 -*-
# Build site_v46 from site_v45: assets, covers, packages, CAD descriptors, code and text patches.
import os, re, shutil, zipfile, hashlib, json
W = r"C:\Users\Public\mbx_work"
S45, D = W + r"\site_v45", W + r"\site_v46"
A = W + r"\v46_assets"
O = W + r"\pf2_out"
sha = lambda b: hashlib.sha256(b).hexdigest()
rd = lambda p: open(p, "rb").read()
shutil.rmtree(D, ignore_errors=True)
shutil.copytree(S45, D)
for n in ("01_Base_AP1", "01_Base_MW4", "02_Cover_AP1", "04_Handle_AP1", "11_HandleRetainer_AP1", "M3_Hardware"):
    shutil.copy2(os.path.join(A, "assets", "pf2", n + ".stl"), os.path.join(D, "assets", "pf2"))
os.remove(os.path.join(D, "assets", "pf2", "12_RollerRetainer_AP1.stl"))
for f in os.listdir(os.path.join(A, "models")):
    shutil.copy2(os.path.join(A, "models", f), os.path.join(D, "models", f))
for f in os.listdir(os.path.join(D, "cad")):
    if f.endswith(".3dm"):
        os.remove(os.path.join(D, "cad", f))
for f in ("Meloprint_PF2_v46_Assembly.3dm", "Meloprint_PF2_v46_MW4_Assembly.3dm"):
    shutil.copy2(os.path.join(O, f), os.path.join(D, "cad", f))
checks = {"v46_checks/drive-dial-unit.json": rd(W + r"\v46_checks.json"), "v46_checks/drive-dial-unit-mw4.json": rd(W + r"\v46_checks_mw4.json"),
          "v46_checks/assembly-path.json": rd(W + r"\v46_asm.json"), "v46_checks/assembly-path-mw4.json": rd(W + r"\v46_asm_mw4.json"),
          "v46_checks/comb-clamp-clip10.json": rd(W + r"\v46_comb.json"), "v46_checks/comb-clamp-clip10-mw4.json": rd(W + r"\v46_comb_mw4.json"),
          "v46_checks/clip12-and-comb-play-before.json": rd(W + r"\v46_extra.json"),
          "v46_checks/motion-checks.json": rd(W + r"\val_v46.json"), "v46_checks/motion-checks-mw4.json": rd(W + r"\val_v46_mw4.json"),
          "v46_checks/yoke-support.txt": rd(W + r"\sup_v46.txt"), "v46_checks/rhino7-build.log": rd(W + r"\rh_build_v46.log"),
          "v46_checks/export.json": rd(A + r"\export_v46.json")}
sources = {"v46_source/" + f: rd(os.path.join(W, f)) for f in ("dial_mods.py", "comb_clamp.py", "t_v46_build.py", "t_v46_clamp.py", "t_v46_validate.py",
                                                                "t_v46_extra.py", "t_v46_comb_clip10.py", "t_v46_assembly.py", "export_v46.py",
                                                                "rh_build_v46.py", "build_v46_site.py")}
readme = rd(W + r"\v46_doc\README_KO.md")
info = {}
for tag, zname, d3dm, base, cover, pk in (("current", "Meloprint_PF2_Print_Package.zip", "Meloprint_PF2_v46_Assembly.3dm", "01_Base_AP1", "02_Cover_AP1", "pkg"),
                                          ("makerworld", "Meloprint_PF2_MW4_Print_Package.zip", "Meloprint_PF2_v46_MW4_Assembly.3dm", "01_Base_MW4", "02_Cover_MW4", "pkg_mw4")):
    zin = zipfile.ZipFile(os.path.join(S45, "downloads", zname))
    repl = {"print_stl/%s_PRINT.stl" % base: rd(os.path.join(A, pk, "print_stl", base + "_PRINT.stl")),
            "print_stl/%s_PRINT.stl" % cover: rd(os.path.join(A, pk, "print_stl", cover + "_PRINT.stl")),
            "print_stl/04_Handle_AP1.stl": rd(os.path.join(A, "pkg", "print_stl", "04_Handle_AP1.stl")),
            "print_stl/11_HandleRetainer_AP1.stl": rd(os.path.join(A, "pkg", "print_stl", "11_HandleRetainer_AP1.stl"))}
    entries = []
    for i in zin.infolist():
        n = i.filename
        if n.startswith("print_stl/12_") or n in ("SHA256.json", "3dm_checks.json") or (n.endswith(".3dm") and "/" not in n):
            continue
        if n == "README_KO.md":
            entries.append(("history/v45/README_KO.md", zin.read(n))); entries.append((n, readme)); continue
        entries.append((n, repl.get(n, zin.read(n))))
    b3 = rd(os.path.join(O, d3dm))
    entries.append((d3dm, b3))
    for n in (base, cover, "04_Handle_AP1", "11_HandleRetainer_AP1", "M3_Hardware"):
        entries.append(("v46_native_parts/%s.step" % n, rd(os.path.join(O, "STEP_v46", n + ".step"))))
    entries += sorted(checks.items()) + sorted(sources.items())
    faces = {"current": 2533, "makerworld": 2174}[tag]
    desc = {"file": "cad/" + d3dm, "filename": d3dm, "bytes": len(b3), "sha256": sha(b3), "parts": 11,
            "hardware": "4x M3x20 DIN912, 1x M3x8 ISO7380, 5x M3 DIN934", "revision": "PF2", "fixedSample": True, "faces": faces,
            "assemblyRevision": "PF2-v46", "combStyle": tag, "rhinoArchiveVersion": 7}
    info[tag] = desc
    entries.append(("3dm_checks.json", json.dumps({tag: desc}, indent=2).encode()))
    names = [n for n, _ in entries]
    assert len(names) == len(set(names)), [n for n in names if names.count(n) > 1]
    entries.append(("SHA256.json", json.dumps({n: sha(b) for n, b in entries}, indent=2).encode()))
    out = os.path.join(D, "downloads", zname)
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for n, b in entries:
            z.writestr(n, b)
    stl = [n for n in names if re.match(r"^print_stl/\d{2}_.*\.stl$", n) and not re.match(r"^print_stl/(02|15|16)_", n)]
    print(zname, "entries", len(entries), "MB %.1f" % (os.path.getsize(out) / 1e6), "mechanism STLs", len(stl), sorted(s[10:12] for s in stl))
    json.dump(desc, open(os.path.join(D, "cad", "pf2-surface.json" if tag == "current" else "pf2-surface-mw4.json"), "w"), indent=2)


def esc(t):
    return "".join(c if ord(c) < 128 else ("\\x%02X" % ord(c) if ord(c) < 256 else "\\u%04X" % ord(c)) for c in t)


def patch(rel, reps):
    p = os.path.join(D, rel)
    s = open(p, encoding="utf-8").read()
    for old, new, n in reps:
        c = s.count(old)
        assert c == n, (rel, old[:70], c, n)
        s = s.replace(old, new)
    open(p, "w", encoding="utf-8", newline="").write(s)
    print("patched", rel, len(reps))


patch("app.js", [
    ('{key:"rollerRetainer",name:"12_RollerRetainer_AP1",file:"assets/pf2/12_RollerRetainer_AP1.stl",motion:"roller"},', "", 1),
    (esc("PF2 전체 12부품 + M3×20 나사·너트 4세트"), esc("PF2 전체 11부품 + M3 나사·너트 5세트"), 1),
    (esc("출력 부품 12개 + M3 나사·너트 8개 서피스 솔리드"), esc("출력 부품 11개 + M3 나사·너트 10개 서피스 솔리드"), 2),
    (esc("12부품"), esc("11부품"), 3),
    (esc("12개"), esc("11개"), 2),
    ('"v45 ' + esc("기본"), '"v46 ' + esc("기본"), 1),
    ('"v45 MW4 ', '"v46 MW4 ', 1),
    ("mm_12_Parts_M3.zip", "mm_11_Parts_M3.zip", 1),
    (".length!==12)throw", ".length!==11)throw", 1),
])
patch("pf2-parts.js", [('{"key": "rollerRetainer", "name": "12_RollerRetainer_AP1", "file": "assets/pf2/12_RollerRetainer_AP1.stl", "motion": "roller"}, ', "", 1)])
V46 = ('<p class="hint"><strong>v46 · 출력 부품 11개.</strong> 다이얼을 M3 볼트 하나로 손잡이 기어에 조여 한 덩어리로 돌게 했습니다. '
       '걸쇠·U자 창이 없는 통짜 원판이라 세게 돌려도 비틀리거나 빠지지 않습니다. 빗은 레일 패드와 압착 리브로 좌우·위아래 유격 없이 고정됩니다. 롤러 클립(12번)은 필요 없어 뺐습니다.</p>')
patch("index.html", [
    ('<p class="eyebrow">PF2 v45 · 12 PRINTED PARTS + M3 SCREWS</p>', '<p class="eyebrow">PF2 v46 · 11 PRINTED PARTS + M3 SCREWS</p>', 1),
    ("<h2>전체 모델링 다운로드</h2>", "<h2>전체 모델링 다운로드</h2>" + V46, 1),
    ("v45에서 케이스 락 4개를 M3 나사로 바꿔 출력 부품은 12개입니다.", "v45에서 케이스 락 4개를 M3 나사로, v46에서 롤러 클립을 없애 출력 부품은 11개입니다.", 1),
    ("작은 기능 클립 2개는 남아 있습니다.", "작은 클립은 메인기어용 1개만 남았습니다.", 1),
    ("선택 상판·현재 멜로디 ZIP · 12부품 + M3", "선택 상판·현재 멜로디 ZIP · 11부품 + M3", 1),
    ("현재 설정 전체 3DM · 12개 메시", "현재 설정 전체 3DM · 11개 메시", 1),
    ("v45 기본 상판 고정 샘플 · 서피스 3DM (Rhino 7)", "v46 기본 상판 고정 샘플 · 서피스 3DM (Rhino 7)", 1),
    ("출력 부품 12개의 닫힌 서피스 솔리드와 M3 나사·너트 8개(별도 레이어)가 들어 있습니다(Rhino 7 형식, 출력 부품 면 수 일반 2,535 / MW4 2,188).",
     "출력 부품 11개의 닫힌 서피스 솔리드와 M3 나사·너트 10개(별도 레이어)가 들어 있습니다(Rhino 7 형식, 출력 부품 면 수 일반 2,533 / MW4 2,174).", 1),
    ("v45 현재형 고정 샘플 전체 ZIP · STEP·3DM·설명서", "v46 현재형 고정 샘플 전체 ZIP · STEP·3DM·설명서", 1),
    ("v45 MW4 33음 고정 샘플 전체 ZIP · STEP·3DM", "v46 MW4 33음 고정 샘플 전체 ZIP · STEP·3DM", 1),
    ("<strong>v45 조립 순서:</strong> 04 아래 기어 → <strong>23 레일(핀을 베이스 구멍에)</strong> → 03 메인기어·10 클립 → 06 롤러·12 클립 → 05 화살표 → 화살표를 가운데 두고 02 상판 → <strong>베이스 바닥 육각 홈에 M3 너트 4개, 상판 위에서 M3×20 나사 4개</strong> → 11 손잡이 원판 → 화살표를 끝으로 옮기고 15/16 빗.",
     "<strong>v46 조립 순서:</strong> 손잡이 기어 구멍으로 M3 너트를 밀어 넣고 → 04 기어를 기둥에 → 23 레일 → 03 메인기어·10 클립 → 06 롤러 → 05 화살표 → 화살표를 가운데 두고 02 상판, 바닥 너트 4개 + M3×20 4개 → <strong>11 다이얼을 육각에 끼우고 M3×8 둥근머리 볼트로 조임</strong> → 화살표를 끝으로 옮기고 15/16 빗.", 1),
    ("선택 상판으로 전체 12부품 ZIP", "선택 상판으로 전체 11부품 ZIP", 1),
    ("외형 크기는 유지하고 출력 부품은 12개 + M3 나사 4세트입니다. 기존 3종도 v45 일반형 베이스·상판을 사용합니다.",
     "외형 크기는 유지하고 출력 부품은 11개 + M3 나사 5세트입니다. 기존 3종도 v46 일반형 베이스·상판을 사용합니다.", 1),
    ("PF2 12부품 + M3 나사 구조(v45)를 사용하며 빗은 15·16번입니다.", "PF2 11부품 + M3 나사 구조(v46)를 사용하며 빗은 15·16번입니다.", 1),
    ("<strong>PF2 32 Stable · v45 M3</strong>", "<strong>PF2 32 Stable · v46</strong>", 1),
])
print(json.dumps(info, indent=1))
