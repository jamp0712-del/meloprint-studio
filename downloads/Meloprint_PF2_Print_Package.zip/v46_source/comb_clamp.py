# -*- coding: utf-8 -*-
# Comb clamp (v46): the comb pair is held by pads that only touch its two side rails (x 32.93-34.13, root area),
# so tines never slide over them during insertion.
#  - base pads lift 0.05 mm into the lower rail, cover pads press 0.05 mm onto the upper rail -> no vertical play once
#    the cover is screwed down; 0.3 mm 45 deg chamfers on the entry (+Y) edge.
#  - two vertical half-round crush ribs per side on the base wall, 0.30 mm proud (gap is 0.25) -> no side play.
import sys
sys.path.insert(0, r"C:\Users\Public\mbx_work")
from ap1_tool import cyl, fuse
from OCP.BRepBuilderAPI import BRepBuilderAPI_MakePolygon, BRepBuilderAPI_MakeFace
from OCP.BRepPrimAPI import BRepPrimAPI_MakePrism
from OCP.gp import gp_Pnt, gp_Vec

RAIL_X = (33.03, 34.03)           # 1.0 mm pad inside the 1.2 mm rail (32.931-34.131)
PAD_Y = (62.7, 64.2)              # solid root zone of base (top 4.302 / 3.222) and cover (12.442 / 13.422)
CHAMF = 0.3
LOWER_BOT, UPPER_TOP = 4.722, 11.922
INTERF = 0.05
WALL_X = 34.381
RIB_YS = (56.0, 63.6)
RIB_R, RIB_PROUD = 0.6, 0.30
RIB_Z = (4.9, 7.7)


def _pad(x0, x1, y0, y1, z_att, z_con):
    up = z_con > z_att
    c = min(CHAMF, abs(z_con - z_att))
    if up:
        pts = [(y0, z_att), (y1 + c, z_att), (y1 + c, z_con - c), (y1, z_con), (y0, z_con)]
    else:
        pts = [(y0, z_att), (y1 + c, z_att), (y1 + c, z_con + c), (y1, z_con), (y0, z_con)]
    poly = BRepBuilderAPI_MakePolygon()
    for y, z in pts:
        poly.Add(gp_Pnt(x0, y, z))
    poly.Close()
    return BRepPrimAPI_MakePrism(BRepBuilderAPI_MakeFace(poly.Wire()).Face(), gp_Vec(x1 - x0, 0, 0)).Shape()


def base_clamp(B, floor_z):
    adds = []
    for s in (-1, 1):
        x0, x1 = sorted((s * RAIL_X[0], s * RAIL_X[1]))
        adds.append(_pad(x0, x1, PAD_Y[0], PAD_Y[1], floor_z - 0.05, LOWER_BOT + INTERF))
        for y in RIB_YS:
            adds.append(cyl(s * (WALL_X + RIB_R - RIB_PROUD), y, RIB_R, RIB_Z[0], RIB_Z[1]))
    return fuse(B, *adds)


def cover_clamp(C, ceil_z):
    adds = []
    for s in (-1, 1):
        x0, x1 = sorted((s * RAIL_X[0], s * RAIL_X[1]))
        adds.append(_pad(x0, x1, PAD_Y[0], PAD_Y[1], ceil_z + 0.05, UPPER_TOP - INTERF))
    return fuse(C, *adds)


# MW4 combs have a 4.5 mm body (z 3.422-13.222, seated y 47.9-58.5) that already rests on the base floor (gap 0.2) and
# tapers to the thin root at y 59.75. Pads at the AP1 position would be crossed by that body during insertion, so MW4 uses
# cover pads over the body's rails instead: they push the body 0.25 mm down onto the floor (0.2 gap + 0.05 preload) and
# are only touched in the last ~5 mm of the stroke. No base pads for MW4.
MW4_PAD_Y = (54.5, 57.0)
MW4_BODY_TOP, MW4_PRESS = 13.222, 0.25


def cover_clamp_mw4(C, ceil_z=14.95):
    adds = []
    for s in (-1, 1):
        x0, x1 = sorted((s * RAIL_X[0], s * RAIL_X[1]))
        adds.append(_pad(x0, x1, MW4_PAD_Y[0], MW4_PAD_Y[1], ceil_z + 0.05, MW4_BODY_TOP - MW4_PRESS))
    return fuse(C, *adds)


def base_ribs_only(B):
    return fuse(B, *[cyl(s * (WALL_X + RIB_R - RIB_PROUD), y, RIB_R, RIB_Z[0], RIB_Z[1]) for s in (-1, 1) for y in RIB_YS])


def cover_clamp_mesh(m3, C, ceil_z, mw4=False):
    """Same pads for the decorative cover meshes (assembly frame)."""
    import numpy as np
    from ap1_tool import to_mesh
    for s in (-1, 1):
        x0, x1 = sorted((s * RAIL_X[0], s * RAIL_X[1]))
        pad = _pad(x0, x1, MW4_PAD_Y[0], MW4_PAD_Y[1], 14.95 + 0.05, MW4_BODY_TOP - MW4_PRESS) if mw4 else \
            _pad(x0, x1, PAD_Y[0], PAD_Y[1], ceil_z + 0.05, UPPER_TOP - INTERF)
        V, F = to_mesh(pad, 0.005, 0.1)
        from mf_tool import weld
        V, F = weld(V, F, 1e-5)
        C = C + m3.Manifold(m3.Mesh(vert_properties=V.astype(np.float32), tri_verts=F.astype(np.uint32)))
    return C
