#include <fstream>
#include <vector>
#include <cmath>
#include <algorithm>
#include <cstdint>
struct P{float x,y,z;};
int main(int ac,char**av){if(ac<3)return 1;std::ifstream f(av[1],std::ios::binary);int w,h,n;f.read((char*)&w,4);f.read((char*)&h,4);f.read((char*)&n,4);std::vector<float> depth(w*h,-1e30f);std::vector<unsigned char> rgb(w*h*3,245);for(int i=0;i<n;i++){P a,b,c;float col[3];f.read((char*)&a,12);f.read((char*)&b,12);f.read((char*)&c,12);f.read((char*)col,12);float den=(b.y-c.y)*(a.x-c.x)+(c.x-b.x)*(a.y-c.y);if(std::abs(den)<1e-7)continue;int x0=std::max(0,(int)std::floor(std::min({a.x,b.x,c.x}))),x1=std::min(w-1,(int)std::ceil(std::max({a.x,b.x,c.x})));int y0=std::max(0,(int)std::floor(std::min({a.y,b.y,c.y}))),y1=std::min(h-1,(int)std::ceil(std::max({a.y,b.y,c.y})));for(int y=y0;y<=y1;y++)for(int x=x0;x<=x1;x++){float u=((b.y-c.y)*(x+.5-c.x)+(c.x-b.x)*(y+.5-c.y))/den,v=((c.y-a.y)*(x+.5-c.x)+(a.x-c.x)*(y+.5-c.y))/den,t=1-u-v;if(u<0||v<0||t<0)continue;float z=u*a.z+v*b.z+t*c.z;int at=y*w+x;if(z>depth[at]){depth[at]=z;for(int k=0;k<3;k++)rgb[at*3+k]=(unsigned char)std::clamp(col[k],0.f,255.f);}}}std::ofstream o(av[2],std::ios::binary);o<<"P6\n"<<w<<" "<<h<<"\n255\n";o.write((char*)rgb.data(),rgb.size());}
