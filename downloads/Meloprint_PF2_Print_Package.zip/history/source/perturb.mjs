import fs from 'fs';
import factory from 'manifold-3d';
const K=await factory();K.setup();
const D=JSON.parse(fs.readFileSync('engineeringpf2/output/design.json'));
const cx=D.cx,cy=D.cy,hy=D.hy,E=D.stroke/2,M={},names={};
for(const n of Object.keys(D.parts)){
 let b=fs.readFileSync('engineeringpf2/output/parts/'+n+'.stl'),nt=b.readUInt32LE(80),v=new Float32Array(nt*9),t=new Uint32Array(nt*3);
 for(let i=0;i<nt;i++)for(let j=0;j<9;j++)v[i*9+j]=b.readFloatLE(84+i*50+12+j*4);
 for(let j=0;j<t.length;j++)t[j]=j;
 let mesh=new K.Mesh({numProp:3,vertProperties:v,triVerts:t});mesh.merge();let m=new K.Manifold(mesh);M[n.slice(0,2)]=m;names[n.slice(0,2)]=n;
 console.log(n,m.status(),m.volume(),m.decompose().map(c=>c.volume()));
}

let checks=0,hits=[];
for(let theta=0;theta<360;theta+=15){
 const rad=theta*Math.PI/180,x=-E*Math.sin(rad),dy=E*(Math.cos(rad)-1);
 const main=M['03'].translate([-cx,-cy,0]).rotate([0,0,theta]).translate([cx,cy,0]);
 const handle=M['04'].translate([-cx,-hy,0]).rotate([0,0,-1.5*theta]).translate([cx,hy,0]);
 for(const yaw of [-.5,0,.5])for(const yy of [-.1,0,.1]){
  const q=M['05'].translate([-cx,-cy,0]).rotate([0,0,yaw]).translate([cx+x,cy+yy,0]);
  for(const [k,b] of [['01',M['01']],['02',M['02']],['03',main],['04',handle]]){
   const r=q.intersect(b),v=r.volume();r.delete();checks++;if(v>.002)hits.push({theta,yaw,y_shift:yy,pair:'05-'+k,volume:v});
  }
  q.delete();
 }
 main.delete();handle.delete();
}
fs.writeFileSync('engineeringpf2/output/perturbation_checks.json',JSON.stringify({description:'Geometric tolerance sweep only; not a friction or self-centering test. Roller slot reactions and intentional comb plucking excluded.',yaw_degrees:[-.5,0,.5],y_shift_mm:[-.1,0,.1],checks,hits},null,2));console.log('PERTURB',checks,hits.length,JSON.stringify(hits.slice(0,6)));
