import fs from 'fs';
import factory from 'manifold-3d';
const K=await factory();K.setup();
const D=JSON.parse(fs.readFileSync('engineeringpf2/output/design.json'));
const cx=D.cx,cy=D.cy,hy=D.hy,E=D.stroke/2,M={},names={};
for(const n of Object.keys(D.parts)){
 let b=fs.readFileSync('engineeringpf2/output/parts/'+n+'.stl'),nt=b.readUInt32LE(80),v=new Float32Array(nt*9),t=new Uint32Array(nt*3);
 for(let i=0;i<nt;i++)for(let j=0;j<9;j++)v[i*9+j]=b.readFloatLE(84+i*50+12+j*4);
 for(let j=0;j<t.length;j++)t[j]=j;
 let mesh=new K.Mesh({numProp:3,vertProperties:v,triVerts:t});mesh.merge();let m=new K.Manifold(mesh);M[n.slice(0,2)]=m;names[n.slice(0,2)]=n;
 console.log(n,m.status(),m.volume(),m.decompose().map(c=>c.volume()));
}
let hits=[],max={},checks=0;const fixed=['01','02','10','11','19','20','21','22'];
const mov=['03','04','05','06','12'];
const pairs=['03-04','03-05','04-05','05-06','05-12','03-06','03-12','04-06','04-12','06-12'];
function check(a,b,aa,bb,theta){let q=aa.intersect(bb),v=q.volume();q.delete();checks++;if(v>.002){let key=a+'-'+b;hits.push({theta,pair:key,volume:v});max[key]=Math.max(max[key]||0,v);}}
const step=Number(process.env.STEP||10);
for(let theta=0;theta<360;theta+=step){
 let rad=theta*Math.PI/180,x=-E*Math.sin(rad),dy=E*(Math.cos(rad)-1),P={...M};
 P['03']=M['03'].translate([-cx,-cy,0]).rotate([0,0,theta]).translate([cx,cy,0]);
 P['04']=M['04'].translate([-cx,-hy,0]).rotate([0,0,-1.5*theta]).translate([cx,hy,0]);
 for(const k of ['05'])P[k]=M[k].translate([x,0,0]);
 for(const k of ['06','12'])P[k]=M[k].translate([x,dy,0]);
 for(const k of [])P[k]=M[k].translate([-cx,0,-14.5]).rotate([0,-x/4*180/Math.PI,0]).translate([cx+x,0,14.5]);
 for(const a of mov)for(const b of fixed)check(a,b,P[a],P[b],theta);
 for(const pair of pairs){let[a,b]=pair.split('-');check(a,b,P[a],P[b],theta);}
 let body=P['05'].subtract(K.Manifold.cube([25,20,25]).translate([cx+x-12.5,25,0]));for(const b of ['15','16'])check('05-body',b,body,P[b],theta);body.delete();
 for(const k of mov)P[k].delete();
 if(theta%30===0)console.log('ANGLE',theta,'hits',hits.length);
}
for(let i=0;i<fixed.length;i++)for(let j=i+1;j<fixed.length;j++)check(fixed[i],fixed[j],M[fixed[i]],M[fixed[j]],'static');
fs.writeFileSync('engineeringpf2/output/collision.json',JSON.stringify({step_degrees:step,checks,threshold_mm3:.002,maximum:max,hits},null,2));console.log('RESULT',checks,JSON.stringify(max));
