import pathlib,json,zipfile,hashlib
P=pathlib.Path('engineeringpf2/output');D=json.loads((P/'design.json').read_text());assert D['part_count']==15
for n in ['collision','perturbation_checks','exact_checks']:
 r=json.loads((P/(n+'.json')).read_text());assert not r['hits'],n
R=json.loads((P/'3dm_checks.json').read_text());assert R['parts']==15
report='''# PF2 CAD 검증 결과\n\n- 조립 부품 15개. 3DM은 유효한 닫힌 BREP 15개이며 메쉬 객체는 없습니다.\n- 조립 STL과 출력 STL은 각각 단일 연결체, 닫힌 메쉬와 일관된 면 방향을 검사했습니다.\n- 회전 5도 간격의 지정 부품 간 간섭 검사를 수행했습니다.\n- 화살표의 ±0.5도 평면 회전과 ±0.1mm 전후 편차를 조합한 검사도 수행했습니다. 이 검사는 실제 자기 정렬이나 마찰 토크 시험이 아닙니다.\n- 별도로 15도 간격에서 정확한 BREP로 화살표와 베이스·상판·주기어·손잡이를 검사했습니다.\n- 의도된 빗 타음 간섭은 제거하지 않았습니다.\n- 임의의 큰 비틀림, 출력 오차 전체, 마찰, 탄성 변형, 소리, 수명은 검증하지 않았습니다.\n\n'''
for n in ['collision','perturbation_checks','exact_checks']:
 r=json.loads((P/(n+'.json')).read_text());report+=f"- {n}: {r['checks']}개 조합, 기준 초과 간섭 {len(r['hits'])}건.\n"
report+=f"- 3DM 면 수: {R['faces']}개. Rhino 데스크톱 직접 확인은 수행하지 않았습니다.\n"
(P/'VERIFICATION_KO.md').write_text(report)
files={}
for name in ['Meloprint_PF2_Assembly.3dm','Meloprint_PF2_Assembly.step','Meloprint_PF2_Preview.png','README_KO.md','SOURCE_KO.md','VERIFICATION_KO.md','design.json','mesh_checks.json','3dm_checks.json','collision.json','perturbation_checks.json','exact_checks.json','final_checks.json']:
 files[name]=P/name
for folder in ['print_stl','coupons']:
 for f in sorted((P/folder).glob('*')):files[folder+'/'+f.name]=f
for name in ['build.py','package_parts.py','export-brep.py','finish_3dm.py','check.mjs','perturb.mjs','exact_check.py','verify_final.py','coupons.py','preview.py','render.cpp','write_docs.py','package_final.py']:
 files['source/'+name]=P.parent/name
for f in (P.parent/'input').glob('*.brep'):files['source/input/'+f.name]=f
for f in pathlib.Path('recovered19/package/source/cad_helpers').glob('*.cpp'):files['source/cad_helpers/'+f.name]=f
manifest={k:hashlib.sha256(v.read_bytes()).hexdigest() for k,v in files.items()}
zp=P/'Meloprint_PF2_Print_Package.zip'
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
 for k,v in files.items():z.write(v,k)
 z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(zp) as z:
 assert z.testzip() is None
 assert len([n for n in z.namelist() if n.startswith('print_stl/')])==15
print('PACKAGED',zp.stat().st_size,len(files))
