import cadquery as c,json,pathlib,trimesh,numpy as np,hashlib
P=pathlib.Path('engineeringpf2/output');B=pathlib.Path('engineeringpf/output');D=json.loads((P/'design.json').read_text())
check={'revision':'PF2','part_count':len(D['parts']),'physical_test':False,'slicer_test':False,'website_modified':False,'unchanged_parts':[]}
for n in D['parts']:
 if n[:2] not in ['01','02','05']:
  a=(P/'parts'/(n+'.brep')).read_bytes();b=(B/'parts'/(n+'.brep')).read_bytes()
  if hashlib.sha256(a).digest()!=hashlib.sha256(b).digest():
   aa=c.Shape.importBrep(str(P/'parts'/(n+'.brep')));bb=c.Shape.importBrep(str(B/'parts'/(n+'.brep')))
   assert abs(aa.Volume()-bb.Volume())<.002 and len(aa.Faces())==len(bb.Faces()),n
  check['unchanged_parts'].append(n)
a=c.Shape.importBrep(str(P/'parts/05_Yoke_AP1.brep'));b=c.Shape.importBrep(str(B/'parts/05_Yoke_AP1.brep'))
mask=c.Solid.makeBox(20,4,6.7,c.Vector(-10,27.01,5.34));aa=a.intersect(mask);bb=b.intersect(mask);v=aa.cut(bb).Volume()+bb.cut(aa).Volume();assert v<.002;check['contact_nose_difference_mm3']=v
meshes=[trimesh.load(P/'parts'/(n+'.stl')) for n in D['parts']];bounds=np.array([m.bounds for m in meshes]);check['assembly_mesh_bounds_mm']=[bounds[:,0,:].min(0).tolist(),bounds[:,1,:].max(0).tolist()]
y=trimesh.load(P/'print_stl/05_Yoke_AP1.stl');check['yoke_vertices_at_bed']=int((abs(y.vertices[:,2])<.015).sum());assert check['yoke_vertices_at_bed']>=4
u=trimesh.load(P/'parts/05_Yoke_AP1.stl');body=u.vertices[u.vertices[:,1]<0];check['yoke_body_bed_clearance_mm']=float(u.bounds[1,0]-body[:,0].max());assert check['yoke_body_bed_clearance_mm']<.015
check['stl_sha256']={n:hashlib.sha256((P/'parts'/(n+'.stl')).read_bytes()).hexdigest() for n in D['parts']}
(P/'final_checks.json').write_text(json.dumps(check,indent=2));print('FINAL',len(check['unchanged_parts']),'reused; nose difference',v,'bed vertices',check['yoke_vertices_at_bed'])
