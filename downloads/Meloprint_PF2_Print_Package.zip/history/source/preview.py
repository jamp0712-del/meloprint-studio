import numpy as np,trimesh,pathlib,json,struct,subprocess
from PIL import Image,ImageDraw,ImageFont
P=pathlib.Path('engineeringpf2/output');D=json.loads((P/'design.json').read_text())
colors={'01':(58,65,73),'02':(68,79,90),'03':(48,147,148),'04':(62,69,80),'05':(239,163,57),'06':(237,203,140),'07':(231,184,78),'08':(231,184,78),'09':(224,121,56),'15':(225,224,217),'16':(225,224,217)}
meshes={n:trimesh.load(P/'parts'/(n+'.stl')) for n in D['parts']}
def render(path,hide,vec):
 z=np.array(vec,dtype=float);z/=np.linalg.norm(z);x=np.cross([0,1,0],z);x/=np.linalg.norm(x);y=np.cross(z,x);basis=np.stack([x,-y,z],axis=1)
 verts=np.concatenate([m.vertices@basis for n,m in meshes.items() if n[:2] not in hide]);lo=verts.min(0);hi=verts.max(0);w,h=850,1100;scale=min((w-100)/(hi[0]-lo[0]),(h-100)/(hi[1]-lo[1]));mid=(lo+hi)/2
 light=np.array([-1,-.8,2]);light/=np.linalg.norm(light);chunks=[]
 for n,m in meshes.items():
  if n[:2] in hide:continue
  v=m.triangles@basis;v[:,:,:2]=(v[:,:,:2]-mid[:2])*scale+[w/2,h/2]
  lum=.40+.60*np.maximum(m.face_normals@light,0);rgb=np.array(colors.get(n[:2],(171,177,186)))*lum[:,None]
  chunks.append(np.concatenate([v.reshape(-1,9),rgb],axis=1).astype('<f4'))
 a=np.concatenate(chunks);raw=path.with_suffix('.raw');raw.write_bytes(struct.pack('<iii',w,h,len(a))+a.tobytes());subprocess.run(['engineeringpf/render',str(raw),str(path.with_suffix('.ppm'))],check=True);im=Image.open(path.with_suffix('.ppm'));im.save(path);raw.unlink();path.with_suffix('.ppm').unlink()
render(P/'assembled.png',[],[.35,-.55,2.8]);render(P/'internal.png',['02','04','11','19','20','21','22','15','16'],[.25,-.30,3.5])
canvas=Image.new('RGB',(1760,1280),'#f5f5f5');draw=ImageDraw.Draw(canvas);font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';f=ImageFont.truetype(font,33);small=ImageFont.truetype(font,22)
canvas.paste(Image.open(P/'assembled.png'),(15,90));canvas.paste(Image.open(P/'internal.png'),(895,90))
draw.text((40,24),'MELOPRINT / PF2 — ALL-PRINTED PROTOTYPE',font=f,fill='#17232c');draw.text((40,1200),'ASSEMBLED • same external size',font=small,fill='#17232c');draw.text((930,1200),'INTERNAL • cover + knob hidden',font=small,fill='#17232c');draw.text((40,1240),'Geometry preview. Physical print / friction / sound tests are not yet performed.',font=small,fill='#56616b');canvas.save(P/'Meloprint_PF2_Preview.png')
