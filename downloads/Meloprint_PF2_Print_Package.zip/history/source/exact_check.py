import cadquery as c,json,math,pathlib
P=pathlib.Path('engineeringpf2/output');D=json.loads((P/'design.json').read_text());cx,cy,hy,E=D['cx'],D['cy'],D['hy'],D['stroke']/2
S={n[:2]:c.Shape.importBrep(str(P/'parts'/(n+'.brep'))) for n in D['parts']};hits=[];checks=0
for theta in range(0,360,15):
 x=-E*math.sin(math.radians(theta)); q=S['05'].translate((x,0,0))
 for k,b in [('01',S['01']),('02',S['02']),('03',S['03'].rotate((cx,cy,0),(cx,cy,1),theta)),('04',S['04'].rotate((cx,hy,0),(cx,hy,1),-1.5*theta))]:
  v=q.intersect(b).Volume();checks+=1
  if v>.002:hits.append({'theta':theta,'pair':'05-'+k,'volume_mm3':v})
 print(theta,len(hits),flush=True)
(P/'exact_checks.json').write_text(json.dumps({'method':'OpenCascade exact BREP intersections','step_degrees':15,'checks':checks,'threshold_mm3':.002,'hits':hits},indent=2));print('EXACT',checks,len(hits))
