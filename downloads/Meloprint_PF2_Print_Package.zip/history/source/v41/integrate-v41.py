import pathlib,json,hashlib,zipfile,shutil,cadquery as cq,rhino3dm as r
R=pathlib.Path(__file__).resolve().parents[1];D=R/'model-source/pf2/v41';changed=json.loads((D/'design.json').read_text())['parts'];P=D/'print_stl';P.mkdir(exist_ok=True)
for n in [*changed,'01_Base_MW4']:
 shutil.copyfile(D/(n+'.stl'),R/'dist/assets/pf2'/(n+'.stl'));s=cq.Shape.importBrep(str(D/(n+'.brep')))
 if n=='11_HandleRetainer_AP1':s=s.rotate((0,0,0),(1,0,0),180)
 b=s.BoundingBox();s=s.translate((-(b.xmin+b.xmax)/2,-(b.ymin+b.ymax)/2,-b.zmin));cq.exporters.export(s,str(P/(n+'.stl')),tolerance=.005,angularTolerance=.05)
 if n=='01_Base_MW4':shutil.copyfile(P/(n+'.stl'),R/'dist/models/01_Base_MW4_PRINT.stl')
old=r.File3dm.Read(str(R/'dist/cad/Meloprint_PF2_Assembly.3dm'));new=r.File3dm.Read(str(D/'replacement-surfaces.3dm'));replacements={o.Attributes.Name:o.Geometry for o in new.Objects}
for o in list(old.Objects):
 if o.Attributes.Name in replacements:
  a=r.ObjectAttributes();a.Name=o.Attributes.Name;a.LayerIndex=o.Attributes.LayerIndex;a.WireDensity=-1;a.ObjectColor=o.Attributes.ObjectColor;a.ColorSource=o.Attributes.ColorSource;n=a.Name;old.Objects.Delete(o.Attributes.Id);a.SetUserString('Revision','PF2-v41 assembly-path repair');old.Objects.AddBrep(replacements[n],a)
assert len(old.Objects)==15 and all(isinstance(o.Geometry,r.Brep) and o.Geometry.IsValid and o.Geometry.IsSolid for o in old.Objects)
old.Strings['Assembly']='PF2 v41: lower gear first, cover next, upper wheel last. Test printed integral latches before full print.'
assert old.Write(str(R/'dist/cad/Meloprint_PF2_Assembly.3dm'),7)
data=(R/'dist/cad/Meloprint_PF2_Assembly.3dm').read_bytes();m=json.loads((R/'dist/cad/pf2-surface.json').read_text());m['bytes']=len(data);m['sha256']=hashlib.sha256(data).hexdigest();m['faces']=sum(len(o.Geometry.Faces) for o in old.Objects);m['assemblyRevision']='PF2-v41';(R/'dist/cad/pf2-surface.json').write_text(json.dumps(m,indent=2));shutil.copyfile(R/'dist/cad/Meloprint_PF2_Assembly.3dm',D/'Meloprint_PF2_v41_Assembly.3dm')
meta=json.loads((R/'model-source/pf2/design.json').read_text());shapes=cq.importers.importStep(str(D/'original-assembly.step')).solids().vals();assembly=cq.Assembly(name='Meloprint_PF2_v41')
for (n,v),s in zip(meta['parts'].items(),shapes):
 assert abs(s.Volume()-v['volume_mm3'])<.02,n
 if n in changed:s=cq.Shape.importBrep(str(D/(n+'.brep')))
 assembly.add(s,name=n)
assembly.save(str(D/'Meloprint_PF2_v41_Assembly.step'))
print('Updated',len(changed),'parts; 15 native valid solid Breps; faces',m['faces'])
