import cadquery as cq,pathlib,json
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import PolyCollection
R=pathlib.Path(__file__).resolve().parents[1];D=R/'model-source/pf2/v41';C=D/'coupons';C.mkdir(exist_ok=True);V=cq.Vector;cx=.0012908316532776;hy=-80.54360267801859
read=lambda n:cq.Shape.importBrep(str(D/(n+'.brep')))
b=read('01_Base_AP1');g=read('04_Handle_AP1');w=read('11_HandleRetainer_AP1')
region=cq.Solid.makeCylinder(8,40,V(cx,hy,-5))
coupons={'C41_BasePost':b.intersect(region),'C42_DriveSocket':g.intersect(region),'C43_WheelLatch':w.intersect(cq.Solid.makeBox(24,46,12,V(cx-12,hy-23,20)))}
for n,s in coupons.items():
 assert s.isValid() and len(s.Solids())==1,n
 cq.exporters.export(s,str(C/(n+'.step')))
 if n=='C43_WheelLatch':s=s.rotate((0,0,0),(1,0,0),180)
 bb=s.BoundingBox();s=s.translate((-(bb.xmin+bb.xmax)/2,-(bb.ymin+bb.ymax)/2,-bb.zmin));cq.exporters.export(s,str(C/(n+'.stl')),tolerance=.005,angularTolerance=.05)
# True CAD cross-section at the handle axis (not an imagined render).
orig=cq.importers.importStep(str(D/'original-assembly.step')).solids().vals();cover=orig[1]
fig,axes=plt.subplots(1,2,figsize=(13,5),facecolor='#f4f6fa')
for ax,explode in zip(axes,[False,True]):
 for s,color,label,offset in [(b,'#687b91','Base / fixed journal',0),(g,'#ea9b42','04 lower gear + shaft',0),(cover,'#57b9a5','02 unchanged cover',0),(w,'#508bd2','11 top wheel + latch',18 if explode else 0)]:
  cut=s.intersect(cq.Solid.makeBox(100,.04,45,V(-50,hy-.02,-5)))
  vv,ff=cut.tessellate(.03,.1);pts=[[p.x,p.z+offset] for p in vv];ax.add_collection(PolyCollection([[pts[i] for i in f] for f in ff],facecolors=color,edgecolors='none',label=label))
 ax.set(xlim=(-48,48),ylim=(-6,52),aspect='equal',xlabel='X (mm)',ylabel='Z (mm)');ax.grid(alpha=.14);ax.set_title('Final assembled cross-section' if not explode else 'Top wheel is fitted AFTER the cover',fontsize=12)
 if explode:ax.annotate('',xy=(0,31),xytext=(0,38),arrowprops={'arrowstyle':'->','lw':2,'color':'#315c87'})
axes[0].legend(loc='upper left',fontsize=8);fig.suptitle('PF2 v41 | 15 parts | assembly-path repair',fontsize=17);fig.tight_layout();fig.savefig(D/'Assembly_Section_v41.png',dpi=180)
