"""PF2 v41 assembly repair, 15 printed parts. No physical validation."""
import cadquery as cq,math,json,pathlib,zipfile
R=pathlib.Path(__file__).resolve().parents[1];D=R/'model-source/pf2/v41';D.mkdir(exist_ok=True)
V=cq.Vector;cx=.0012908316532776;cy=-23.218354284050648;hy=-80.54360267801859;py=cy+36.064
box=lambda a,b,c,d,e,f:cq.Solid.makeBox(b-a,d-c,f-e,V(cx+a,hy+c,e))
cyl=lambda r,a,b:cq.Solid.makeCylinder(r,b-a,V(cx,hy,a))
pc=lambda r,a,b:cq.Solid.makeCylinder(r,b-a,V(cx,py,a))
def hexagon(af,z,h):
 r=af/math.sqrt(3);w=cq.Wire.makePolygon([V(cx+r*math.cos(math.pi/6+i*math.pi/3),hy+r*math.sin(math.pi/6+i*math.pi/3),z) for i in range(6)],close=True)
 return cq.Solid.extrudeLinear(w,[],V(0,0,h))
src=D/'original-assembly.step'
if not src.exists():
 with zipfile.ZipFile(R/'dist/downloads/Meloprint_PF2_Print_Package.zip') as z:src.write_bytes(z.read('Meloprint_PF2_Assembly.step'))
meta=json.loads((R/'model-source/pf2/design.json').read_text());solids=cq.importers.importStep(str(src)).solids().vals();original=dict(zip(meta['parts'],solids))
for n,s in original.items():assert abs(s.Volume()-meta['parts'][n]['volume_mm3'])<.02,n
old=original['04_Handle_AP1']
gear=old.intersect(box(-50,50,-50,50,-3,21.4)).fuse(hexagon(12,21.39,3.81).cut(cyl(4.6,21.3,25.4))).clean()
wheel=old.intersect(box(-50,50,-50,50,21.4,31)).cut(hexagon(12.5,21.3,4.1))
for side in [-1,1]:
 a,b=(2.3,6.5) if side==1 else (-6.5,-2.3);wheel=wheel.cut(box(a,b,-19,3,21.3,31))
 a,b=(3.1,4.3) if side==1 else (-4.3,-3.1);beam=box(a,b,-20,-1.5,25.9,27.1)
 a,b=(2.7,4.8) if side==1 else (-4.8,-2.7);hook=box(a,b,-1.5,1.5,25.9,27.1)
 funnel=cq.Solid.makeCone(4.2,2.7,.95,V(cx,hy,25.9))
 wheel=wheel.fuse(beam.cut(funnel)).fuse(hook.cut(funnel).cut(cyl(2.7,25.8,27.2)))
wheel=wheel.clean()
base=original['01_Base_AP1'].cut(box(-44.51,44.51,-71-hy,-67.7-hy,1.599,9.851)).clean()
main=original['03_MainGear_AP1'].cut(cq.Solid.makeCylinder(3,8,V(cx,py,5.5))).fuse(pc(2.9,5.49,6.2)).fuse(pc(2,6.19,10.1)).fuse(pc(1.35,10.09,11.5)).fuse(pc(2,11.5,11.9)).clean()
roller=pc(5,6.3,7.2).fuse(pc(3.5,7.19,10)).cut(pc(2.2,6.2,10.1)).clean()
parts={'01_Base_AP1':base,'03_MainGear_AP1':main,'04_Handle_AP1':gear,'06_CrankRoller_AP1':roller,'11_HandleRetainer_AP1':wheel}
# Front-right lock lug clipped the retained comb seat during quarter-turn.
lock0=original['22_CaseLock_AP1'];region=cq.Solid.makeBox(10,10,1.5,V(35,53.8,10.5));allowed=cq.Solid.makeCylinder(3,1.7,V(40,58.8,10.4));parts['22_CaseLock_AP1']=lock0.cut(region.cut(allowed)).clean()
report={'revision':'PF2-v41','partCount':15,'bodyEnvelopeUnchanged':True,'coverUnchanged':True,'shaftHexAcrossFlatsMm':12,'socketHexAcrossFlatsMm':12.5,'hexEngagementMm':3.8,'retainingFlexure':{'lengthMm':17,'radialThicknessMm':1.2,'heightMm':1.2,'requiredDeflectionMm':1.3,'nominalNeckClearanceMm':.2,'headAxialClearanceMm':.3,'beamStrainEstimate':1.5*1.2*1.3/17**2,'physicalTest':False},'parts':{}}
for n,s in parts.items():
 assert s.isValid() and len(s.Solids())==1,n
 for ext in ['step','brep','stl']:cq.exporters.export(s,str(D/(n+'.'+ext)),**({'tolerance':.005,'angularTolerance':.05} if ext=='stl' else {}))
 b=s.BoundingBox();report['parts'][n]={'faces':len(s.Faces()),'volume_mm3':s.Volume(),'bounds':[b.xmin,b.xmax,b.ymin,b.ymax,b.zmin,b.zmax]}
mw=base.cut(cq.Solid.makeBox(68.8,33.6,10.4,V(-34.36919491968,26.184,3.1215951232))).clean()
for ext in ['step','brep','stl']:cq.exporters.export(mw,str(D/('01_Base_MW4.'+ext)),**({'tolerance':.005,'angularTolerance':.05} if ext=='stl' else {}))
# Exact solid quarter-turn clearance checks for all four existing case locks.
report['exactCaseLocks']={}
for i,(x,y) in enumerate([(-40,-119),(40,-119),(-40,58.8),(40,58.8)]):
 lock=parts.get(str(19+i)+'_CaseLock_AP1',original[str(19+i)+'_CaseLock_AP1']);vals=[]
 for a in range(0,91,5):
  t=lock.rotate((x,y,0),(x,y,1),a);v=t.intersect(base).Volume()+t.intersect(original['02_Cover_AP1']).Volume();vals.append(v)
 report['exactCaseLocks'][str(19+i)]=max(vals)
print(json.dumps(report,indent=2));(D/'design.json').write_text(json.dumps(report,indent=2))
