"""PF2: entirely printed, central plain guide and visible integral arrow. Experimental prototype, mm."""
import cadquery as cq,math,json,pathlib
P=pathlib.Path(__file__).resolve().parent;O=P/'output';Q=O/'parts';Q.mkdir(parents=True,exist_ok=True)
V=cq.Vector;cx=.0012908316532776;cy=-23.218354284050648;hy=-80.54360267801859;E=36.064;fz=14.5;front=23.;rear=-66.;py=cy+E
xmin=-45.37685143;xmax=45.43846134;ymin=-125.92174494;ymax=64.80430265
box=lambda x0,x1,y0,y1,z0,z1:cq.Solid.makeBox(x1-x0,y1-y0,z1-z0,V(x0,y0,z0))
def cyl(r,z0,z1,x=cx,y=cy):return cq.Solid.makeCylinder(r,z1-z0,V(x,y,z0))
def ycyl(r,y0,y1,x=cx,z=fz):return cq.Solid.makeCylinder(r,y1-y0,V(x,y0,z),V(0,1,0))
def polyxy(pts,z,h):return cq.Solid.extrudeLinear(cq.Wire.makePolygon([V(x,y,z) for x,y in pts],close=True),[],V(0,0,h))
def polyxz(pts,y,h):return cq.Solid.extrudeLinear(cq.Wire.makePolygon([V(x,y,z) for x,z in pts],close=True),[],V(0,h,0))
def hx(af,y0,y1):
 r=af/math.sqrt(3);return polyxz([(cx+r*math.cos(i*math.pi/3),fz+r*math.sin(i*math.pi/3)) for i in range(6)],y0,y1-y0)
def gear(n,m,pa,z,h,y,phase,thin=.10,add=1,ded=1.25):
 p=math.radians(pa);r=m*n/2;rb=r*math.cos(p);rr=r-ded*m;rt=r+add*m;half=math.pi/(2*n)-thin/(2*r);ip=math.tan(p)-p
 a=lambda q:half+ip-(math.tan(math.acos(min(1,rb/q)))-math.acos(min(1,rb/q)))
 pol=lambda q,t:V(cx+q*math.cos(t),y+q*math.sin(t),z);edges=[];low=max(rr,rb)
 for i in range(n):
  c=phase+2*math.pi*i/n;pts=[pol(low+(rt-low)*k/16,c-a(low+(rt-low)*k/16)) for k in range(17)]
  if rr<rb:edges.append(cq.Edge.makeLine(pol(rr,c-a(low)),pts[0]))
  edges.append(cq.Edge.makeSpline(pts,tol=1e-7));aa=a(rt);edges.append(cq.Edge.makeThreePointArc(pts[-1],pol(rt,c),pol(rt,c+aa)))
  pts=[pol(rt-(rt-low)*k/16,c+a(rt-(rt-low)*k/16)) for k in range(17)];edges.append(cq.Edge.makeSpline(pts,tol=1e-7))
  if rr<rb:edges.append(cq.Edge.makeLine(pts[-1],pol(rr,c+a(low))))
  end=c+2*math.pi/n-a(low);edges.append(cq.Edge.makeThreePointArc(pol(rr,c+a(low)),pol(rr,(c+a(low)+end)/2),pol(rr,end)))
 return cq.Solid.extrudeLinear(cq.Wire.assembleEdges(edges),[],V(0,0,h))
def rounded(z,h):
 s=box(xmin,xmax,ymin,ymax,z,z+h);es=[e for e in s.Edges() if e.BoundingBox().zlen>h-.001];return s.fillet(4,es)
orig={n:cq.Shape.importBrep(str(P/'input'/f'{n:02}.brep')) for n in [1,2,4,8,9]};parts={};meta={}
def add(n,s,group,desc):
 assert s.isValid(),n;assert len(s.Solids())==1,(n,len(s.Solids()));assert s.Volume()>0
 cq.exporters.export(s,str(Q/(n+'.brep')));parts[n]=s;meta[n]={'group':group,'description':desc,'faces':len(s.Faces()),'volume_mm3':s.Volume()};print(n,len(s.Faces()),flush=True)
# Rebuilt simple body: same envelope; preserve original comb seat/front interfaces.
base=rounded(-4.8,19.52159587).cut(box(-43.3,43.3,ymin+2.1,29.9,-3.3,15))
base=base.cut(box(-50,50,29.8,100,-5,16)).fuse(orig[1].intersect(box(-50,50,29.7,100,-5,16)))
cover=rounded(14.95,20.73442238-14.95).cut(box(-43.3,43.3,ymin+2.1,29.9,14.8,17.4))
cover=cover.cut(box(-50,50,29.8,100,-1,22)).fuse(orig[2].intersect(box(-50,50,29.7,100,-1,22)))
cover=cover.cut(cyl(7.5,14,22,y=hy))
# The original comb-view bridge is retained; rear roof is a clean uninterrupted surface.
for yy,top,neck,head in [(cy,5.65,1.15,.35),(hy,26.,1.4,.4)]:
 base=base.fuse(cyl(7,-4.8,-3.2,y=yy)).fuse(cyl(4,-3.3,top,y=yy)).fuse(cyl(2.5,top,top+neck,y=yy)).fuse(cyl(4,top+neck,top+neck+head,y=yy))
 for ang in [0,120,240]:
  a=math.radians(ang);base=base.fuse(cyl(1.5,-3.3,-2.05,cx+6*math.cos(a),yy+6*math.sin(a)))
# One central datum rail, rear flat vertical support only; no synchronization teeth.
for yy,y0,y1 in [(front,17.9,21.3),(rear,-71.,-67.7)]:
 base=base.fuse(box(-44.5,44.5,y0,y1,1.6 if yy==rear else -3.3,9.85))
 if yy==rear:
  for xa,xb in [(-44.5,-26),(26,44.5)]:base=base.fuse(box(xa,xb,y0,y1,-3.3,1.61))

# Roof capture lands, with clearance; no rack teeth.
cover=cover.fuse(box(-43.3,43.3,cy-1.7,cy+1.7,14.65,17.5))
cover=cover.fuse(box(-43.3,43.3,-71.3,-67.4,12.95,17.5))
# Open viewing/assembly window clears the integral arrow head with yoke centered.
cover=cover.cut(box(-39.6,39.6,8.6,27.4,12.7,24))
# Recessed all-printed quarter-turn case locks.
lockpos=[(-40.,-119.),(40.,-119.),(-40.,58.8),(40.,58.8)]
for lx,ly in lockpos:
 base=base.fuse(cyl(4.8,-4.8,14.7215,lx,ly));cover=cover.fuse(cyl(4.8,14.95,20.6,lx,ly))
 tool=cyl(2.4,10.35,21,lx,ly).fuse(box(lx-3.8,lx+3.8,ly-1.05,ly+1.05,11.95,21))
 base=base.cut(tool).cut(cyl(3.85,10.4,12.1,lx,ly));cover=cover.cut(tool).cut(cyl(3.7,19.45,21,lx,ly))
# Clear retained front-cover skirts around new case bosses; preserve 0.20mm assembly gap.
cover=cover.cut(box(-50,50,29.69,29.81,-1,14.8))
for lx,ly in lockpos[2:]:cover=cover.cut(cyl(5.0,-1,14.9,lx,ly))
# Eliminate tiny trapped cavities where the original front corner fillets meet new bosses.
for xa,xb,ya,yb in [(-36.65,-35.8,55.35,56.35),(36.05,36.5,55.55,56.05)]:cover=cover.fuse(box(xa,xb,ya,yb,19.35,19.95))
# Replace legacy M3 corner bosses and holes with flat printable corner structure.
# Preserve only the original comb-seat interfaces above Y=60.5.
seat_window=box(-38.9,38.9,60.5,66,-.2,15.)
seat_void=seat_window.cut(orig[1])
for xa,xb in [(-50,-31.8),(31.8,50)]:
 mask=box(xa,xb,50.8,70,-6,23)
 patch=rounded(-4.8,19.52159587).intersect(mask).cut(box(-35.1,35.1,50.7,60.5,-.2,12.4)).cut(seat_void)
 base=base.cut(mask).fuse(patch)
 patch=rounded(14.95,20.73442238-14.95).intersect(mask)
 seat=orig[2].intersect(mask).intersect(box(-38.9,38.9,60.5,66,-1,15.))
 cover=cover.cut(mask).fuse(patch).fuse(seat)
for lx,ly in lockpos[2:]:
 tool=cyl(2.4,10.35,21,lx,ly).fuse(box(lx-3.8,lx+3.8,ly-1.05,ly+1.05,11.95,21))
 base=base.cut(tool).cut(cyl(3.85,10.4,12.1,lx,ly))
 cover=cover.cut(tool).cut(cyl(3.7,19.45,21,lx,ly))

# Local inner-wall relief for the 14mm wide side-printable yoke and small yaw.
# Outer footprint unchanged; side wall retains at least 1.72mm nominal thickness.
for xa,xb in [(-43.65,-43.25),(43.25,43.65)]:
 relief=box(xa,xb,-72.2,29.69,4.0,17.3)
 base=base.cut(relief);cover=cover.cut(relief)
add('01_Base_AP1',base,'fixed','Same body envelope; printed journals, flat end supports; central datum in cover')
add('02_Cover_AP1',cover,'fixed','Clean rebuilt roof, original front comb interface, central plain guide and arrow viewing window; no racks')
m=1.1465049678793588
main=gear(60,m,20,-1.8,3,cy,-math.pi/2).fuse(cyl(m*30-1.25*m,1.19,1.61)).fuse(cyl(40.5,1.6,5.5))
for ang in [0,120,240]:
 a=math.radians(ang);main=main.cut(cyl(6,-2,5.6,cx+20*math.cos(a),cy+20*math.sin(a)))
main=main.cut(cyl(4.225,-2,6)).cut(cyl(4.6,1,3)).fuse(cyl(2,5.49,10.1,y=py)).fuse(cyl(1.35,10.1,11.5,y=py)).fuse(cyl(2,11.5,11.9,y=py)).fuse(cyl(2.9,5.4,7.2,y=py))
add('03_MainGear_AP1',main,'main','60T smooth involute gear; raised crank carrier')
handle=gear(40,m,20,-1.8,3,hy,math.pi/2+math.pi/40).fuse(cyl(7,1.19,21.5,y=hy)).fuse(cyl(41.22285,21.4,29.3944223,y=hy))
for rr in [12,17,22,27,32,37]:handle=handle.cut(cyl(rr+.45,28.6,29.5,y=hy).cut(cyl(rr-.45,28.5,29.6,y=hy)))
handle=handle.cut(cyl(4.225,-2,26.1,y=hy)).cut(cyl(4.6,1.2,23,y=hy)).cut(cyl(5.5,26,30,y=hy))
add('04_Handle_AP1',handle,'handle','40T low gear, hollow printed journal and exposed knob')
yoke=box(cx-7.0,cx+7.0,-69.5,20,7.5,11).cut(box(cx-3.75,cx+3.75,-64,17.5,7.4,11.1))
# Central cover-mounted datum minimizes eccentric drive moment.
# 14mm guide length, 0.20mm nominal flank clearance; 1.8mm floor.
shoe=box(cx-7,cx+7,cy-4,cy+4,12.5,17.1)
shoe=shoe.cut(box(cx-7.1,cx+7.1,cy-1.9,cy+1.9,14.3,17.2))
shoe=shoe.cut(box(cx-4,cx+4,cy-2.1,cy+2.1,14.3,17.2))
for xa,xb in [(cx-7.0,cx-4.95),(cx+4.95,cx+7.0)]:
 shoe=shoe.fuse(box(xa,xb,cy-4,cy+4,10.9,12.6))
yoke=yoke.fuse(shoe)
# Front flat support only, no lateral datum.
yoke=yoke.fuse(box(cx-7.0,cx+7.0,17.9,21.3,10.1,12.6))
yoke=yoke.cut(box(cx-7,cx+7,17.9,21.3,0,10.1))
# Floating rear pad supports Z without a second lateral locating rail.
yoke=yoke.fuse(box(cx-7.0,cx+7.0,-71.,-67.7,10.1,12.6))
yoke=yoke.cut(box(cx-7.1,cx+7.1,-71.,-67.7,0,10.1))
for xa,xb in [(cx-7.0,cx-4.95),(cx+4.95,cx+7.0)]:yoke=yoke.fuse(box(xa,xb,21.2,27,4.1,11))
yoke=yoke.fuse(box(cx-7.0,cx+7.0,25,27,4.1,5.35))
yoke=yoke.fuse(orig[4].intersect(box(-10,10,25,31,5.34,12)))

# Visible 14 x 18mm arrow plate; contact nose below remains unchanged.
yoke=yoke.fuse(box(cx-3,cx+3,16.6,19.0,10.9,21.3))
arrow=[(cx-3,9),(cx+3,9),(cx+3,18),(cx+7.0,18),(cx,27),(cx-7.0,18),(cx-3,18)]
yoke=yoke.fuse(polyxy(arrow,21.2,2.0))
# Relief extends past support edges to allow small yaw and Y error.
yoke=yoke.cut(box(cx-7.5,cx+7.5,17.55,21.65,0,10.1)).cut(box(cx-7.5,cx+7.5,-71.35,-67.35,0,10.1))
add('05_Yoke_AP1',yoke,'yoke','Integral visible arrow; central datum saddle and floating rear support')
add('06_CrankRoller_AP1',cyl(3.5,7.8,10.0,y=py).cut(cyl(2.2,7.7,10.1,y=py)).cut(cq.Solid.makeCone(2.4,2.2,.2,V(cx,py,7.8))),'roller','Independent printed roller; 0.20mm radial clearance')
def clip(ro,ri,mouth,z0,z1,x,y):return cyl(ro,z0,z1,x,y).cut(cyl(ri,z0-.1,z1+.1,x,y)).cut(box(x-mouth/2,x+mouth/2,y,y+ro+.1,z0-.1,z1+.1))
add('10_MainRetainer_AP1',clip(4.3,2.65,4.7,5.7,6.7,cx,cy),'fixed','Flat printed non-clamping main retainer')
add('11_HandleRetainer_AP1',clip(4.3,2.65,4.7,26.1,27.3,cx,hy),'fixed','Flat printed non-clamping knob retainer')
add('12_RollerRetainer_AP1',clip(3.0,1.45,2.5,10.2,11.3,cx,py),'roller','Small flat printed crank retainer; test coupon first')
add('15_CombLower_existing',orig[8],'comb','Unchanged default Happy Birthday comb')
add('16_CombUpper_existing',orig[9],'comb','Unchanged default Happy Birthday comb')
for i,(lx,ly) in enumerate(lockpos):
 s=cyl(2.1,10.6,19.55,lx,ly).fuse(cyl(3.6,19.5,20.7,lx,ly)).fuse(box(lx-.8,lx+.8,ly-3.5,ly+3.5,10.6,11.9)).cut(box(lx-.5,lx+.5,ly-2.7,ly+2.7,20.15,20.8));add(f'{19+i:02}_CaseLock_AP1',s,'fixed','Printed quarter-turn case lock, shown in locked position')
from OCP.BRepTools import BRepTools
for n,s in parts.items():
 cq.exporters.export(cq.Shape.importBrep(str(Q/(n+'.brep'))),str(Q/(n+'.step')));s=cq.Shape.importBrep(str(Q/(n+'.brep')));BRepTools.Clean_s(s.wrapped);cq.exporters.export(s,str(Q/(n+'.stl')),tolerance=.02,angularTolerance=.08)
 b=s.BoundingBox();meta[n]['bounds']=[getattr(b,k) for k in ['xmin','xmax','ymin','ymax','zmin','zmax']]
D={'revision':'PF2','legacy_screw_features_removed':True,'sync_removed':True,'guide_flank_clearance_mm':0.20,'visible_arrow_mm':[14,18,2],'requires_closed_cover':True,'units':'mm','cx':cx,'cy':cy,'hy':hy,'stroke':2*E,'ratio':1.5,'part_count':len(parts),'all_parts_printable':True,'purchased_hardware':0,'parts':meta,'physical_test':False,'friction_test':False,'website_modified':False}
(O/'design.json').write_text(json.dumps(D,indent=2));print('BUILT',flush=True)
