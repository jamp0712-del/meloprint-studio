import rhino3dm as r,json,pathlib,subprocess
P=pathlib.Path('engineeringpf2/output');D=json.loads((P/'design.json').read_text());m=r.File3dm.Read(str(P/'native.3dm'));assert len(m.Objects)==15
cols={'01':(65,72,82,255),'02':(77,88,101,255),'03':(49,152,153,255),'04':(55,63,76,255),'05':(245,176,65,255),'06':(227,215,178,255),'07':(226,177,67,255),'08':(226,177,67,255),'09':(224,115,53,255),'15':(235,232,221,255),'16':(211,224,229,255)}
faces=0;record=[]
for o in m.Objects:
 n=o.Attributes.Name;g=o.Geometry;assert isinstance(g,r.Brep) and g.IsValid and g.IsSolid,n
 layer=r.Layer();layer.Name=n;layer.Color=cols.get(n[:2],(174,184,195,255));li=m.Layers.Add(layer);o.Attributes.LayerIndex=li;o.Attributes.WireDensity=-1;o.Attributes.SetUserString('Part',n);o.Attributes.SetUserString('Printable','Yes');o.Attributes.SetUserString('Revision','PF2 experimental');faces+=len(g.Faces);record.append({'name':n,'faces':len(g.Faces),'valid':g.IsValid,'solid':g.IsSolid})
m.Settings.ModelUnitSystem=r.UnitSystem.Millimeters;m.Settings.ModelAbsoluteTolerance=.005
m.Strings['AP1_status']='Experimental prototype. No physical print/friction/durability test.';m.Strings['Website']='Unchanged';m.Strings['Hardware']='15 fully printed assembly parts; zero purchased hardware';m.Strings['Source']='Standalone CG1-envelope redesign';m.Strings['Motion']='72.128mm travel; 60/40 main drive; central plain guide; integral visible arrow'
tmp=P/'styled.3dm';out=P/'Meloprint_PF2_Assembly.3dm';assert m.Write(str(tmp),7);subprocess.run(['engineeringpf/sdk/set-view',str(tmp),str(out)],check=True)
m=r.File3dm.Read(str(out));assert len(m.Objects)==15 and all(isinstance(o.Geometry,r.Brep) and o.Geometry.IsValid and o.Geometry.IsSolid for o in m.Objects)
report={'parts':len(m.Objects),'closed_valid_breps':15,'faces':faces,'units':'mm','absolute_tolerance_mm':.005,'meshes_as_objects':0,'isocurves_hidden':True,'shaded_view_configured':True,'Rhino_desktop_visual_test':False,'objects':record};(P/'3dm_checks.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='objects'}));
