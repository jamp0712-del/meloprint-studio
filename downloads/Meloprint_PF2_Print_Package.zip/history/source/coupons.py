import cadquery as c,pathlib,json,trimesh,numpy as np
P=pathlib.Path('engineeringpf2/output/coupons');P.mkdir(exist_ok=True)
def box(a,b,c0,d,e,f):return c.Solid.makeBox(b-a,d-c0,f-e,c.Vector(a,c0,e))
parts={}
for gap in [.15,.20,.25]:
 parts[f'C01_Saddle_gap_{gap:.2f}']=box(-7,7,-4,4,0,4.6).cut(box(-7.1,7.1,-1.7-gap,1.7+gap,1.8,4.7)).cut(box(-4,4,-1.9-gap,1.9+gap,1.8,4.7))
# Inverted for printing: flange on bed, tongue pointing upward.
parts['C02_Rail_3.40mm']=box(-15,15,-4,4,0,1.8).fuse(box(-15,15,-1.7,1.7,1.79,4.25))
for n,s in parts.items():
 assert s.isValid() and len(s.Solids())==1
 c.exporters.export(s,str(P/(n+'.step')));c.exporters.export(s,str(P/(n+'.stl')),tolerance=.01)
 m=trimesh.load(P/(n+'.stl'));assert m.is_watertight
print('guide coupons',len(parts))
