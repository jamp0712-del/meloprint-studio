import pathlib,json,numpy as np,trimesh,cadquery as cq
P=pathlib.Path('engineeringpf2/output');D=json.loads((P/'design.json').read_text());T=P/'print_stl';T.mkdir(exist_ok=True);report={};assembly=cq.Assembly(name='Meloprint_AP1')
for n,d in D['parts'].items():
 m=trimesh.load(P/'parts'/(n+'.stl'));parts=m.split(only_watertight=False);assert m.is_watertight and m.is_winding_consistent,n;assert len(parts)==1,(n,len(parts));assert m.volume>0
 ident=n[:2];rotation=None
 if ident in ['02']:rotation=(np.pi,[1,0,0])
 elif ident=='05':rotation=(np.pi/2,[0,1,0])
 elif ident in ['07','08']:rotation=(-np.pi/2,[1,0,0])
 elif ident in ['13','14','17']:rotation=(np.pi/2,[1,0,0])
 elif ident=='09':rotation=None
 if rotation:m.apply_transform(trimesh.transformations.rotation_matrix(*rotation))
 b=m.bounds;m.apply_translation([-b[:,0].mean(),-b[:,1].mean(),-b[0,2]]);m.export(T/(n+'.stl'))
 report[n]={'watertight':bool(m.is_watertight),'connected_components':len(parts),'positive_volume_mm3':float(m.volume),'print_dimensions_mm':m.extents.tolist(),'triangles':len(m.faces),'orientation_rotation':None if rotation is None else [float(rotation[0]*180/np.pi),rotation[1]]}
 assembly.add(cq.Shape.importBrep(str(P/'parts'/(n+'.brep'))),name=n)
assembly.save(str(P/'Meloprint_PF2_Assembly.step'))
(P/'mesh_checks.json').write_text(json.dumps(report,indent=2));print('PASS',len(report),'watertight single-component STLs')
