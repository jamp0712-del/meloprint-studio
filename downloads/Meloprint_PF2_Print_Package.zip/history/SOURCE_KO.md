v41 최신 구조는 source/v41 및 전체 인수인계 ZIP의 site/scripts/build-v41.py를 사용하십시오. source/build.py는 PF2 초기 설계 기록입니다.
