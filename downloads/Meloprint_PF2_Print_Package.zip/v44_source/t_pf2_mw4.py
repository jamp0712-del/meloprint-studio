# -*- coding: utf-8 -*-
# MW4 variant: convert site MW4 3dm, apply the same structural fixes (base pin holes, handle/yoke from the fixed AP1 set,
# new rear guide rail 23). Writes in/pf2mw4mod_brep (real names) and in/pf2mw4_valid (AP1 names, for the validators).
import sys, os
sys.path.insert(0, r"C:\Users\Public\mbx_work")
import rhino3dm as r
from occ_conv import brep_to_occ, volume
from ap1_view import load_cache
from ap1_tool import n_solids, valid
import pf2_mods as PM
from OCP.BRepTools import BRepTools

SRC = r"C:\Users\Public\mbx_work\site\cad\Meloprint_PF2_MW4_Assembly.3dm"
FIX = load_cache(r"C:\Users\Public\mbx_work\in\pf2mod_brep")
f = r.File3dm.Read(SRC)
S = {}
for o in f.Objects:
    s, info = brep_to_occ(o.Geometry)
    S[o.Attributes.Name] = s
    print("%-22s conv solids=%d valid=%s vol=%.2f" % (o.Attributes.Name, n_solids(s), valid(s), volume(s)))
out = dict(S)
out["01_Base_MW4"] = PM.base_pin_holes(S["01_Base_MW4"])
for k in ("04_Handle_AP1", "05_Yoke_AP1", "23_RearGuideRail"):
    out[k] = FIX[k]
# mechanism parts other than the fixed ones must be identical to the AP1 set
for k in ("03_MainGear_AP1", "06_CrankRoller_AP1", "10_MainRetainer_AP1", "11_HandleRetainer_AP1", "12_RollerRetainer_AP1"):
    print("%-22s MW4 vol %.3f vs AP1 %.3f" % (k, volume(S[k]), volume(FIX[k])))
A = {"01_Base_MW4": "01_Base_AP1", "02_Cover_MW4": "02_Cover_AP1", "15_CombLower_MW4": "15_CombLower_AP1", "16_CombUpper_MW4": "16_CombUpper_AP1"}
for d, alias in ((r"C:\Users\Public\mbx_work\in\pf2mw4mod_brep", False), (r"C:\Users\Public\mbx_work\in\pf2mw4_valid", True)):
    os.makedirs(d, exist_ok=True)
    for fn in os.listdir(d):
        os.remove(os.path.join(d, fn))
    for n, s in out.items():
        BRepTools.Write_s(s, os.path.join(d, (A.get(n, n) if alias else n) + ".brep"))
print("01_Base_MW4 after holes: solids=%d valid=%s vol=%.2f (d=%.2f)" % (n_solids(out["01_Base_MW4"]), valid(out["01_Base_MW4"]),
      volume(out["01_Base_MW4"]), volume(out["01_Base_MW4"]) - volume(S["01_Base_MW4"])))
