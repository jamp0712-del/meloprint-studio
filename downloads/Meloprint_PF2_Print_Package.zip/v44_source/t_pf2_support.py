﻿# -*- coding: utf-8 -*-
import sys, math
sys.path.insert(0, r"C:\Users\Public\mbx_work")
from pf2_kin import load, posed, first_contact, pitch_free, ECC, MAIN_C
src = sys.argv[1] if len(sys.argv) > 1 else r"C:\Users\Public\mbx_work\in\pf2_brep"
M = load(src)
Y = [n for n in M if n.startswith("05")][0]
others = [n for n in M if n != Y and n[:2] not in ("15", "16")]
for th in (0, 45, 90, 135, 180):
    P = posed(M, th)
    who, d = first_contact(P, Y, others, (0, 0, -1))
    up, du = first_contact(P, Y, others, (0, 0, 1))
    print("theta %3d  free drop %.3f (stops on %s) | free lift %.3f (stops on %s)" % (th, d, who, du, up))
    # yoke resting after the drop; check back-end droop about front support (y ~ 20) and front lift about the roller
    P[Y] = P[Y].translate((0, 0, -d + 0.002))
    roller_y = MAIN_C[1] + ECC * math.cos(math.radians(th))
    for lab, py, pz, sg in (("back end down, pivot front rail", 20.0, 9.85, 1), ("back end down, pivot roller", roller_y, 7.2, 1),
                            ("front end down, pivot roller", roller_y, 7.2, -1)):
        hits, a = pitch_free(P, Y, others, py, pz, sg)
        drop_back = math.radians(a) * abs(-71.0 - py)
        print("     %-34s free %.3f deg (= %.2f mm at the far end) first hit: %s" % (lab, a, drop_back, hits[:2] if hits else None))

