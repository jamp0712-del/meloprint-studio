# -*- coding: utf-8 -*-
# Full validation for a PF2-style assembly (static, sweep, gaps, assembly path). Usage: src_dir out_json
import sys, json, math, time
sys.path.insert(0, r"C:\Users\Public\mbx_work")
from pf2_kin import load, posed, part_xf, first_contact
from mf_tool import inter_vol

src, out = sys.argv[1], sys.argv[2]
M = load(src)
names = sorted(M)
R = {}
PLUCK = lambda a, b: (a.startswith("05") and b[:2] in ("15", "16")) or (b.startswith("05") and a[:2] in ("15", "16"))

st = []
for i in range(len(names)):
    for j in range(i + 1, len(names)):
        v, bb = inter_vol(M[names[i]], M[names[j]])
        if v > 1e-3:
            st.append((names[i], names[j], round(v, 4), [round(c, 2) for c in bb], "pluck" if PLUCK(names[i], names[j]) else ""))
R["static"] = st
print("STATIC")
for s in st:
    print("  ", s)

Y = [n for n in names if n.startswith("05")][0]
others = [n for n in names if n != Y and n[:2] not in ("15", "16")]
P0 = posed(M, 90)
who, drop = first_contact(P0, Y, others, (0, 0, -1))
R["yoke_drop"] = (drop, who)
print("yoke free drop %.3f on %s" % (drop, who))

worst = {}
mov = [n for n in names if part_xf(n, 10) is not None]
t0 = time.time()
for th in range(0, 360, 5):
    P = posed(M, th)
    P[Y] = P[Y].translate((0, 0, -drop + 0.002))
    done = set()
    for a in mov:
        for b in names:
            if a == b or (b, a) in done:
                continue
            done.add((a, b))
            v, bb = inter_vol(P[a], P[b])
            if v > 1e-3:
                k = tuple(sorted((a, b)))
                if k not in worst or v > worst[k][1]:
                    worst[k] = (th, round(v, 4), [round(c, 2) for c in bb], "pluck" if PLUCK(a, b) else "")
R["sweep"] = [(k[0], k[1]) + w for k, w in sorted(worst.items())]
print("SWEEP %.0fs" % (time.time() - t0))
for s in R["sweep"]:
    print("  ", s)

pairs = [("05", "01"), ("05", "02"), ("05", "03"), ("05", "06"), ("05", "04"), ("05", "11"), ("06", "03"), ("04", "03"), ("04", "01"),
         ("04", "02"), ("11", "02"), ("03", "01"), ("05", "23"), ("04", "23"), ("03", "23")]
def nm(k):
    c = [n for n in names if n.startswith(k)]
    return c[0] if c else None
gaps = {}
for th in range(0, 360, 30):
    P = posed(M, th)
    P[Y] = P[Y].translate((0, 0, -drop + 0.002))
    for a, b in pairs:
        A, B = nm(a), nm(b)
        if A and B:
            gaps.setdefault(A + " | " + B, []).append(round(P[A].min_gap(P[B], 3.0), 3))
R["gaps"] = {k: (min(v), max(v)) for k, v in gaps.items()}
print("GAPS")
for k, v in R["gaps"].items():
    print("   %-40s %s" % (k, v))
json.dump(R, open(out, "w"), indent=1)
