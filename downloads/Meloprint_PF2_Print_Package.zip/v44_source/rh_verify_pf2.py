# -*- coding: utf-8 -*-
# Rhino 7: import PF2-fixed STEP parts, verify solids/volumes, Rhino-kernel interference at several crank angles,
# save a Rhino 7 B-rep 3dm with layers, capture images.
import os, json, math, traceback
import Rhino
import Rhino.Geometry as G
import scriptcontext as sc
import rhinoscriptsyntax as rs
import System.Drawing as SD

W = r"C:\Users\Public\mbx_work"
OUT = W + r"\pf2_out"
LOG = open(W + r"\rh_verify_pf2.log", "w")
def L(*a):
    LOG.write(" ".join(str(x) for x in a) + "\n"); LOG.flush()

COL = {"01": (190, 190, 190), "02": (90, 170, 90), "03": (230, 140, 30), "04": (220, 175, 40), "05": (210, 60, 60),
       "06": (230, 90, 160), "10": (30, 180, 200), "11": (60, 120, 210), "12": (30, 180, 200), "15": (140, 90, 200),
       "16": (175, 135, 225), "19": (160, 160, 70), "20": (160, 160, 70), "21": (160, 160, 70), "22": (160, 160, 70),
       "23": (40, 40, 40)}
MAIN_C = (0.0, -23.218); HANDLE_C = (0.0, -80.544); ECC = 36.064


def xf_for(n, th):
    t = math.radians(th)
    k = n[:2]
    if k == "03":
        return G.Transform.Rotation(math.radians(-th), G.Vector3d.ZAxis, G.Point3d(MAIN_C[0], MAIN_C[1], 0))
    if k in ("04", "11"):
        return G.Transform.Rotation(math.radians(1.5 * th), G.Vector3d.ZAxis, G.Point3d(HANDLE_C[0], HANDLE_C[1], 0))
    if k in ("06", "12"):
        return G.Transform.Translation(G.Vector3d(ECC * math.sin(t), ECC * math.cos(t) - ECC, 0))
    if k == "05":
        return G.Transform.Translation(G.Vector3d(ECC * math.sin(t), 0, -0.248))
    return G.Transform.Identity


def ivol(a, b):
    def one(bb):
        r = G.Brep.CreateBooleanIntersection(a, bb, 0.001)
        if r is None:
            return None
        return sum(abs(G.VolumeMassProperties.Compute(x).Volume) for x in r if x.IsSolid)
    if not G.BoundingBox.Intersection(a.GetBoundingBox(True), b.GetBoundingBox(True)).IsValid:
        return 0.0
    v = one(b)
    if v is not None:
        return v
    best = None
    for d in ((0, 0, .004), (0, 0, -.004), (.004, 0, 0), (-.004, 0, 0), (0, .004, 0), (0, -.004, 0)):
        c = b.DuplicateBrep(); c.Translate(G.Vector3d(*d)); vv = one(c)
        if vv is not None and (best is None or vv < best):
            best = vv
    return best


try:
    doc = sc.doc
    doc.ModelUnitSystem = Rhino.UnitSystem.Millimeters
    rep = json.load(open(OUT + r"\export_report.json"))
    parts = {}
    for fn in sorted(os.listdir(OUT + r"\STEP")):
        if not fn.endswith(".step") or "Assembly" in fn:
            continue
        n = fn[:-5]
        before = set(o.Id for o in doc.Objects)
        ok = rs.Command('_-Import "' + OUT + "\\STEP\\" + fn + '" _Enter', False)
        new = [o for o in doc.Objects if o.Id not in before]
        for o in new:
            if isinstance(o, Rhino.DocObjects.InstanceObject):
                rs.ExplodeBlockInstance(o.Id, True)
        new = [o for o in doc.Objects if o.Id not in before and not isinstance(o, Rhino.DocObjects.InstanceObject)]
        kinds = [type(o.Geometry).__name__ for o in new]
        breps = []
        for o in new:
            g = o.Geometry
            b = g if isinstance(g, G.Brep) else (g.ToBrep() if hasattr(g, "ToBrep") else None)
            if b is not None:
                breps.append(b.DuplicateBrep())
            doc.Objects.Delete(o.Id, True)
        if len(breps) > 1:
            j = G.Brep.JoinBreps(breps, 0.01)
            breps = list(j) if j else breps
        if not breps:
            L("%-22s import=%s NO BREP kinds=%s" % (n, ok, kinds)); continue
        b = max(breps, key=lambda x: x.GetBoundingBox(True).Diagonal.Length)
        if not b.IsSolid:
            b.JoinNakedEdges(0.01)
        naked = sum(1 for e in b.Edges if e.Valence == G.EdgeAdjacency.Naked)
        vm = G.VolumeMassProperties.Compute(b) if b.IsSolid else None
        parts[n] = b
        vol = vm.Volume if vm else float("nan")
        L("%-22s import=%s kinds=%s pieces=%d solid=%s valid=%s faces=%d naked=%d rhino_vol=%.2f occ_vol=%.2f diff=%.4f%%" % (
            n, ok, ",".join(sorted(set(kinds))), len(breps), b.IsSolid, b.IsValid, b.Faces.Count, naked, vol, rep[n]["brep_vol"], 100 * (vol - rep[n]["brep_vol"]) / rep[n]["brep_vol"]))
    pairs = [("05", "23"), ("05", "01"), ("05", "02"), ("05", "03"), ("05", "06"), ("04", "03"), ("23", "04"), ("23", "01"), ("23", "03"), ("06", "03"), ("11", "02")]
    def nm(k):
        return [x for x in parts if x.startswith(k)][0]
    L("== Rhino-kernel interference (yoke resting 0.248 lower)")
    for th in (0, 45, 90, 135, 180, 270):
        row = []
        for a, b in pairs:
            A = parts[nm(a)].DuplicateBrep(); A.Transform(xf_for(nm(a), th))
            B = parts[nm(b)].DuplicateBrep(); B.Transform(xf_for(nm(b), th))
            v = ivol(A, B)
            row.append("%s-%s:%s" % (a, b, "NA" if v is None else ("%.3f" % v)))
        L("  theta %3d  " % th + "  ".join(row))
    # save Rhino 7 B-rep 3dm (assembly pose theta = 0, yoke resting)
    f = Rhino.FileIO.File3dm()
    f.Settings.ModelUnitSystem = Rhino.UnitSystem.Millimeters
    f.Settings.ModelAbsoluteTolerance = 0.005
    top = Rhino.DocObjects.Layer(); top.Name = "Meloprint_PF2_v44"
    f.AllLayers.Add(top)
    pid = [l for l in f.AllLayers if l.Name == "Meloprint_PF2_v44"][0].Id
    for n in sorted(parts):
        lay = Rhino.DocObjects.Layer(); lay.Name = n; lay.ParentLayerId = pid
        c = COL.get(n[:2], (150, 150, 150)); lay.Color = SD.Color.FromArgb(c[0], c[1], c[2])
        f.AllLayers.Add(lay)
    lidx = dict((l.Name, l.Index) for l in f.AllLayers)
    for n in sorted(parts):
        at = Rhino.DocObjects.ObjectAttributes(); at.Name = n; at.LayerIndex = lidx[n]
        at.SetUserString("Revision", "PF2-v44 (rear lower guide + fits)")
        b = parts[n].DuplicateBrep()
        if n.startswith("05"):
            b.Translate(G.Vector3d(0, 0, -0.248))
        f.Objects.AddBrep(b, at)
    p = OUT + r"\Meloprint_PF2_v44_Assembly.3dm"
    f.Write(p, 7)
    back = Rhino.FileIO.File3dm.Read(p)
    bad = [o.Attributes.Name for o in back.Objects if not (isinstance(o.Geometry, G.Brep) and o.Geometry.IsSolid and o.Geometry.IsValid)]
    L("saved", p, "version", Rhino.FileIO.File3dm.ReadArchiveVersion(p), "objects", len(back.Objects), "bad", bad)
    # images
    for n, b in parts.items():
        at = Rhino.DocObjects.ObjectAttributes(); at.Name = n
        at.ColorSource = Rhino.DocObjects.ObjectColorSource.ColorFromObject
        c = COL.get(n[:2], (150, 150, 150)); at.ObjectColor = SD.Color.FromArgb(*c)
        bb = b.DuplicateBrep()
        if n.startswith("05"):
            bb.Translate(G.Vector3d(0, 0, -0.248))
        doc.Objects.AddBrep(bb, at)
    view = doc.Views.ActiveView; view.Maximized = True; vp = view.ActiveViewport
    for dm in Rhino.Display.DisplayModeDescription.GetDisplayModes():
        if dm.EnglishName.replace(" ", "").lower() == "shaded":
            vp.DisplayMode = dm
    def cap(name, proj, bbox=None, hide=()):
        for o in doc.Objects.GetObjectList(Rhino.DocObjects.ObjectEnumeratorSettings()):
            pass
        ids = {}
        es = Rhino.DocObjects.ObjectEnumeratorSettings(); es.HiddenObjects = True
        for o in doc.Objects.GetObjectList(es):
            if any(o.Attributes.Name.startswith(h) for h in hide):
                doc.Objects.Hide(o.Id, True)
            else:
                doc.Objects.Show(o.Id, True)
        vp.SetProjection(proj, None, False)
        if bbox:
            vp.ZoomBoundingBox(bbox)
        else:
            vp.ZoomExtents()
        for _ in range(3):
            view.Redraw(); Rhino.RhinoApp.Wait()
        vc = Rhino.Display.ViewCapture(); vc.Width = 1800; vc.Height = 1100; vc.ScaleScreenItems = False; vc.DrawAxes = False; vc.DrawGrid = False
        vc.CaptureToBitmap(view).Save(OUT + "\\img_" + name + ".png")
    T = Rhino.Display.DefinedViewportProjection
    cap("assembly", T.Perspective)
    cap("open_top", T.Perspective, hide=("02", "11"))
    cap("rear_rail", T.Perspective, bbox=G.BoundingBox(G.Point3d(-45, -85, -4), G.Point3d(45, -55, 14)), hide=("02", "11", "04"))
    doc.Modified = False
except Exception:
    L("ERR", traceback.format_exc())
L("##DONE##")
LOG.close()
