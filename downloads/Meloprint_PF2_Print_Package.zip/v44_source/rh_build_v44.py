# -*- coding: utf-8 -*-
# Rhino 7: build the v44 surface 3DMs from the site's v43 files. Unchanged parts keep their original Breps;
# 01 base, 04 handle, 05 yoke are replaced by the fixed parts and 23_RearGuideRail is added. Saved as Rhino 7.
import os, math, traceback
import Rhino
import Rhino.Geometry as G
import scriptcontext as sc
import rhinoscriptsyntax as rs
import System.Drawing as SD

W = r"C:\Users\Public\mbx_work"
OUT = W + r"\pf2_out"
LOG = open(W + r"\rh_build_v44.log", "w")
def L(*a):
    LOG.write(" ".join(str(x) for x in a) + "\n"); LOG.flush()
REV = "PF2-v44 rear lower guide"


def import_step(path):
    doc = sc.doc
    before = set(o.Id for o in doc.Objects)
    rs.Command('_-Import "' + path + '" _Enter', False)
    new = [o for o in doc.Objects if o.Id not in before]
    for o in new:
        if isinstance(o, Rhino.DocObjects.InstanceObject):
            rs.ExplodeBlockInstance(o.Id, True)
    new = [o for o in doc.Objects if o.Id not in before and not isinstance(o, Rhino.DocObjects.InstanceObject)]
    bs = []
    for o in new:
        if isinstance(o.Geometry, G.Brep):
            bs.append(o.Geometry.DuplicateBrep())
        doc.Objects.Delete(o.Id, True)
    if len(bs) != 1:
        raise RuntimeError("expected one brep in %s, got %d" % (path, len(bs)))
    return bs[0]


def vol(b):
    m = G.VolumeMassProperties.Compute(b)
    if m is None:
        mp = Rhino.Geometry.MeshingParameters.QualityRenderMesh
        ms = G.Mesh.CreateFromBrep(b, mp)
        mm = G.Mesh(); [mm.Append(x) for x in ms]
        m2 = G.VolumeMassProperties.Compute(mm)
        return (m2.Volume if m2 else float("nan")), "mesh"
    return m.Volume, "brep"


def ivol(a, b):
    if not G.BoundingBox.Intersection(a.GetBoundingBox(True), b.GetBoundingBox(True)).IsValid:
        return 0.0
    r = G.Brep.CreateBooleanIntersection(a, b, 0.001)
    if r is None:
        return None
    return sum(abs(G.VolumeMassProperties.Compute(x).Volume) for x in r if x.IsSolid and G.VolumeMassProperties.Compute(x))


try:
    fixed = {"04_Handle_AP1": import_step(OUT + r"\STEP\04_Handle_AP1.step"),
             "05_Yoke_AP1": import_step(OUT + r"\STEP\05_Yoke_AP1.step"),
             "23_RearGuideRail": import_step(OUT + r"\STEP\23_RearGuideRail.step"),
             "01_Base_AP1": import_step(OUT + r"\STEP\01_Base_AP1.step"),
             "01_Base_MW4": import_step(OUT + r"\STEP_MW4_01_Base_MW4.step")}
    for k, b in fixed.items():
        v, how = vol(b)
        L("fixed %-18s solid=%s valid=%s faces=%d vol=%.2f" % (k, b.IsSolid, b.IsValid, b.Faces.Count, v))
    for tag, src, dst in (("AP1", W + r"\site\cad\Meloprint_PF2_Assembly.3dm", OUT + r"\Meloprint_PF2_v44_Assembly.3dm"),
                          ("MW4", W + r"\site\cad\Meloprint_PF2_MW4_Assembly.3dm", OUT + r"\Meloprint_PF2_v44_MW4_Assembly.3dm")):
        f0 = Rhino.FileIO.File3dm.Read(src)
        f = Rhino.FileIO.File3dm()
        f.Settings.ModelUnitSystem = f0.Settings.ModelUnitSystem
        f.Settings.ModelAbsoluteTolerance = f0.Settings.ModelAbsoluteTolerance
        f.Settings.ModelAngleToleranceRadians = f0.Settings.ModelAngleToleranceRadians
        idx = {}
        for l in f0.AllLayers:
            nl = Rhino.DocObjects.Layer(); nl.Name = l.Name; nl.Color = l.Color
            f.AllLayers.Add(nl)
        for l in f.AllLayers:
            idx[l.Name] = l.Index
        lay0 = dict((l.Index, l.Name) for l in f0.AllLayers)
        geo = {}
        faces = 0
        for o in f0.Objects:
            n = o.Attributes.Name
            a = o.Attributes.Duplicate()
            a.LayerIndex = idx[lay0[o.Attributes.LayerIndex]]
            b = fixed[n].DuplicateBrep() if n in fixed else o.Geometry.DuplicateBrep()
            a.SetUserString("Revision", REV if n in fixed else a.GetUserString("Revision") or "PF2")
            if n in fixed:
                a.SetUserString("Change", {"01_Base_AP1": "2x pin holes for rail 23", "01_Base_MW4": "2x pin holes for rail 23",
                                           "04_Handle_AP1": "tooth flanks -0.0025 rad (backlash 0.093->0.147 mm)",
                                           "05_Yoke_AP1": "roller slot 0.25->0.15 mm per side"}[n])
            f.Objects.AddBrep(b, a)
            geo[n] = b
            faces += b.Faces.Count
        nl = Rhino.DocObjects.Layer(); nl.Name = "23_RearGuideRail"; nl.Color = SD.Color.FromArgb(174, 184, 195)
        f.AllLayers.Add(nl)
        li = [l.Index for l in f.AllLayers if l.Name == "23_RearGuideRail"][0]
        a = Rhino.DocObjects.ObjectAttributes(); a.Name = "23_RearGuideRail"; a.LayerIndex = li
        a.SetUserString("Part", "23_RearGuideRail"); a.SetUserString("Printable", "Yes"); a.SetUserString("Revision", REV)
        a.SetUserString("Change", "new: lower guide under the arrow/yoke rear bar, 2 pins into base")
        f.Objects.AddBrep(fixed["23_RearGuideRail"].DuplicateBrep(), a)
        geo["23_RearGuideRail"] = fixed["23_RearGuideRail"]
        faces += fixed["23_RearGuideRail"].Faces.Count
        f.Strings.SetString("MeloprintRevision", "PF2-v44")
        f.Strings.SetString("Changes", "v44 = v43 + 23_RearGuideRail (rear lower guide for the arrow/yoke), base pin holes, handle backlash, yoke roller slot fit")
        f.Write(dst, 7)
        back = Rhino.FileIO.File3dm.Read(dst)
        bad = [o.Attributes.Name for o in back.Objects if not (isinstance(o.Geometry, G.Brep) and o.Geometry.IsSolid and o.Geometry.IsValid)]
        L("%s saved %s archive=%d objects=%d faces=%d bad=%s" % (tag, dst, Rhino.FileIO.File3dm.ReadArchiveVersion(dst), len(back.Objects), faces, bad))
        base = [k for k in geo if k.startswith("01_")][0]
        cov = [k for k in geo if k.startswith("02_")][0]
        c16 = [k for k in geo if k.startswith("16_")][0]
        v, how = vol(geo[cov])
        L("  %s volume %.2f (%s)" % (cov, v, how))
        L("  rail23 x %s: %s   rail23 x %s: %s" % (base, ivol(geo["23_RearGuideRail"], geo[base]), cov, ivol(geo["23_RearGuideRail"], geo[cov])))
        y = geo["05_Yoke_AP1"].DuplicateBrep(); y.Translate(G.Vector3d(0, 0, -0.248))
        L("  positive control yoke x %s (designed pluck overlap): %s" % (c16, ivol(y, geo[c16])))
        L("  yoke x rail23: %s  yoke x %s: %s  yoke x %s: %s" % (ivol(y, geo["23_RearGuideRail"]), base, ivol(y, geo[base]), cov, ivol(y, geo[cov])))
except Exception:
    L("ERR", traceback.format_exc())
L("##DONE##")
LOG.close()
