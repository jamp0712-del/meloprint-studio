# -*- coding: utf-8 -*-
# Build v44 site assets: assembly-frame STLs (viewer / mesh 3DM) and print STLs using the site's own orientation rules.
import sys, os, json, io
sys.path.insert(0, r"C:\Users\Public\mbx_work")
import numpy as np, trimesh
from ap1_view import load_cache
from mf_tool import to_manifold
from ap1_export import write_stl

OUT = sys.argv[1]
AP = load_cache(r"C:\Users\Public\mbx_work\in\pf2mod_brep")
MW = load_cache(r"C:\Users\Public\mbx_work\in\pf2mw4mod_brep")
ROT = json.load(open(r"C:\Users\Public\mbx_work\print_rot.json"))
FLIP = [[1, 0, 0], [0, -1, 0], [0, 0, -1]]


def mesh(shape, defl=0.004):
    mm = to_manifold(shape, defl).to_mesh()
    return np.array(mm.vert_properties)[:, :3].astype(float), np.array(mm.tri_verts).astype(np.int64)


def put(path, V, F, name):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    write_stl(path, V, F, name)
    t = trimesh.load(path)
    print("%-48s tris=%6d watertight=%s vol=%.2f bounds=%s..%s" % (os.path.relpath(path, OUT), len(F), t.is_watertight, t.volume,
          np.round(t.bounds[0], 2), np.round(t.bounds[1], 2)))
    return t


def print_xf(V, R, mode):
    W = V @ np.array(R, float).T
    if mode == "center":       # print_stl/ convention: XY bbox centre at origin, z from 0
        W -= np.array([(W[:, 0].min() + W[:, 0].max()) / 2, (W[:, 1].min() + W[:, 1].max()) / 2, W[:, 2].min()])
    else:                      # models/01_Base_MW4_PRINT.stl convention: x centred, y and z from 0
        W -= np.array([(W[:, 0].min() + W[:, 0].max()) / 2, W[:, 1].min(), W[:, 2].min()])
    return W


jobs = [("01_Base_AP1", AP["01_Base_AP1"]), ("01_Base_MW4", MW["01_Base_MW4"]), ("04_Handle_AP1", AP["04_Handle_AP1"]),
        ("05_Yoke_AP1", AP["05_Yoke_AP1"]), ("23_RearGuideRail", AP["23_RearGuideRail"])]
for n, s in jobs:
    V, F = mesh(s)
    put(os.path.join(OUT, "assets", "pf2", n + ".stl"), V, F, n)                       # assembly frame
    if n == "01_Base_AP1":
        put(os.path.join(OUT, "pkg", "print_stl", "01_Base_AP1_PRINT.stl"), print_xf(V, ROT["print_stl/01_Base_AP1_PRINT.stl"]["R"], "center"), F, n)
    elif n == "01_Base_MW4":
        put(os.path.join(OUT, "models", "01_Base_MW4_PRINT.stl"), print_xf(V, ROT["models/01_Base_MW4_PRINT.stl"]["R"], "y0"), F, n)
        put(os.path.join(OUT, "pkg_mw4", "print_stl", "01_Base_MW4_PRINT.stl"), print_xf(V, ROT["mw4:print_stl/01_Base_MW4_PRINT.stl"]["R"], "center"), F, n)
    elif n == "23_RearGuideRail":
        put(os.path.join(OUT, "pkg", "print_stl", n + ".stl"), print_xf(V, FLIP, "center"), F, n)
    else:
        put(os.path.join(OUT, "pkg", "print_stl", n + ".stl"), print_xf(V, ROT["print_stl/%s.stl" % n]["R"], "center"), F, n)
