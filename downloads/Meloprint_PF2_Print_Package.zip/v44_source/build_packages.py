# -*- coding: utf-8 -*-
# Rebuild downloads/Meloprint_PF2_*_Print_Package.zip for v44 and the cad/*.json descriptors.
import zipfile, hashlib, json, os, io, re, shutil
W = r"C:\Users\Public\mbx_work"
SRC = W + r"\site"
DST = W + r"\site_v44"
A = W + r"\v44_assets"
O = W + r"\pf2_out"
sha = lambda b: hashlib.sha256(b).hexdigest()
rd = lambda p: open(p, "rb").read()

checks = {
    "v44_checks/motion-checks.json": rd(W + r"\val_v44.json"),
    "v44_checks/motion-checks-mw4.json": rd(W + r"\val_mw4.json"),
    "v44_checks/yoke-support.txt": rd(W + r"\sup_v44.txt"),
    "v44_checks/yoke-support-mw4.txt": rd(W + r"\sup_mw4.txt"),
    "v44_checks/assembly-path.txt": rd(W + r"\asm_v44.txt"),
    "v44_checks/assembly-path-mw4.txt": rd(W + r"\asm_mw4.txt"),
    "v44_checks/rhino7-verify.log": rd(W + r"\rh_verify_pf2.log"),
    "v44_checks/rhino7-build.log": rd(W + r"\rh_build_v44.log"),
    "v44_checks/rail-vs-covers.json": rd(W + r"\rail_cover_checks.json"),
    "v44_checks/native-export.json": rd(O + r"\export_report.json"),
    "v44_checks/print-orientation.json": rd(W + r"\print_rot.json"),
}
src_files = ["pf2_mods.py", "pf2_kin.py", "t_pf2_mods.py", "t_pf2_mw4.py", "t_pf2_validate.py", "t_pf2_support.py", "t_pf2_assembly.py",
             "t_rail_covers.py", "build_site_assets.py", "rh_verify_pf2.py", "rh_build_v44.py", "build_packages.py"]
sources = {"v44_source/" + f: rd(os.path.join(W, f)) for f in src_files}
readme = rd(W + r"\v44_doc\README_KO.md")

info = {}
for tag, zname, d3dm, base_name, base_print, steps in (
        ("current", "Meloprint_PF2_Print_Package.zip", "Meloprint_PF2_v44_Assembly.3dm", "01_Base_AP1", A + r"\pkg\print_stl\01_Base_AP1_PRINT.stl",
         {"01_Base_AP1": O + r"\STEP\01_Base_AP1.step"}),
        ("makerworld", "Meloprint_PF2_MW4_Print_Package.zip", "Meloprint_PF2_v44_MW4_Assembly.3dm", "01_Base_MW4", A + r"\pkg_mw4\print_stl\01_Base_MW4_PRINT.stl",
         {"01_Base_MW4": O + r"\STEP_MW4_01_Base_MW4.step"})):
    zin = zipfile.ZipFile(os.path.join(SRC, "downloads", zname))
    repl = {"print_stl/%s_PRINT.stl" % base_name: rd(base_print),
            "print_stl/04_Handle_AP1.stl": rd(A + r"\pkg\print_stl\04_Handle_AP1.stl"),
            "print_stl/05_Yoke_AP1.stl": rd(A + r"\pkg\print_stl\05_Yoke_AP1.stl"),
            "README_KO.md": readme}
    old3dm = [n for n in zin.namelist() if n.endswith(".3dm") and "/" not in n][0]
    oldstep = [n for n in zin.namelist() if n.endswith(".step") and "/" not in n][0]
    entries = []
    for i in zin.infolist():
        n = i.filename
        if n in (old3dm, oldstep):
            continue           # v43 sample CAD stays in the original v43 package (keeps the ZIP under 15 MB)
        elif n in ("README_KO.md", "3dm_checks.json"):
            entries.append(("history/v43/" + n, zin.read(n)))
            if n == "README_KO.md":
                entries.append((n, readme))
        elif n == "SHA256.json":
            continue
        elif n in repl:
            entries.append((n, repl[n]))
        else:
            entries.append((n, zin.read(n)))
    entries.append(("print_stl/23_RearGuideRail.stl", rd(A + r"\pkg\print_stl\23_RearGuideRail.stl")))
    b3 = rd(os.path.join(O, d3dm))
    entries.append((d3dm, b3))
    entries.append(("Meloprint_PF2_v44_Assembly.step" if tag == "current" else "Meloprint_PF2_v44_MW4_Parts_Changed.step",
                    rd(O + r"\STEP\Meloprint_PF2_v44_Assembly.step") if tag == "current" else rd(steps["01_Base_MW4"])))
    for k, p in steps.items():
        entries.append(("v44_native_parts/%s.step" % k, rd(p)))
    for k in ("04_Handle_AP1", "05_Yoke_AP1", "23_RearGuideRail"):
        entries.append(("v44_native_parts/%s.step" % k, rd(O + r"\STEP\%s.step" % k)))
    entries += sorted(checks.items()) + sorted(sources.items())
    faces = {"current": 2575, "makerworld": 2228}[tag]
    desc = {"file": "cad/" + d3dm, "filename": d3dm, "bytes": len(b3), "sha256": sha(b3), "parts": 16, "revision": "PF2",
            "fixedSample": True, "faces": faces, "assemblyRevision": "PF2-v44", "combStyle": tag, "rhinoArchiveVersion": 7}
    info[tag] = desc
    entries.append(("3dm_checks.json", json.dumps({tag: desc}, indent=2, ensure_ascii=False).encode("utf-8")))
    names = [n for n, _ in entries]
    assert len(names) == len(set(names)), [n for n in names if names.count(n) > 1]
    entries.append(("SHA256.json", json.dumps({n: sha(b) for n, b in entries}, indent=2).encode("utf-8")))
    out = os.path.join(DST, "downloads", zname)
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for n, b in entries:
            z.writestr(n, b)
    stl = [n for n in names if re.match(r"^print_stl/\d{2}_.*\.stl$", n) and not re.match(r"^print_stl/(02|15|16)_", n)]
    print(zname, "entries", len(entries), "bytes", os.path.getsize(out), "mechanism STLs", len(stl))
    json.dump(desc, open(os.path.join(DST, "cad", "pf2-surface.json" if tag == "current" else "pf2-surface-mw4.json"), "w"), indent=2)
print(json.dumps(info, indent=1))
