﻿# -*- coding: utf-8 -*-
# Structural fixes for the PF2 v43 assembly (exterior unchanged). OCC B-rep, Rhino not required.
import sys, math, os
sys.path.insert(0, r"C:\Users\Public\mbx_work")
from ap1_tool import box, cyl, cut, fuse, rotated, n_solids, valid
from ap1_mods import common, prism_xy, revolve_rz
from occ_conv import volume

MAIN_C = (0.0, -23.218)
HANDLE_C = (0.0, -80.544)

# ---- rear lower guide rail (new part 23)
RAIL_Y = (-70.90, -67.75)
RAIL_TOP = 9.85            # same height as the existing front rail
RAIL_T = 3.0
LEG_X = (27.0, 43.25)
FLOOR_Z = 1.6              # raised floor beside the handle-gear recess
PIN_X = 36.0
PIN_R = 1.2
PIN_LEN = 2.0
HOLE_R = 1.35
HOLE_D = 2.3


def rear_rail():
    y0, y1 = RAIL_Y
    bar = box(-43.30, y0, RAIL_TOP - RAIL_T, 43.30, y1, RAIL_TOP)
    parts = [bar]
    for sx in (-1, 1):
        a, b = sorted((sx * LEG_X[0], sx * LEG_X[1]))
        parts.append(box(a, y0, FLOOR_Z, b, y1, RAIL_TOP - RAIL_T + 0.01))
        parts.append(cyl(sx * PIN_X, (y0 + y1) / 2.0, PIN_R, FLOOR_Z - PIN_LEN, FLOOR_Z + 0.01))
    return fuse(*parts)


def base_pin_holes(B):
    yc = sum(RAIL_Y) / 2.0
    return cut(B, *[cyl(sx * PIN_X, yc, HOLE_R, FLOOR_Z - HOLE_D, FLOOR_Z + 0.5) for sx in (-1, 1)])


# ---- main gear: self-supporting crank ring (45 deg cone) + neck fill
def printable_main_gear(G):
    cx, cy = MAIN_C
    neck = cut(cyl(cx, cy, 35.50, 1.19, 1.61), cyl(cx, cy, 32.0, 1.0, 1.8))
    G2 = fuse(G, neck)
    cutter = revolve_rz([(35.56, 1.25), (35.56, 1.6), (42.0, 8.04), (43.0, 8.04), (43.0, 1.25)], cx, cy)
    return cut(G2, cutter)


# ---- handle gear: tooth tops -0.4 (clearance to the cone) + flank thinning (backlash)
def tune_handle(H, trim_tops=False):
    cx, cy = HANDLE_C
    if trim_tops:
        trim = cut(cyl(cx, cy, 30.0, 0.8, 1.25), cyl(cx, cy, 7.05, 0.7, 1.3))
        H = cut(H, trim)
    ring = cut(cyl(cx, cy, 26.0, -3.0, 1.5), cyl(cx, cy, 20.0, -4.0, 2.0))
    teeth = common(H, ring)
    d = math.degrees(0.0025)
    thin = common(common(teeth, rotated(teeth, d, (cx, cy, 0))), rotated(teeth, -d, (cx, cy, 0)))
    return fuse(cut(H, ring), thin)


# ---- yoke: roller slot 0.25 -> 0.15 per side
def tune_yoke(Y, slot_half=3.75, y_range=(-63.0, 16.0)):
    plates = [box(slot_half - 0.101, y_range[0], 7.55, slot_half + 0.01, y_range[1], 10.95),
              box(-slot_half - 0.01, y_range[0], 7.55, -slot_half + 0.101, y_range[1], 10.95)]
    return fuse(Y, *plates)


def apply_all(S):
    out = dict(S)
    out["01_Base_AP1"] = base_pin_holes(S["01_Base_AP1"])
    # 03 stays as designed: the 45 deg cone shrank the ring (R40.5 -> 39.46) and thinned the crank-pin root,
    # so the ring keeps its shape and prints with build-plate supports instead.
    out["04_Handle_AP1"] = tune_handle(S["04_Handle_AP1"])
    out["05_Yoke_AP1"] = tune_yoke(S["05_Yoke_AP1"])
    out["23_RearGuideRail"] = rear_rail()
    return out

