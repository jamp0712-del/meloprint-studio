# -*- coding: utf-8 -*-
# PF2 v43 kinematics (manifold meshes) and yoke support / pitch analysis.
import sys, math, json
sys.path.insert(0, r"C:\Users\Public\mbx_work")
from ap1_view import load_cache
from mf_tool import to_manifold, inter_vol, xf_translate, xf_rotate, compose

MAIN_C = (0.0, -23.218)
HANDLE_C = (0.0, -80.544)
ECC = 36.064
RATIO = 1.5


def part_xf(n, th):
    t = math.radians(th)
    k = n[:2]
    if k == "03":
        return xf_rotate(-th, (MAIN_C[0], MAIN_C[1], 0), (0, 0, 1))
    if k in ("04", "11") or n.startswith("04"):
        return xf_rotate(th * RATIO, (HANDLE_C[0], HANDLE_C[1], 0), (0, 0, 1))
    if k in ("06", "12"):
        px, py = ECC * math.sin(t), MAIN_C[1] + ECC * math.cos(t)
        return xf_translate(px, py - (MAIN_C[1] + ECC), 0)
    if k == "05":
        return xf_translate(ECC * math.sin(t), 0, 0)
    return None


def load(src):
    S = load_cache(src)
    return {n: to_manifold(s) for n, s in S.items()}


def posed(M, th, extra=None):
    P = {}
    for n, m in M.items():
        xf = part_xf(n, th)
        P[n] = m.transform(xf) if xf is not None else m
        if extra and n in extra:
            P[n] = P[n].transform(extra[n])
    return P


def first_contact(P, mover, others, dvec, maxd=5.0):
    lo, hi = 0.0, maxd
    def hit(d):
        m = P[mover].translate((dvec[0] * d, dvec[1] * d, dvec[2] * d))
        for o in others:
            v, _ = inter_vol(m, P[o])
            if v > 1e-4:
                return o
        return None
    if hit(maxd) is None:
        return None, maxd
    for _ in range(26):
        mid = (lo + hi) / 2
        if hit(mid):
            hi = mid
        else:
            lo = mid
    return hit(hi), round(lo, 3)


def pitch_free(P, yoke, others, pivot_y, pivot_z, sign, maxa=5.0):
    """Rotate yoke about an X-parallel axis through (y,z) until first contact."""
    lo, hi = 0.0, maxa
    def hit(a):
        m = P[yoke].transform(xf_rotate(sign * a, (0, pivot_y, pivot_z), (1, 0, 0)))
        hits = []
        for o in others:
            v, bb = inter_vol(m, P[o])
            if v > 1e-4:
                hits.append((o, [round(c, 1) for c in bb]))
        return hits
    if not hit(maxa):
        return None, maxa
    for _ in range(24):
        mid = (lo + hi) / 2
        if hit(mid):
            hi = mid
        else:
            lo = mid
    return hit(hi), round(lo, 3)
