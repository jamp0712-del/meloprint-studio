# Rail 23 (and the yoke in its lowest/highest positions) against every downloadable cover, in assembly coordinates.
import os, json
import numpy as np, trimesh, manifold3d as m3
S = r"C:\Users\Public\mbx_work\site_v44"
LB = {"base": (0.030805587768554688, -30.558719635009766, 20.73442268371582)}
for k in ("chrome", "acid", "pink", "ice", "orange", "purple"):
    LB[k] = (0.030805587768554688, -30.558719635009766, 21.134403228759766)


def mf(V, F):
    return m3.Manifold(m3.Mesh(vert_properties=np.asarray(V, np.float32), tri_verts=np.asarray(F, np.uint32)))


def load(p, xf=None):
    t = trimesh.load(p)
    t.merge_vertices()
    V = t.vertices.copy()
    F = t.faces.copy()
    if xf:
        cx, cy, z = xf
        V = np.c_[V[:, 0] + cx, cy - V[:, 1], z - V[:, 2]]
        F = F[:, ::-1]           # mirror (y,z both flipped = rotation, keeps handedness) -> actually det=+1
        F = F[:, ::-1]
    return t, mf(V, F), V


rail_t, rail, _ = load(os.path.join(S, "assets/pf2/23_RearGuideRail.stl"))
yoke_t, yoke, _ = load(os.path.join(S, "assets/pf2/05_Yoke_AP1.stl"))
res = {}
for pre in ("", "mw4_"):
    for k, xf in LB.items():
        p = os.path.join(S, "models", "%s02_Cover_PF2_%s_PRINT.stl" % (pre, k))
        t, c, V = load(p, xf)
        iv = (rail ^ c).volume()
        gap = rail.min_gap(c, 5.0)
        ys = []
        for dx in (-36.064, 0.0, 36.064):
            y2 = yoke.translate((dx, 0, -0.248))
            ys.append(round((y2 ^ c).volume(), 4))
        res[pre + k] = {"rail_overlap_mm3": round(iv, 4), "rail_min_gap_mm": round(gap, 3), "yoke_overlap_mm3_at_left_mid_right": ys,
                        "cover_status": str(c.status())}
        print("%-14s rail overlap %.4f  gap %.3f   yoke overlap %s  (%s)" % (pre + k, iv, gap, ys, c.status()))
json.dump(res, open(r"C:\Users\Public\mbx_work\rail_cover_checks.json", "w"), indent=1)
