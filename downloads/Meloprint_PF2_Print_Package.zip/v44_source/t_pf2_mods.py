import sys, os, time
sys.path.insert(0, r"C:\Users\Public\mbx_work")
from ap1_view import load_cache
import pf2_mods as PM
from ap1_tool import n_solids, valid
from occ_conv import volume
from OCP.BRepTools import BRepTools
S = load_cache(r"C:\Users\Public\mbx_work\in\pf2_brep")
t = time.time()
PM.tune_yoke.__defaults__ = (3.75, (-63.85, 17.4))
M = PM.apply_all(S)
print("mods %.1fs" % (time.time() - t))
out = r"C:\Users\Public\mbx_work\in\pf2mod_brep"
os.makedirs(out, exist_ok=True)
for f in os.listdir(out):
    os.remove(os.path.join(out, f))
for n in sorted(M):
    s = M[n]
    v0 = volume(S[n]) if n in S else None
    print("%-24s solids=%d valid=%s vol=%.2f%s" % (n, n_solids(s), valid(s), volume(s), "" if v0 is None else " (d=%.2f)" % (volume(s) - v0)))
    BRepTools.Write_s(s, os.path.join(out, n + ".brep"))
