﻿# -*- coding: utf-8 -*-
import sys, json
sys.path.insert(0, r"C:\Users\Public\mbx_work")
from pf2_kin import load, posed
from mf_tool import inter_vol, xf_rotate

src = sys.argv[1]
ML = load(src)
M = posed(ML, 90)            # arrow parked at one end (as the site instructs for comb insertion)
MC = posed(ML, 0)            # arrow centred for the cover (v41 guide step 4)
LOCK_C = {"19_CaseLock_AP1": (-40, -119), "20_CaseLock_AP1": (40, -119), "21_CaseLock_AP1": (-40, 58.8), "22_CaseLock_AP1": (40, 58.8)}
seq = [("04_Handle_AP1", (0, 0, 40))]
if any(n.startswith("23") for n in M):
    seq.append(("23_RearGuideRail", (0, 0, 30)))
seq += [("03_MainGear_AP1", (0, 0, 35)), ("10_MainRetainer_AP1", (0, 0, 15)), ("06_CrankRoller_AP1", (0, 0, 20)),
        ("12_RollerRetainer_AP1", (0, 0, 15)), ("05_Yoke_AP1", (0, 0, 35)), ("02_Cover_AP1", (0, 0, 35)), ("LOCKS", (0, 0, 25)),
        ("11_HandleRetainer_AP1", (0, 0, 30)), ("COMBS", None)]


def hits(movers, installed, vec, steps=30):
    out = []
    for k in range(steps + 1):
        t = 1.0 - k / float(steps)
        for mn, mm in movers.items():
            m2 = mm.translate((vec[0] * t, vec[1] * t, vec[2] * t))
            for n, o in installed.items():
                v, bb = inter_vol(m2, o)
                if v > 0.01:
                    out.append((round(t, 3), mn, n, round(v, 3), [round(c, 1) for c in bb]))
    return out


inst = {"01_Base_AP1": M["01_Base_AP1"]}
for name, vec in seq:
    if name == "LOCKS":
        for ang in (0, 90):
            mv = {n: M[n].transform(xf_rotate(ang, (LOCK_C[n][0], LOCK_C[n][1], 0), (0, 0, 1))) for n in LOCK_C}
            print("case locks inserted at %d deg: collisions %d" % (ang, len(hits(mv, inst, vec))))
        inst.update({n: M[n] for n in LOCK_C})
        continue
    if name == "COMBS":
        mv = {n: M[n] for n in M if n[:2] in ("15", "16")}
        for lab, v in (("-Z (from above)", (0, 0, 30)), ("-Y (from the comb end)", (0, 45, 0))):
            h = hits(mv, inst, v)
            print("combs %-24s collisions %3d  %s" % (lab, len(h), h[:3]))
        continue
    if name == "02_Cover_AP1":
        instc = dict(inst); instc["05_Yoke_AP1"] = MC["05_Yoke_AP1"]; instc["06_CrankRoller_AP1"] = MC["06_CrankRoller_AP1"]; instc["03_MainGear_AP1"] = MC["03_MainGear_AP1"]; instc["12_RollerRetainer_AP1"] = MC["12_RollerRetainer_AP1"]; instc["04_Handle_AP1"] = MC["04_Handle_AP1"]
        h = hits({name: M[name]}, instc, vec)
        print("%-22s collisions %3d (arrow centred)  %s" % (name, len(h), h[:2])); inst[name] = M[name]; continue
    h = hits({name: M[name]}, inst, vec)
    print("%-22s collisions %3d  %s" % (name, len(h), h[:2]))
    inst[name] = M[name]

