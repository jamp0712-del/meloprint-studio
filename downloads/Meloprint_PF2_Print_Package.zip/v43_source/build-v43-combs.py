import cadquery as cq,json
from pathlib import Path
D=Path('model-source/pf2/v43');V=cq.Vector;checks=[]
def prism(points,z,h):return cq.Solid.extrudeLinear(cq.Wire.makePolygon([V(x,y,z) for x,y in points],close=True),[],V(0,0,h))
for style in ['current','makerworld']:
 data=json.loads((D/(style+'.json')).read_text());mw=style=='makerworld';tip=data['design']['tipY']
 for row,r in data['rows'].items():
  body=prism(r['profile']['outline'],-1.3 if mw else 0,4.5 if mw else 3.2)
  if mw:
   yz=[(tip,1.7),(tip+3,-1.3),(58.5,-1.3),(59.584,0),(100,0),(100,4),(tip,4)];wedge=cq.Solid.extrudeLinear(cq.Wire.makePolygon([V(-50,y,z) for y,z in yz],close=True),[],V(100,0,0));body=body.intersect(wedge)
  body=body.fuse(prism(r['profile']['header'],3.19,.41))
  for x in [-26.84919491968,26.91080508032]:body=body.fuse(cq.Solid.makeCylinder(2.4,1.61,V(x,70.56,3.59))) if row=='lower' else body.cut(cq.Solid.makeCylinder(2.55,1.82,V(x,70.56,1.8)))
  body=body.mirror('XY').translate((0,0,r['z']+3.2)) if row=='upper' else body.translate((0,0,r['z']));body=body.clean();assert body.isValid() and len(body.Solids())==1;key=('15_CombLower_' if row=='lower' else '16_CombUpper_')+('MW4' if mw else 'AP1')
  for ext in ['brep','step','stl']:cq.exporters.export(body,str(D/(key+'.'+ext)),tolerance=.003,angularTolerance=.04)
  checks.append(dict(part=key,valid=True,solids=1,faces=len(body.Faces()),volume=body.Volume()));print(checks[-1],flush=True)
(D/'comb-checks.json').write_text(json.dumps(checks,indent=2))
