import cadquery as cq,json
from pathlib import Path
D=Path('model-source/pf2/v43');V=cq.Vector;c=.03080508032
box=lambda a,b,y0,y1,z0,z1:cq.Solid.makeBox(b-a,y1-y0,z1-z0,V(c+a,y0,z0))
def sides(a,b,y0,y1,z0,z1):return box(a,b,y0,y1,z0,z1).fuse(box(-b,-a,y0,y1,z0,z1))
base=cq.importers.importBrep('model-source/pf2/v41/01_Base_AP1.brep').val();cover=cq.importers.importBrep('model-source/pf2/v42/02_Cover_AP1.brep').val()
zone=sides(34.35,37.4,49,64.80430265232,-.17,20.73442238);rails={'base':sides(34.35,37.4,49,64.80430265232,-.17,8.32159),'cover':sides(34.35,37.4,49,64.80430265232,8.52159,20.73442238)};checks=[]
for mw,z0,z1 in [(False,4.521595,12.121596),(True,3.221595,13.421596)]:
 for name,s in [('base',base),('cover',cover)]:
  n=s.cut(zone).fuse(rails[name])
  if name=='base':n=n.fuse(sides(34.35,44.5,49,55,-.17,1))
  n=n.cut(box(-34.35,34.35,26.184,66,z0,z1)).cut(sides(34.34,35,49.6,52.25,z0,z1))
  for x in [-40,40]:
   hole=cq.Solid.makeCylinder(2.4,11,V(x,58.8,10.35)).fuse(cq.Solid.makeBox(7.6,2.1,10,V(x-3.8,57.75,11.95))).fuse(cq.Solid.makeCylinder(3.85,1.7,V(x,58.8,10.4))).fuse(cq.Solid.makeCylinder(3.7,2,V(x,58.8,19.45)));n=n.cut(hole)
  pieces=sorted(n.clean().Solids(),key=lambda s:s.Volume(),reverse=True)
  for q in pieces[1:]:assert q.Volume()<100 and q.BoundingBox().ymin>49 and q.BoundingBox().zmin>12
  n=pieces[0];assert n.isValid() and len(n.Solids())==1;key=('01_Base_' if name=='base' else '02_Cover_')+('MW4' if mw else 'AP1')
  for ext in ['brep','step','stl']:cq.exporters.export(n,str(D/(key+'.'+ext)),tolerance=.003,angularTolerance=.04)
  if name=='cover':
   for label,delta in [('add',n.cut(s)),('cut',s.cut(n))]:cq.exporters.export(delta,str(D/('case-'+('mw-' if mw else '')+label+'.stl')),tolerance=.003,angularTolerance=.04)
  b=n.BoundingBox();ob=s.BoundingBox();checks.append(dict(part=key,valid=True,solids=1,faces=len(n.Faces()),volume=n.Volume(),discardedOldGuideFragments=[q.Volume() for q in pieces[1:]],bounds=[b.xmin,b.xmax,b.ymin,b.ymax,b.zmin,b.zmax],previousBounds=[ob.xmin,ob.xmax,ob.ymin,ob.ymax,ob.zmin,ob.zmax]));print(checks[-1],flush=True)
(D/'case-checks.json').write_text(json.dumps(checks,indent=2))
