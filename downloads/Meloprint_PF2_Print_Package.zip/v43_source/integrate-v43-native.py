import rhino3dm as r,json,hashlib,cadquery as cq
from pathlib import Path
D=Path('model-source/pf2/v43');cad=Path('dist/cad');old=(cad/'Meloprint_PF2_Assembly.3dm').read_bytes();repl={o.Attributes.Name:o.Geometry for o in r.File3dm.Read(str(D/'replacements.3dm')).Objects};reports={}
def keymap(key,mw):
 if key.startswith('15_'):key='15_CombLower_AP1'
 if key.startswith('16_'):key='16_CombUpper_AP1'
 return key.replace('_AP1','_MW4') if mw and key in ['01_Base_AP1','02_Cover_AP1','15_CombLower_AP1','16_CombUpper_AP1'] else key
for mw in [False,True]:
 m=r.File3dm.FromByteArray(old)
 for o in list(m.Objects):
  key=keymap(o.Attributes.Name,mw)
  if key in repl:
   at=r.ObjectAttributes();at.Name=key;at.LayerIndex=o.Attributes.LayerIndex;at.ObjectColor=o.Attributes.ObjectColor;at.ColorSource=o.Attributes.ColorSource;at.WireDensity=-1;at.SetUserString('Revision','PF2-v43');m.Objects.Delete(o.Attributes.Id);m.Objects.AddBrep(repl[key],at)
 assert len(m.Objects)==15
 for o in m.Objects:assert isinstance(o.Geometry,r.Brep) and o.Geometry.IsValid and o.Geometry.IsSolid,o.Attributes.Name
 name='Meloprint_PF2_MW4_Assembly.3dm' if mw else 'Meloprint_PF2_Assembly.3dm';m.Write(str(cad/name),8);b=(cad/name).read_bytes();info=dict(file='cad/'+name,filename=name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),parts=15,revision='PF2',fixedSample=True,faces=sum(len(o.Geometry.Faces) for o in m.Objects),assemblyRevision='PF2-v43',combStyle='makerworld' if mw else 'current');(cad/('pf2-surface-mw4.json' if mw else 'pf2-surface.json')).write_text(json.dumps(info,indent=2));reports[info['combStyle']]=info;print(info,flush=True)
 order=list(json.loads(Path('model-source/pf2/design.json').read_text())['parts']);original=cq.importers.importStep('model-source/pf2/v42/Meloprint_PF2_v42_Assembly.step').solids().vals();assert len(original)==len(order)==15;solids=[]
 for key,body in zip(order,original):
  f=D/(keymap(key,mw)+'.brep');solids.append(cq.importers.importBrep(str(f)).val() if f.exists() else body)
 cq.exporters.export(cq.Compound.makeCompound(solids),str(D/('Assembly_MW4.step' if mw else 'Assembly.step')))
(D/'native-checks.json').write_text(json.dumps(reports,indent=2))
