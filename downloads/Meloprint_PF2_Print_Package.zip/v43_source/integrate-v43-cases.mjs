import fs from 'node:fs';import assert from 'node:assert/strict';import {read} from '../tests/v41-mesh-utils.mjs';import {COVER_MODELS} from '../src/cover-models.js';import {stlBytes} from '../src/model.js';
const D='model-source/pf2/v43/';
function mesh(s,t=p=>p){const m=s.getMesh(),vertices=[],faces=[];for(let i=0;i<m.vertProperties.length;i+=m.numProp)vertices.push(t(Array.from(m.vertProperties.slice(i,i+3))));for(let i=0;i<m.triVerts.length;i+=3)faces.push(Array.from(m.triVerts.slice(i,i+3)));return {vertices,faces};}
fs.mkdirSync('../pf2-cover-work',{recursive:true});
for(const [key,c]of Object.entries(COVER_MODELS)){
 const old=read('dist/'+c.file,p=>[p[0]+c.cx,c.cy-p[1],c.z-p[2]]);
 for(const mw of[false,true]){
  // Both use the SAME original AP1 cover; native deltas include exact lock pockets.
  const pre='case-'+(mw?'mw-':''),s=old.add(read(D+pre+'add.stl')).subtract(read(D+pre+'cut.stl')).simplify(.0001);assert.equal(s.status(),'NoError');const pcs=s.decompose().sort((a,b)=>b.volume()-a.volume());assert(pcs.slice(1).every(x=>Math.abs(x.volume())<.003));const b=pcs[0].simplify(.0001),name=mw?'models/mw4_'+c.file.split('/').pop():c.file;
  fs.writeFileSync('dist/'+name,stlBytes(mesh(b,p=>[p[0]-c.cx,c.cy-p[1],c.z-p[2]])));
  if(!mw){c.faces=b.numTri();c.volume=b.volume();fs.writeFileSync('../pf2-cover-work/'+key+'.json',JSON.stringify({...mesh(b),color:c.color}));}console.log(name,b.numTri(),b.volume());
 }
}
for(const key of ['01_Base_AP1','01_Base_MW4','02_Cover_AP1'])fs.copyFileSync(D+key+'.stl','dist/assets/pf2/'+key+'.stl');
fs.writeFileSync('dist/models/01_Base_MW4_PRINT.stl',stlBytes(mesh(read(D+'01_Base_MW4.stl')),true));
fs.writeFileSync('src/cover-models.js','export const COVER_MODELS='+JSON.stringify(COVER_MODELS)+';\n');
