import cadquery as cq,sys,math
from OCP.BRep import BRep_Tool
from OCP.BRepTools import BRepTools,BRepTools_WireExplorer
from OCP.BRepBuilderAPI import BRepBuilderAPI_NurbsConvert
from OCP.TopExp import TopExp,TopExp_Explorer
from OCP.TopTools import TopTools_IndexedMapOfShape
from OCP.TopAbs import TopAbs_VERTEX,TopAbs_EDGE,TopAbs_FACE,TopAbs_WIRE,TopAbs_REVERSED,TopAbs_FORWARD
from OCP.TopoDS import TopoDS
from OCP.GeomConvert import GeomConvert
from OCP.Geom2dConvert import Geom2dConvert
from OCP.Geom import Geom_TrimmedCurve
from OCP.Geom2d import Geom2d_TrimmedCurve
from OCP.gp import gp_Pnt
out=open(sys.argv[1],'w')
def write(*v):out.write(' '.join(str(x) for x in v)+'\n')
def ncurve(c,dim):
 if c.IsPeriodic():c.SetNotPeriodic()
 n=c.NbPoles();deg=c.Degree();ks=[]
 for i in range(1,c.NbKnots()+1):ks += [c.Knot(i)]*c.Multiplicity(i)
 ks=ks[1:-1];write(dim,deg,n,len(ks));write(*ks)
 for i in range(1,n+1):p=c.Pole(i);w=c.Weight(i);write(p.X()*w,p.Y()*w,p.Z()*w if dim==3 else 0,w)
def nsurface(s):
 if s.IsUPeriodic():s.SetUNotPeriodic()
 if s.IsVPeriodic():s.SetVNotPeriodic()
 ku=[];kv=[]
 for i in range(1,s.NbUKnots()+1):ku += [s.UKnot(i)]*s.UMultiplicity(i)
 for i in range(1,s.NbVKnots()+1):kv += [s.VKnot(i)]*s.VMultiplicity(i)
 ku=ku[1:-1];kv=kv[1:-1];write(s.UDegree(),s.VDegree(),s.NbUPoles(),s.NbVPoles(),len(ku),len(kv));write(*ku);write(*kv)
 for i in range(1,s.NbUPoles()+1):
  for j in range(1,s.NbVPoles()+1):p=s.Pole(i,j);w=s.Weight(i,j);write(p.X()*w,p.Y()*w,p.Z()*w,w)
def mapping(s,t):
 m=TopTools_IndexedMapOfShape();TopExp.MapShapes_s(s,t,m);return m
write(len(sys.argv)-2)
for num in sys.argv[2:]:
 s=cq.importers.importStep('model-source/pf2/v43/'+num+'.step').val().wrapped;s=BRepBuilderAPI_NurbsConvert(s,True).Shape();vs=mapping(s,TopAbs_VERTEX);es=mapping(s,TopAbs_EDGE);fs=mapping(s,TopAbs_FACE)
 write(num);write(vs.Extent())
 for i in range(1,vs.Extent()+1):p=BRep_Tool.Pnt_s(TopoDS.Vertex_s(vs.FindKey(i)));write(p.X(),p.Y(),p.Z())
 write(es.Extent());ends=[]
 for i in range(1,es.Extent()+1):
  e=TopoDS.Edge_s(es.FindKey(i).Oriented(TopAbs_FORWARD));v0=TopExp.FirstVertex_s(e);v1=TopExp.LastVertex_s(e);a=vs.FindIndex(v0)-1;b=vs.FindIndex(v1)-1;ends.append((BRep_Tool.Pnt_s(v0),BRep_Tool.Pnt_s(v1)));degen=BRep_Tool.Degenerated_s(e);write(int(degen),a,b)
  if not degen:
   lo,hi=BRep_Tool.Range_s(e);c=BRep_Tool.Curve_s(e,0.,0.).Copy();c=GeomConvert.CurveToBSplineCurve_s(Geom_TrimmedCurve(c,lo,hi));ncurve(c,3)
 write(fs.Extent())
 for i in range(1,fs.Extent()+1):
  face=TopoDS.Face_s(fs.FindKey(i));rev=face.Orientation()==TopAbs_REVERSED;f=TopoDS.Face_s(face.Oriented(TopAbs_FORWARD));surf=BRep_Tool.Surface_s(f).Copy();write(int(rev));nsurface(surf);wires=[];ex=TopExp_Explorer(f,TopAbs_WIRE);outer=BRepTools.OuterWire_s(f)
  while ex.More():wires.append(TopoDS.Wire_s(ex.Current()));ex.Next()
  write(len(wires))
  for w in wires:
   trims=[];we=BRepTools_WireExplorer(w,f)
   while we.More():
    e=we.Current();ei=es.FindIndex(e)-1;r=e.Orientation()==TopAbs_REVERSED;lo,hi=BRep_Tool.Range_s(e,f);pc=BRep_Tool.CurveOnSurface_s(e,f,0.,0.).Copy()
    if lo<pc.FirstParameter()-1e-7 or hi>pc.LastParameter()+1e-7:lo=pc.FirstParameter();hi=pc.LastParameter()
    pc=Geom2dConvert.CurveToBSplineCurve_s(Geom2d_TrimmedCurve(pc,lo,hi))
    a,b=ends[ei];q=pc.Value(pc.FirstParameter());p0=surf.Value(q.X(),q.Y());q=pc.Value(pc.LastParameter());p1=surf.Value(q.X(),q.Y())
    if p0.Distance(a)+p1.Distance(b)>p0.Distance(b)+p1.Distance(a):pc.Reverse();p0,p1=p1,p0
    assert max(p0.Distance(a),p1.Distance(b))<.01,(num,i,ei,'pcurve endpoint mismatch')
    if r:pc.Reverse()
    trims.append((ei,r,pc));we.Next()
   write(int(w.IsSame(outer)),len(trims))
   for ei,r,pc in trims:write(ei,int(r));ncurve(pc,2)
 print(num,fs.Extent(),'faces',flush=True)
