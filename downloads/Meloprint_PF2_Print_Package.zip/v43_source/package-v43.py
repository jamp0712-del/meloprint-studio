import zipfile,json,hashlib,cadquery as cq
from pathlib import Path
D=Path('model-source/pf2/v43');dest=Path('dist/downloads');src=dest/'Meloprint_PF2_Print_Package.zip'
with zipfile.ZipFile(src) as z:original={n:z.read(n) for n in z.namelist() if n!='SHA256.json'}
guide='''# PF2 v43 잠금형 빗

외형 크기와 15개 부품 수를 유지했습니다. **01 베이스·02 상판·15/16 빗을 함께 교체**하세요. 이전 몸체와 혼용하지 마세요. 일반형과 MW4형의 베이스·상판을 구분하세요.

1. 화살표를 좌우 이동 끝으로 옮깁니다.
2. 위·아래 빗의 정렬 핀을 맞춥니다.
3. 두 판을 함께 제품 위쪽 입구에서 아래 방향(-Y)으로 끝까지 삽입합니다. 어깨가 닿고 양쪽 걸쇠가 턱에 걸리는지 확인합니다.
4. 분리는 상판을 열고 양쪽 걸쇠를 안쪽으로 누른 후 위로 빼냅니다. 힘으로 잡아당기지 마세요.

걸쇠는 빗과 일체형입니다. 명목 위쪽 이동 여유 0.05mm, 좌우 걸림 깊이 각 0.5mm입니다. 출력 오차에 따른 유격과 삽입력은 실물로 확인해야 합니다. 실물 마찰·삽입력·반복 내구성·음질 시험은 미실시입니다. 검사에서 사용한 0.8mm 탄성 변위는 가정값이며 FEA 결과가 아닙니다.

3DM/STEP은 기본 상판·물림 0.35mm의 고정 샘플입니다. 현재형은 생일축하, MW4는 제공한 33음입니다. 3DM은 15개의 닫힌 native BREP 솔리드입니다. 사용자 멜로디는 사이트 생성기를 이용하세요. Rhino 실제 화면과 실제 브라우저 QA는 미검증입니다.

기존 구동부의 조립 순서는 아래 기어 → 상판 → 위 손잡이입니다. 화살표와 구동부 부품은 이번 수정에서 유지했습니다. 작은 걸쇠는 출력 누락이나 층간 갈라짐이 없는지 확인한 뒤 조립하세요. 상판을 닫고 작동합니다.

검사 결과는 v43_checks/에 있습니다. history/ 자료는 과거 설계 기록이므로 출력용으로 사용하지 마세요.
'''
for mw in [False,True]:
 files={}
 for n,b in original.items():
  if n.startswith('print_stl/') or n.startswith('coupons/'):files[n]=b
  elif not n.startswith('history/') and not n.endswith('.3dm') and not n.endswith('Assembly.step') and not n.startswith('v43_'):files['history/'+n]=b
  elif n.startswith('history/'):files[n]=b
 suffix='MW4' if mw else 'AP1'
 for prefix,stem in [('01','Base'),('02','Cover'),('15','CombLower'),('16','CombUpper')]:
  key=prefix+'_'+stem+'_'+suffix;s=cq.importers.importBrep(str(D/(key+'.brep'))).val()
  if prefix in ['02','16']:s=s.rotate((0,0,0),(1,0,0),180)
  b=s.BoundingBox();s=s.translate((-(b.xmin+b.xmax)/2,-(b.ymin+b.ymax)/2,-b.zmin));p=D/(key+'_PRINT.stl');cq.exporters.export(s,str(p),tolerance=.003,angularTolerance=.04)
  for n in list(files):
   if n.startswith('print_stl/'+prefix+'_') and n.endswith('.stl'):del files[n]
  files['print_stl/'+key+'_PRINT.stl']=p.read_bytes();files['v43_native_parts/'+key+'.step']=(D/(key+'.step')).read_bytes()
 name='Meloprint_PF2_MW4_Assembly.3dm' if mw else 'Meloprint_PF2_Assembly.3dm';files[name]=(Path('dist/cad')/name).read_bytes();files['Meloprint_PF2_Assembly.step']=(D/('Assembly_MW4.step' if mw else 'Assembly.step')).read_bytes();files['README_KO.md']=guide.encode()
 for p in D.glob('*checks.json'):files['v43_checks/'+p.name]=p.read_bytes()
 for p in Path('scripts').glob('*v43*'):files['v43_source/'+p.name]=p.read_bytes()
 files['3dm_checks.json']=(D/'native-checks.json').read_bytes();files['SHA256.json']=json.dumps({n:hashlib.sha256(b).hexdigest() for n,b in files.items()},indent=2).encode();out=dest/('Meloprint_PF2_MW4_Print_Package.zip' if mw else 'Meloprint_PF2_Print_Package.zip')
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for n,b in files.items():z.writestr(n,b)
 print(out,out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest(),flush=True)
(D/'README_KO.md').write_text(guide)
