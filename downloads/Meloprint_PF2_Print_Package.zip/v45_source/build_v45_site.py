# -*- coding: utf-8 -*-
# Build site_v45 (M3 screws) from site_v44: assets, covers, packages, CAD descriptors, code and text patches.
import os, re, shutil, zipfile, hashlib, json
W = r"C:\Users\Public\mbx_work"
S44, D = W + r"\site_v44", W + r"\site_v45"
A = W + r"\v45_assets"
O = W + r"\pf2_out"
sha = lambda b: hashlib.sha256(b).hexdigest()
rd = lambda p: open(p, "rb").read()
shutil.rmtree(D, ignore_errors=True)
shutil.copytree(S44, D)
# --- assets
for n in ("01_Base_AP1", "01_Base_MW4", "02_Cover_AP1", "M3_Hardware"):
    shutil.copy2(os.path.join(A, "assets", "pf2", n + ".stl"), os.path.join(D, "assets", "pf2"))
for n in ("19", "20", "21", "22"):
    os.remove(os.path.join(D, "assets", "pf2", "%s_CaseLock_AP1.stl" % n))
for f in os.listdir(os.path.join(A, "models")):
    shutil.copy2(os.path.join(A, "models", f), os.path.join(D, "models", f))
for f in os.listdir(os.path.join(D, "cad")):
    if f.endswith(".3dm"):
        os.remove(os.path.join(D, "cad", f))
for f in ("Meloprint_PF2_v45_M3_Assembly.3dm", "Meloprint_PF2_v45_M3_MW4_Assembly.3dm"):
    shutil.copy2(os.path.join(O, f), os.path.join(D, "cad", f))
# --- packages
checks = {"v45_checks/m3-hardware-walls-path.json": rd(W + r"\m3_checks.json"), "v45_checks/m3-hardware-walls-path-mw4.json": rd(W + r"\m3_checks_mw4.json"),
          "v45_checks/m3-cover-meshes.json": rd(W + r"\m3_cover_mesh_checks.json"), "v45_checks/motion-checks.json": rd(W + r"\val_m3.json"),
          "v45_checks/motion-checks-mw4.json": rd(W + r"\val_m3_mw4.json"), "v45_checks/yoke-support.txt": rd(W + r"\sup_m3.txt"),
          "v45_checks/rhino7-cover-boolean.log": rd(W + r"\rh_m3_cover.log"), "v45_checks/rhino7-build.log": rd(W + r"\rh_build_v45.log"),
          "v45_checks/rhino7-hardware.log": rd(W + r"\rh_check_v45hw.log"), "v45_checks/export.json": rd(A + r"\export_m3.json")}
sources = {"v45_source/" + f: rd(os.path.join(W, f)) for f in ("m3_mods.py", "t_m3_build.py", "rh_m3_cover.py", "t_m3_covers.py", "t_m3_validate.py",
                                                                "t_m3_combs.py", "build_m3_covers_mesh.py", "export_m3.py", "rh_build_v45.py",
                                                                "rh_check_v45hw.py", "build_v45_site.py")}
readme = rd(W + r"\v45_doc\README_KO.md")
info = {}
for tag, zname, d3dm, base, cover, pk in (("current", "Meloprint_PF2_Print_Package.zip", "Meloprint_PF2_v45_M3_Assembly.3dm", "01_Base_AP1", "02_Cover_AP1", "pkg"),
                                          ("makerworld", "Meloprint_PF2_MW4_Print_Package.zip", "Meloprint_PF2_v45_M3_MW4_Assembly.3dm", "01_Base_MW4", "02_Cover_MW4", "pkg_mw4")):
    zin = zipfile.ZipFile(os.path.join(S44, "downloads", zname))
    repl = {"print_stl/%s_PRINT.stl" % base: rd(os.path.join(A, pk, "print_stl", base + "_PRINT.stl")),
            "print_stl/%s_PRINT.stl" % cover: rd(os.path.join(A, pk, "print_stl", cover + "_PRINT.stl"))}
    entries = []
    for i in zin.infolist():
        n = i.filename
        if re.match(r"^print_stl/(19|20|21|22)_", n) or n in ("SHA256.json", "3dm_checks.json") or (n.endswith(".3dm") and "/" not in n):
            continue
        if n == "README_KO.md":
            entries.append(("history/v44/README_KO.md", zin.read(n))); entries.append((n, readme)); continue
        if n.startswith("Meloprint_PF2_v44") and n.endswith(".step"):
            entries.append(("history/v44/" + n, zin.read(n))); continue
        entries.append((n, repl.get(n, zin.read(n))))
    b3 = rd(os.path.join(O, d3dm))
    entries.append((d3dm, b3))
    for n in (base, cover, "M3_Hardware"):
        entries.append(("v45_native_parts/%s.step" % n, rd(os.path.join(O, "STEP_v45", n + ".step"))))
    entries += sorted(checks.items()) + sorted(sources.items())
    faces = {"current": 2535, "makerworld": 2188}[tag]
    desc = {"file": "cad/" + d3dm, "filename": d3dm, "bytes": len(b3), "sha256": sha(b3), "parts": 12, "hardware": "4x M3x20 DIN912 + 4x M3 DIN934",
            "revision": "PF2", "fixedSample": True, "faces": faces, "assemblyRevision": "PF2-v45", "combStyle": tag, "rhinoArchiveVersion": 7}
    info[tag] = desc
    entries.append(("3dm_checks.json", json.dumps({tag: desc}, indent=2).encode()))
    names = [n for n, _ in entries]
    assert len(names) == len(set(names)), [n for n in names if names.count(n) > 1]
    entries.append(("SHA256.json", json.dumps({n: sha(b) for n, b in entries}, indent=2).encode()))
    out = os.path.join(D, "downloads", zname)
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for n, b in entries:
            z.writestr(n, b)
    stl = [n for n in names if re.match(r"^print_stl/\d{2}_.*\.stl$", n) and not re.match(r"^print_stl/(02|15|16)_", n)]
    print(zname, "entries", len(entries), "MB %.1f" % (os.path.getsize(out) / 1e6), "mechanism STLs", len(stl), sorted(stl))
    json.dump(desc, open(os.path.join(D, "cad", "pf2-surface.json" if tag == "current" else "pf2-surface-mw4.json"), "w"), indent=2)


# --- code / text
def esc(t):
    return "".join(c if ord(c) < 128 else ("\\x%02X" % ord(c) if ord(c) < 256 else "\\u%04X" % ord(c)) for c in t)


def patch(rel, reps):
    p = os.path.join(D, rel)
    s = open(p, encoding="utf-8").read()
    for old, new, n in reps:
        c = s.count(old)
        assert c == n, (rel, old[:70], c, n)
        s = s.replace(old, new)
    open(p, "w", encoding="utf-8", newline="").write(s)
    print("patched", rel, len(reps))


locks_ey = "".join('{key:"lock%d",name:"%d_CaseLock_AP1",file:"assets/pf2/%d_CaseLock_AP1.stl",motion:"fixed"},' % (i + 1, 19 + i, 19 + i) for i in range(4))
patch("app.js", [
    (locks_ey, "", 1),
    ('{key:"rearRail",name:"23_RearGuideRail",file:"assets/pf2/23_RearGuideRail.stl",motion:"fixed"}];function cY(',
     '{key:"rearRail",name:"23_RearGuideRail",file:"assets/pf2/23_RearGuideRail.stl",motion:"fixed"},'
     '{key:"hardware",name:"M3_Hardware",file:"assets/pf2/M3_Hardware.stl",motion:"fixed"}];function cY(', 1),
    (esc("PF2 전체 16부품"), esc("PF2 전체 12부품 + M3×20 나사·너트 4세트"), 1),
    (esc("16부품"), esc("12부품"), 3),
    (esc("16개"), esc("12개"), 4),
    ('"v44 ' + esc("기본"), '"v45 ' + esc("기본"), 1),
    ('"v44 MW4 ', '"v45 MW4 ', 1),
    ("mm_16_Parts.zip", "mm_12_Parts_M3.zip", 1),
    (".length!==16)throw", ".length!==12)throw", 1),
])
LOCKS_PP = ", ".join('{"key": "lock%d", "name": "%d_CaseLock_AP1", "file": "assets/pf2/%d_CaseLock_AP1.stl", "motion": "fixed"}' % (i + 1, 19 + i, 19 + i) for i in range(4)) + ", "
patch("pf2-parts.js", [(LOCKS_PP, "", 1)])
V45 = ('<p class="hint"><strong>v45 · 케이스 락 4개를 M3 나사로 교체.</strong> 상판 네 모서리를 M3×20 육각 렌치 볼트(DIN 912) 4개와 M3 너트 4개로 고정합니다. '
       '너트는 베이스 바닥의 육각 홈에 넣고, 나사는 상판 위에서 2.5mm 렌치로 조입니다. 출력 부품은 12개입니다. 상판 7종 모두 나사 머리가 윗면보다 0.9mm 들어가 있고, 장식은 그대로입니다.</p>')
patch("index.html", [
    ('<p class="eyebrow">PF2 v44 · 16 PRINTED PARTS</p>', '<p class="eyebrow">PF2 v45 · 12 PRINTED PARTS + M3 SCREWS</p>', 1),
    ("<h2>전체 모델링 다운로드</h2>", "<h2>전체 모델링 다운로드</h2>" + V45, 1),
    ("v44에서 화살표 가이드 레일 1개를 더해 16개입니다.", "v44에서 화살표 가이드 레일 1개를 더했고, v45에서 케이스 락 4개를 M3 나사로 바꿔 출력 부품은 12개입니다.", 1),
    ("작은 기능 클립 2개와 케이스 락 4개는 남아 있습니다.", "작은 기능 클립 2개는 남아 있습니다.", 1),
    ("선택 상판·현재 멜로디 ZIP · 16부품", "선택 상판·현재 멜로디 ZIP · 12부품 + M3", 1),
    ("현재 설정 전체 3DM · 16개 메시", "현재 설정 전체 3DM · 12개 메시", 1),
    ("v44 기본 상판 고정 샘플 · 서피스 3DM (Rhino 7)", "v45 기본 상판 고정 샘플 · 서피스 3DM (Rhino 7)", 1),
    ("16개의 닫힌 서피스 솔리드(Rhino 7 형식), 일반 2,575개 면 / MW4 2,228개 면입니다.",
     "출력 부품 12개의 닫힌 서피스 솔리드와 M3 나사·너트 8개(별도 레이어)가 들어 있습니다(Rhino 7 형식, 출력 부품 면 수 일반 2,535 / MW4 2,188).", 1),
    ("v44 현재형 고정 샘플 전체 ZIP · STEP·3DM·설명서", "v45 현재형 고정 샘플 전체 ZIP · STEP·3DM·설명서", 1),
    ("v44 MW4 33음 고정 샘플 전체 ZIP · STEP·3DM", "v45 MW4 33음 고정 샘플 전체 ZIP · STEP·3DM", 1),
    ("<strong>v44 조립 순서:</strong> 04 아래 기어 → <strong>23 레일(핀을 베이스 구멍에)</strong> → 03 메인기어·10 클립 → 06 롤러·12 클립 → 05 화살표 → 화살표를 가운데 두고 02 상판 → 19–22 케이스 락 → 11 손잡이 원판 → 화살표를 끝으로 옮기고 15/16 빗. ",
     "<strong>v45 조립 순서:</strong> 04 아래 기어 → <strong>23 레일(핀을 베이스 구멍에)</strong> → 03 메인기어·10 클립 → 06 롤러·12 클립 → 05 화살표 → 화살표를 가운데 두고 02 상판 → <strong>베이스 바닥 육각 홈에 M3 너트 4개, 상판 위에서 M3×20 나사 4개</strong> → 11 손잡이 원판 → 화살표를 끝으로 옮기고 15/16 빗. 빗을 뺄 때는 나사 4개를 풀고 상판을 엽니다. ", 1),
    ("선택 상판으로 전체 16부품 ZIP", "선택 상판으로 전체 12부품 ZIP", 1),
    ("외형 크기는 유지하고 부품은 16개입니다. 기존 3종도 v44 일반형 베이스·상판을 사용합니다.",
     "외형 크기는 유지하고 출력 부품은 12개 + M3 나사 4세트입니다. 기존 3종도 v45 일반형 베이스·상판을 사용합니다.", 1),
    ("PF2 16부품 구조(v44)를 사용하며 빗은 15·16번입니다.", "PF2 12부품 + M3 나사 구조(v45)를 사용하며 빗은 15·16번입니다.", 1),
    ("<strong>PF2 32 Stable · v44</strong>", "<strong>PF2 32 Stable · v45 M3</strong>", 1),
])
print(json.dumps(info, indent=1))
