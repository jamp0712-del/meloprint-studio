# Comb insertion (-Y, arrow parked at the end) against base + cover, v44 vs v45 (M3): the hit list must be identical.
import sys
sys.path.insert(0, r"C:\Users\Public\mbx_work")
from pf2_kin import load, posed
from mf_tool import inter_vol
for tag, src in (("v44", r"C:\Users\Public\mbx_work\in\pf2mod_brep"), ("v45", r"C:\Users\Public\mbx_work\in\pf2m3_brep"),
                 ("v44 MW4", r"C:\Users\Public\mbx_work\in\pf2mw4_valid"), ("v45 MW4", r"C:\Users\Public\mbx_work\in\pf2m3mw4_valid")):
    M = posed(load(src), 90)
    combs = {n: M[n] for n in M if n[:2] in ("15", "16")}
    inst = {n: M[n] for n in M if n[:2] not in ("15", "16")}
    hits = []
    for k in range(31):
        t = 1.0 - k / 30.0
        for cn, cm in combs.items():
            m2 = cm.translate((0, 45 * t, 0))
            for n, o in inst.items():
                v, bb = inter_vol(m2, o)
                if v > 0.01:
                    hits.append((round(t, 3), cn[:2], n[:2], round(v, 2)))
    print("%-8s comb insertion hits %d  %s" % (tag, len(hits), sorted(set((h[1], h[2]) for h in hits))))
    print("          ", hits)
