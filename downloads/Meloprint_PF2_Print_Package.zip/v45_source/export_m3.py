# -*- coding: utf-8 -*-
# Export v45 (M3) changed parts: STEP (B-rep), viewer STLs (assembly frame), print STLs (site orientation rules).
import sys, os, json
sys.argv = [sys.argv[0], r"C:\Users\Public\mbx_work\pf2_out"] + sys.argv[1:]
sys.path.insert(0, r"C:\Users\Public\mbx_work")
import numpy as np, trimesh
from ap1_view import load_cache
from mf_tool import to_manifold
from ap1_export import step_write, write_stl
from occ_conv import volume
from ap1_tool import fuse
OUT = r"C:\Users\Public\mbx_work\v45_assets"
STEP = r"C:\Users\Public\mbx_work\pf2_out\STEP_v45"
os.makedirs(STEP, exist_ok=True)
AP = load_cache(r"C:\Users\Public\mbx_work\in\pf2m3_brep")
MW = load_cache(r"C:\Users\Public\mbx_work\in\pf2m3mw4_brep")
HW = load_cache(r"C:\Users\Public\mbx_work\in\pf2m3_hw")
FLIP = np.array([[1, 0, 0], [0, -1, 0], [0, 0, -1]], float)
rep = {}


def mesh(s, defl=0.004):
    mm = to_manifold(s, defl).to_mesh()
    return np.array(mm.vert_properties)[:, :3].astype(float), np.array(mm.tri_verts).astype(np.int64)


def put(rel, V, F, name):
    p = os.path.join(OUT, rel)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    write_stl(p, V, F, name)
    t = trimesh.load(p)
    rep[rel] = {"tris": int(len(F)), "watertight": bool(t.is_watertight), "volume": round(float(t.volume), 2),
                "size": [round(float(v), 2) for v in t.extents]}
    print("%-48s %s" % (rel, rep[rel]))


def center(W, y0=False):
    return W - np.array([(W[:, 0].min() + W[:, 0].max()) / 2, W[:, 1].min() if y0 else (W[:, 1].min() + W[:, 1].max()) / 2, W[:, 2].min()])


for n, s in (("01_Base_AP1", AP["01_Base_AP1"]), ("02_Cover_AP1", AP["02_Cover_AP1"]), ("01_Base_MW4", MW["01_Base_MW4"]), ("02_Cover_MW4", MW["02_Cover_MW4"])):
    step_write([(n, s)], os.path.join(STEP, n + ".step"))
    V, F = mesh(s)
    if n in ("01_Base_AP1", "01_Base_MW4", "02_Cover_AP1"):
        put("assets/pf2/%s.stl" % n, V, F, n)
    if n.startswith("01"):
        put(("pkg" if "AP1" in n else "pkg_mw4") + "/print_stl/%s_PRINT.stl" % n, center(V.copy()), F, n)
        if "MW4" in n:
            put("models/01_Base_MW4_PRINT.stl", center(V.copy(), y0=True), F, n)
    else:
        put(("pkg" if "AP1" in n else "pkg_mw4") + "/print_stl/%s_PRINT.stl" % n, center(V @ FLIP.T), F, n)
# hardware: one viewer mesh with all four screws and nuts
hw_all = None
Vs, Fs, off = [], [], 0
for n in sorted(HW):
    V, F = mesh(HW[n], 0.01)
    Vs.append(V); Fs.append(F + off); off += len(V)
put("assets/pf2/M3_Hardware.stl", np.vstack(Vs), np.vstack(Fs), "M3_Hardware")
step_write([(n, HW[n]) for n in sorted(HW)], os.path.join(STEP, "M3_Hardware.step"))
json.dump(rep, open(os.path.join(OUT, "export_m3.json"), "w"), indent=1)
