# -*- coding: utf-8 -*-
# Rhino 7: v45 (M3) surface 3DMs from the v44 files. 19-22 case locks removed, 01/02 replaced, M3 hardware layer added.
import math, traceback
import Rhino
import Rhino.Geometry as G
import scriptcontext as sc
import rhinoscriptsyntax as rs
import System.Drawing as SD

W = r"C:\Users\Public\mbx_work"
O = W + r"\pf2_out"
LOG = open(W + r"\rh_build_v45.log", "w")
def L(*a):
    LOG.write(" ".join(str(x) for x in a) + "\n"); LOG.flush()
REV = "PF2-v45 M3 screws"
CORNERS = [(-40.0, -119.0), (40.0, -119.0), (-40.0, 58.8), (40.0, 58.8)]
CB_Z, NUT_Z1 = 16.80, -1.00


def import_step(path):
    doc = sc.doc
    before = set(o.Id for o in doc.Objects)
    rs.Command('_-Import "' + path + '" _Enter', False)
    new = [o for o in doc.Objects if o.Id not in before]
    for o in new:
        if isinstance(o, Rhino.DocObjects.InstanceObject):
            rs.ExplodeBlockInstance(o.Id, True)
    new = [o for o in doc.Objects if o.Id not in before and not isinstance(o, Rhino.DocObjects.InstanceObject)]
    bs = [o.Geometry.DuplicateBrep() for o in new if isinstance(o.Geometry, G.Brep)]
    for o in new:
        doc.Objects.Delete(o.Id, True)
    if len(bs) != 1:
        raise RuntimeError("%s: %d breps" % (path, len(bs)))
    return bs[0]


def cyl(cx, cy, r, z0, z1):
    return G.Cylinder(G.Circle(G.Plane(G.Point3d(cx, cy, z0), G.Vector3d.ZAxis), r), z1 - z0).ToBrep(True, True)


def hexprism(cx, cy, af, z0, z1, rot):
    rr = af / 2.0 / math.cos(math.radians(30))
    pts = [G.Point3d(cx + rr * math.cos(math.radians(rot + 60 * k)), cy + rr * math.sin(math.radians(rot + 60 * k)), z0) for k in range(7)]
    srf = G.Surface.CreateExtrusion(G.PolylineCurve(pts), G.Vector3d(0, 0, z1 - z0))
    b = srf.ToBrep().CapPlanarHoles(0.001)
    if b.SolidOrientation == G.BrepSolidOrientation.Inward:
        b.Flip()
    return b


def single(res, what):
    if res is None or len(res) != 1 or not res[0].IsSolid:
        raise RuntimeError(what)
    return res[0]


def ivol(a, b):
    if not G.BoundingBox.Intersection(a.GetBoundingBox(True), b.GetBoundingBox(True)).IsValid:
        return 0.0
    r = G.Brep.CreateBooleanIntersection(a, b, 0.001)
    if r is None:
        return None
    t = 0.0
    for x in r:
        m = G.VolumeMassProperties.Compute(x)
        if m:
            t += abs(m.Volume)
    return t


try:
    hw = []
    for i, (cx, cy) in enumerate(CORNERS):
        screw = single(G.Brep.CreateBooleanUnion([cyl(cx, cy, 2.75, CB_Z, CB_Z + 3.0), cyl(cx, cy, 1.5, CB_Z - 20.0, CB_Z + 0.5)], 0.001), "screw")
        nut = single(G.Brep.CreateBooleanDifference(hexprism(cx, cy, 5.5, NUT_Z1 - 2.4, NUT_Z1, 30.0), cyl(cx, cy, 1.5, NUT_Z1 - 3.5, NUT_Z1 + 1.0), 0.001), "nut")
        hw.append(("M3x20_DIN912_%d" % (i + 1), screw))
        hw.append(("M3_Nut_DIN934_%d" % (i + 1), nut))
    covers = dict((o.Attributes.Name, o.Geometry.DuplicateBrep()) for o in Rhino.FileIO.File3dm.Read(O + r"\m3_covers.3dm").Objects)
    for tag, src, dst, base in (("AP1", O + r"\Meloprint_PF2_v44_Assembly.3dm", O + r"\Meloprint_PF2_v45_M3_Assembly.3dm", "01_Base_AP1"),
                                ("MW4", O + r"\Meloprint_PF2_v44_MW4_Assembly.3dm", O + r"\Meloprint_PF2_v45_M3_MW4_Assembly.3dm", "01_Base_MW4")):
        cover = "02_Cover_AP1" if tag == "AP1" else "02_Cover_MW4"
        repl = {base: import_step(O + r"\STEP_v45\%s.step" % base), cover: covers[cover]}
        f0 = Rhino.FileIO.File3dm.Read(src)
        f = Rhino.FileIO.File3dm()
        f.Settings.ModelUnitSystem = f0.Settings.ModelUnitSystem
        f.Settings.ModelAbsoluteTolerance = f0.Settings.ModelAbsoluteTolerance
        lay0 = dict((l.Index, l.Name) for l in f0.AllLayers)
        for l in f0.AllLayers:
            if l.Name[:2] in ("19", "20", "21", "22"):
                continue
            nl = Rhino.DocObjects.Layer(); nl.Name = l.Name; nl.Color = l.Color
            f.AllLayers.Add(nl)
        hl = Rhino.DocObjects.Layer(); hl.Name = "M3_Hardware (buy, do not print)"; hl.Color = SD.Color.FromArgb(150, 150, 160)
        f.AllLayers.Add(hl)
        idx = dict((l.Name, l.Index) for l in f.AllLayers)
        geo, faces = {}, 0
        for o in f0.Objects:
            n = o.Attributes.Name
            if n[:2] in ("19", "20", "21", "22"):
                continue
            a = o.Attributes.Duplicate(); a.LayerIndex = idx[lay0[o.Attributes.LayerIndex]]
            b = repl[n].DuplicateBrep() if n in repl else o.Geometry.DuplicateBrep()
            if n in repl:
                a.SetUserString("Revision", REV)
                a.SetUserString("Change", "case-lock sockets -> M3 clearance hole + hex nut pocket (underside)" if n == base else
                                "lock keyholes filled; M3 clearance hole + counterbore, front 0.228 mm seat boss")
            f.Objects.AddBrep(b, a); geo[n] = b; faces += b.Faces.Count
        for n, b in hw:
            a = Rhino.DocObjects.ObjectAttributes(); a.Name = n; a.LayerIndex = idx["M3_Hardware (buy, do not print)"]
            a.SetUserString("Printable", "No"); a.SetUserString("Part", n); a.SetUserString("Revision", REV)
            f.Objects.AddBrep(b, a); geo[n] = b
        f.Strings.SetString("MeloprintRevision", "PF2-v45")
        f.Strings.SetString("Changes", "v45 = v44 with the four printed case locks (19-22) replaced by 4x M3x20 DIN 912 + 4x M3 DIN 934 nuts")
        f.Write(dst, 7)
        back = Rhino.FileIO.File3dm.Read(dst)
        bad = [o.Attributes.Name for o in back.Objects if not (isinstance(o.Geometry, G.Brep) and o.Geometry.IsSolid and o.Geometry.IsValid)]
        L("%s saved archive=%d objects=%d printed-part faces=%d bad=%s" % (dst, Rhino.FileIO.File3dm.ReadArchiveVersion(dst), len(back.Objects), faces, bad))
        for n, b in hw:
            row = []
            for p in (base, cover, "03_MainGear_AP1", "11_HandleRetainer_AP1", "16_CombUpper_AP1" if tag == "AP1" else "16_CombUpper_MW4"):
                row.append("%s:%s" % (p[:2], ivol(b, geo[p])))
            L("  %-18s %s" % (n, "  ".join(row)))
except Exception:
    L("ERR", traceback.format_exc())
L("##DONE##")
LOG.close()
