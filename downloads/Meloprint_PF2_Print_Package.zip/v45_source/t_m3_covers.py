# Bring the Rhino-made M3 covers into the OCC caches and re-check them.
import sys, os
sys.path.insert(0, r"C:\Users\Public\mbx_work")
import rhino3dm as r
from occ_conv import brep_to_occ, volume
from ap1_tool import n_solids, valid
from OCP.BRepTools import BRepTools
f = r.File3dm.Read(r"C:\Users\Public\mbx_work\pf2_out\m3_covers.3dm")
W = r"C:\Users\Public\mbx_work\in"
for o in f.Objects:
    n = o.Attributes.Name
    s, info = brep_to_occ(o.Geometry)
    print("%-14s solids=%d valid=%s vol=%.2f" % (n, n_solids(s), valid(s), volume(s)))
    if n == "02_Cover_AP1":
        BRepTools.Write_s(s, os.path.join(W, "pf2m3_brep", n + ".brep"))
    else:
        BRepTools.Write_s(s, os.path.join(W, "pf2m3mw4_brep", n + ".brep"))
        BRepTools.Write_s(s, os.path.join(W, "pf2m3mw4_valid", "02_Cover_AP1.brep"))
