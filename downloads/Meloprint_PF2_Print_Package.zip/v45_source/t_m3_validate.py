# -*- coding: utf-8 -*-
# M3 version checks: hardware fit, wall thickness around the new cuts, assembly path with screws and nuts.
import sys, json
sys.path.insert(0, r"C:\Users\Public\mbx_work")
from ap1_view import load_cache
from ap1_tool import cyl, box, cut
from ap1_mods import hexagon, common
from occ_conv import volume
from mf_tool import to_manifold, inter_vol
from pf2_kin import load, posed
from OCP.BRepExtrema import BRepExtrema_DistShapeShape
import m3_mods as MM

src = sys.argv[1]
base_name = sys.argv[2] if len(sys.argv) > 2 else "01_Base_AP1"
R = {}
S = load_cache(src)
HW = load_cache(r"C:\Users\Public\mbx_work\in\pf2m3_hw")
B0 = load_cache(r"C:\Users\Public\mbx_work\in\pf2mod_brep" if "MW4" not in base_name else r"C:\Users\Public\mbx_work\in\pf2mw4mod_brep")[base_name]
B = S[[n for n in S if n.startswith("01")][0]]
C = S[[n for n in S if n.startswith("02")][0]]

# 1) hardware vs every part (manifold, nominal)
MF = {n: to_manifold(s, 0.005) for n, s in S.items() if n[:2] not in ("15", "16")}
HWM = {n: to_manifold(s, 0.005) for n, s in HW.items()}
hw = []
for hn, hm in HWM.items():
    for n, m in MF.items():
        v = (hm ^ m).volume()
        g = hm.min_gap(m, 2.0)
        if v > 1e-4 or g < 0.05:
            hw.append((hn, n, round(v, 4), round(g, 3)))
R["hardware_contacts"] = hw
print("hardware vs parts (overlap mm3, min gap mm) where gap < 0.05:")
for h in hw:
    print("  ", h)

# 2) wall thickness around each new cut: pocket+hole vs the voids of the ORIGINAL base in the corner region
walls = []
for cx, cy in MM.CORNERS:
    reg = box(cx - 7, cy - 7, -4.75, cx + 7, cy + 7, 10.3)
    void = cut(reg, B0)
    void = cut(void, cyl(cx, cy, 3.95, 10.2, 10.5))          # ignore the socket the screw hole opens into
    pocket = common(hexagon(cx, cy, MM.NUT_AF, -4.75, MM.NUT_Z1, MM.NUT_ROT), reg)
    hole = cyl(cx, cy, MM.HOLE_BASE_R, MM.NUT_Z1, 10.2)
    d1 = BRepExtrema_DistShapeShape(pocket, void); d1.Perform()
    d2 = BRepExtrema_DistShapeShape(hole, void); d2.Perform()
    walls.append({"corner": [cx, cy], "nut_pocket_min_wall": round(d1.Value(), 3), "hole_min_wall": round(d2.Value(), 3)})
    print("corner (%g,%g): min wall around nut pocket %.3f mm, around hole %.3f mm" % (cx, cy, d1.Value(), d2.Value()))
R["walls"] = walls
R["base_removed_mm3"] = round(volume(B0) - volume(B), 2)
print("base material removed %.2f mm3 (nominal 4 x 214.0)" % R["base_removed_mm3"])

# 3) assembly path with screws/nuts (cover lowered with the arrow centred, then screws from above, nuts from below)
ML = load(src)
MC = posed(ML, 0)
inst = {n: m for n, m in MC.items() if n[:2] not in ("15", "16", "02", "11")}
cov = [n for n in MC if n.startswith("02")][0]


def path(mov, vec, installed, steps=40):
    out = []
    for k in range(steps + 1):
        t = 1.0 - k / float(steps)
        m2 = mov.translate((vec[0] * t, vec[1] * t, vec[2] * t))
        for n, o in installed.items():
            v, bb = inter_vol(m2, o)
            if v > 0.01:
                out.append((round(t, 3), n, round(v, 3)))
    return out


h = path(MC[cov], (0, 0, 35), inst)
R["cover_lowering_hits"] = h
print("cover lowering: %d hits %s" % (len(h), h[:3]))
inst[cov] = MC[cov]
hd = [n for n in MC if n.startswith("11")][0]
h11 = path(MC[hd], (0, 0, 30), inst)
R["handle_disc_after_cover_hits"] = h11
print("11 handle disc after cover: %d hits %s" % (len(h11), h11[:3]))
inst[hd] = MC[hd]
hits = []
for hn, hm in HWM.items():
    vec = (0, 0, 30) if "Screw" in hn else (0, 0, -20)
    others = dict(inst)
    hh = path(hm, vec, others)
    hits += [(hn,) + x for x in hh]
R["hardware_insertion_hits"] = hits
print("screw/nut insertion: %d hits %s" % (len(hits), hits[:4]))
json.dump(R, open(sys.argv[3] if len(sys.argv) > 3 else r"C:\Users\Public\mbx_work\m3_checks.json", "w"), indent=1)
