# -*- coding: utf-8 -*-
import sys, os, time
sys.path.insert(0, r"C:\Users\Public\mbx_work")
from ap1_view import load_cache
from ap1_tool import n_solids, valid
from occ_conv import volume
from OCP.BRepTools import BRepTools
import m3_mods as MM

W = r"C:\Users\Public\mbx_work\in"


def save(d, shapes):
    os.makedirs(d, exist_ok=True)
    for f in os.listdir(d):
        os.remove(os.path.join(d, f))
    for n, s in shapes.items():
        BRepTools.Write_s(s, os.path.join(d, n + ".brep"))


HW = MM.hardware()
for src, dst, base, cover in ((W + r"\pf2mod_brep", W + r"\pf2m3_brep", "01_Base_AP1", "02_Cover_AP1"),
                              (W + r"\pf2mw4mod_brep", W + r"\pf2m3mw4_brep", "01_Base_MW4", "02_Cover_MW4")):
    S = load_cache(src)
    t = time.time()
    out = {n: s for n, s in S.items() if n[:2] not in ("19", "20", "21", "22")}
    out[base] = MM.base_m3(S[base])
    out[cover] = S[cover]      # placeholder: the cover is rebuilt in Rhino (rh_m3_cover.py) and loaded by t_m3_covers.py
    for n in (base,):
        print("%-14s solids=%d valid=%s vol=%.2f (d=%.2f)  %.0fs" % (n, n_solids(out[n]), valid(out[n]), volume(out[n]), volume(out[n]) - volume(S[n]), time.time() - t))
    save(dst, out)
    if "MW4" in base:   # alias copy with AP1 names for the shared validators
        A = {"01_Base_MW4": "01_Base_AP1", "02_Cover_MW4": "02_Cover_AP1", "15_CombLower_MW4": "15_CombLower_AP1", "16_CombUpper_MW4": "16_CombUpper_AP1"}
        save(W + r"\pf2m3mw4_valid", {A.get(n, n): s for n, s in out.items()})
save(W + r"\pf2m3_hw", HW)
for n, s in HW.items():
    print("%-20s solids=%d valid=%s vol=%.2f" % (n, n_solids(s), valid(s), volume(s)))
