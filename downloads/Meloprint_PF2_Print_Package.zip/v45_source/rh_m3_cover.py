﻿# -*- coding: utf-8 -*-
# Rhino 7: M3 conversion of the 02 cover B-reps (AP1, MW4). OCC's fuse fails on the front keyway faces, Rhino's does not.
import traceback
import Rhino
import Rhino.Geometry as G

W = r"C:\Users\Public\mbx_work"
LOG = open(W + r"\rh_m3_cover.log", "w")
def L(*a):
    LOG.write(" ".join(str(x) for x in a) + "\n"); LOG.flush()
TOL = 0.001
CORNERS = [(-40.0, -119.0), (40.0, -119.0), (-40.0, 58.8), (40.0, 58.8)]
COVER_BOTTOM, BASE_TOP, LEDGE = 14.95, 14.722, 19.45
FILL_R, HOLE_R, CB_R, CB_Z = 3.95, 1.70, 3.00, 16.80


def cyl(cx, cy, r, z0, z1):
    c = G.Circle(G.Plane(G.Point3d(cx, cy, z0), G.Vector3d.ZAxis), r)
    return G.Cylinder(c, z1 - z0).ToBrep(True, True)


def one(res, what):
    if res is None or len(res) != 1:
        raise RuntimeError("%s: %s pieces" % (what, None if res is None else len(res)))
    b = res[0]
    if not (b.IsValid and b.IsSolid):
        raise RuntimeError("%s: invalid/open result" % what)
    return b


def vol(b):
    m = G.VolumeMassProperties.Compute(b)
    if m is not None:
        return m.Volume
    ms = G.Mesh.CreateFromBrep(b, G.MeshingParameters.QualityRenderMesh)
    mm = G.Mesh()
    for x in ms:
        mm.Append(x)
    return -G.VolumeMassProperties.Compute(mm).Volume


try:
    out = Rhino.FileIO.File3dm()
    out.Settings.ModelUnitSystem = Rhino.UnitSystem.Millimeters
    out.Settings.ModelAbsoluteTolerance = 0.005
    for src, name in ((W + r"\pf2_out\Meloprint_PF2_v44_Assembly.3dm", "02_Cover_AP1"),
                      (W + r"\pf2_out\Meloprint_PF2_v44_MW4_Assembly.3dm", "02_Cover_MW4")):
        f = Rhino.FileIO.File3dm.Read(src)
        C = [o.Geometry for o in f.Objects if o.Attributes.Name == name][0].DuplicateBrep()
        v0 = vol(C)
        fills = []
        for i, (cx, cy) in enumerate(CORNERS):
            fills.append(cyl(cx, cy, FILL_R, BASE_TOP if i < 2 else COVER_BOTTOM, LEDGE))
        B = one(G.Brep.CreateBooleanUnion([C] + fills, TOL), name + " union")
        v1 = vol(B)
        cutters = []
        for cx, cy in CORNERS:
            cutters.append(cyl(cx, cy, HOLE_R, BASE_TOP - 0.3, CB_Z + 0.01))
            cutters.append(cyl(cx, cy, CB_R, CB_Z, LEDGE + 0.02))
        B = one(G.Brep.CreateBooleanDifference([B], cutters, TOL), name + " difference")
        v2 = vol(B)
        L("%s: v44 %.2f -> +fill %.2f -> +holes %.2f (net %.2f) faces %d solid %s valid %s" % (name, v0, v1, v2, v2 - v0, B.Faces.Count, B.IsSolid, B.IsValid))
        a = Rhino.DocObjects.ObjectAttributes(); a.Name = name
        out.Objects.AddBrep(B, a)
    out.Write(W + r"\pf2_out\m3_covers.3dm", 7)
    L("saved m3_covers.3dm")
except Exception:
    L("ERR", traceback.format_exc())
L("##DONE##")
LOG.close()
