# -*- coding: utf-8 -*-
# Apply the M3 cover change to all 14 downloadable cover STLs (mesh booleans), check each, write v45 assets.
import sys, os, json
sys.path.insert(0, r"C:\Users\Public\mbx_work")
import numpy as np, trimesh, manifold3d as m3
from ap1_export import write_stl
import m3_mods as MM
S = r"C:\Users\Public\mbx_work\site_v44"
OUT = sys.argv[1]
LB = {"base": (0.030805587768554688, -30.558719635009766, 20.73442268371582)}
for k in ("chrome", "acid", "pink", "ice", "orange", "purple"):
    LB[k] = (0.030805587768554688, -30.558719635009766, 21.134403228759766)


def to_mf(V, F):
    return m3.Manifold(m3.Mesh(vert_properties=np.asarray(V, np.float32), tri_verts=np.asarray(F, np.uint32)))


def from_mf(mf):
    mm = mf.to_mesh()
    return np.array(mm.vert_properties)[:, :3].astype(float), np.array(mm.tri_verts).astype(np.int64)


screws = None
res = {}
os.makedirs(os.path.join(OUT, "models"), exist_ok=True)
for pre in ("", "mw4_"):
    for k, (cx, cy, zz) in LB.items():
        fn = "%s02_Cover_PF2_%s_PRINT.stl" % (pre, k)
        t = trimesh.load(os.path.join(S, "models", fn)); t.merge_vertices()
        V = np.c_[t.vertices[:, 0] + cx, cy - t.vertices[:, 1], zz - t.vertices[:, 2]]     # print -> assembly (180 deg about X)
        C0 = to_mf(V, t.faces)
        C1 = MM.cover_m3_mesh(m3, C0)
        # checks: screw heads/shanks must not touch the cover; driver access above each head must be open
        bad, access = [], []
        for cxx, cyy in MM.CORNERS:
            scr = MM.mf_cyl(m3, cxx, cyy, MM.HEAD_D / 2 - 0.01, MM.CB_Z + 0.01, MM.CB_Z + MM.HEAD_H) + MM.mf_cyl(m3, cxx, cyy, 1.49, MM.CB_Z - 6, MM.CB_Z + 0.02)
            bad.append(round((scr ^ C1).volume(), 4))
            access.append(round((MM.mf_cyl(m3, cxx, cyy, 2.9, MM.CB_Z + 0.05, 30.0) ^ C1).volume(), 4))
        W, F = from_mf(C1)
        P = np.c_[W[:, 0] - cx, cy - W[:, 1], zz - W[:, 2]]                                  # assembly -> print
        p = os.path.join(OUT, "models", fn)
        write_stl(p, P, F, fn[:-4])
        tm = trimesh.load(p)
        res[pre + k] = {"vol_before": round(C0.volume(), 2), "vol_after": round(C1.volume(), 2), "delta": round(C1.volume() - C0.volume(), 2),
                        "watertight": bool(tm.is_watertight), "screw_overlap_mm3": bad, "driver_access_blocked_mm3": access,
                        "z_range": [round(float(tm.bounds[0][2]), 3), round(float(tm.bounds[1][2]), 3)]}
        print("%-12s dV %.2f watertight %s screw overlap %s access blocked %s" % (pre + k, res[pre + k]["delta"], tm.is_watertight, bad, access))
json.dump(res, open(r"C:\Users\Public\mbx_work\m3_cover_mesh_checks.json", "w"), indent=1)
