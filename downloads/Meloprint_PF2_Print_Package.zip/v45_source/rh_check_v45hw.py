# -*- coding: utf-8 -*-
# Rhino 7: hardware vs printed parts with the seating contacts released by 0.01 mm (coplanar contact makes Rhino booleans fail).
import traceback
import Rhino
import Rhino.Geometry as G
W = r"C:\Users\Public\mbx_work"
LOG = open(W + r"\rh_check_v45hw.log", "w")
def L(*a):
    LOG.write(" ".join(str(x) for x in a) + "\n"); LOG.flush()


def ivol(a, b):
    if not G.BoundingBox.Intersection(a.GetBoundingBox(True), b.GetBoundingBox(True)).IsValid:
        return 0.0
    r = G.Brep.CreateBooleanIntersection(a, b, 0.001)
    if r is None:
        return None
    return sum(abs(G.VolumeMassProperties.Compute(x).Volume) for x in r if G.VolumeMassProperties.Compute(x))


try:
    for p in (W + r"\pf2_out\Meloprint_PF2_v45_M3_Assembly.3dm", W + r"\pf2_out\Meloprint_PF2_v45_M3_MW4_Assembly.3dm"):
        f = Rhino.FileIO.File3dm.Read(p)
        g = dict((o.Attributes.Name, o.Geometry) for o in f.Objects)
        base = [k for k in g if k.startswith("01_")][0]
        cov = [k for k in g if k.startswith("02_")][0]
        for n in sorted(k for k in g if k.startswith("M3")):
            b = g[n].DuplicateBrep()
            b.Translate(G.Vector3d(0, 0, 0.01 if "DIN912" in n else -0.01))
            L("%s %-18s base %s  cover %s" % (p[-12:], n, ivol(b, g[base]), ivol(b, g[cov])))
        # positive control: a screw pushed 0.3 mm down must overlap the cover seat
        b = g["M3x20_DIN912_1"].DuplicateBrep(); b.Translate(G.Vector3d(0, 0, -0.3))
        L("  positive control (screw 0.3 mm too deep) cover overlap %s" % ivol(b, g[cov]))
except Exception:
    L("ERR", traceback.format_exc())
L("##DONE##")
LOG.close()
