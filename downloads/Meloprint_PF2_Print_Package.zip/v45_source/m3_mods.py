﻿# -*- coding: utf-8 -*-
# PF2 v45: the four twist case locks (19-22) are replaced by M3x20 socket-head screws + M3 hex nuts.
# Cover: lock keyhole filled, M3 clearance hole + counterbore (head 0.5 below the top); front corners get a
# 0.228 mm seat boss so the cover keeps its designed height (the rear already rests on the base at z 11.522).
# Base: M3 clearance hole down from the socket floor and a hex nut pocket opening on the underside.
import sys, math
sys.path.insert(0, r"C:\Users\Public\mbx_work")
import numpy as np
from ap1_tool import cyl, cut, fuse
from ap1_mods import hexagon

CORNERS = [(-40.0, -119.0), (40.0, -119.0), (-40.0, 58.8), (40.0, 58.8)]
FRONT = CORNERS[:2]
COVER_BOTTOM = 14.95       # cover underside around the locks
BASE_TOP = 14.722          # base corner column top
LEDGE = 19.45              # bottom of the existing lock-head recess (R3.6) in the cover
FILL_R = 3.95              # covers the round hole and the 7.5 x 2 keyway
HOLE_COVER_R = 1.70        # M3 clearance in the cover
CB_R, CB_Z = 3.00, 16.80   # counterbore for DIN 912 head (D5.5 x 3.0) -> head top at z 19.8, top surface 20.734
HOLE_BASE_R = 1.60
NUT_AF, NUT_Z0, NUT_Z1 = 5.75, -4.90, -1.00   # M3 nut 5.5 AF x 2.4, inserted from below; >=1 mm under the comb-latch slit
SCREW_L, HEAD_D, HEAD_H = 20.0, 5.5, 3.0
NUT_T = 2.4
NUT_ROT = 30.0             # a flat, not a corner, faces the comb-latch slit at the rear corners


def cover_m3(C):
    for cx, cy in CORNERS:
        C = fuse(C, cyl(cx, cy, FILL_R, COVER_BOTTOM, LEDGE))
    for cx, cy in FRONT:
        C = fuse(C, cyl(cx, cy, FILL_R, BASE_TOP, COVER_BOTTOM + 0.01))
    for cx, cy in CORNERS:
        C = cut(C, cyl(cx, cy, HOLE_COVER_R, BASE_TOP - 0.3, CB_Z + 0.01), cyl(cx, cy, CB_R, CB_Z, LEDGE + 0.02))
    return C


def base_m3(B):
    for cx, cy in CORNERS:
        B = cut(B, cyl(cx, cy, HOLE_BASE_R, NUT_Z1 - 0.01, 10.6), hexagon(cx, cy, NUT_AF, NUT_Z0, NUT_Z1, NUT_ROT))
    return B


def hardware():
    """Nominal M3x20 DIN 912 screws (seated) and DIN 934 nuts (pulled up to the pocket ceiling), for checks and the 3DM."""
    out = {}
    for i, (cx, cy) in enumerate(CORNERS):
        scr = fuse(cyl(cx, cy, HEAD_D / 2, CB_Z, CB_Z + HEAD_H), cyl(cx, cy, 1.5, CB_Z - SCREW_L, CB_Z + 0.01))
        nut = cut(hexagon(cx, cy, 5.5, NUT_Z1 - NUT_T, NUT_Z1, NUT_ROT),cyl(cx, cy, 1.5, NUT_Z1 - NUT_T - 1, NUT_Z1 + 1))
        out["HW_M3x20_Screw_%d" % (i + 1)] = scr
        out["HW_M3_Nut_%d" % (i + 1)] = nut
    return out


# ---- mesh versions (manifold3d) for the decorative cover STLs, in assembly coordinates
def mf_cyl(m3, cx, cy, r, z0, z1, seg=96):
    return m3.Manifold.cylinder(z1 - z0, r, r, seg).translate((cx, cy, z0))


def cover_m3_mesh(m3, C):
    adds = [mf_cyl(m3, cx, cy, FILL_R, COVER_BOTTOM, LEDGE) for cx, cy in CORNERS]
    adds += [mf_cyl(m3, cx, cy, FILL_R, BASE_TOP, COVER_BOTTOM + 0.01) for cx, cy in FRONT]
    for a in adds:
        C = C + a
    for cx, cy in CORNERS:
        C = C - mf_cyl(m3, cx, cy, HOLE_COVER_R, BASE_TOP - 0.3, CB_Z + 0.01) - mf_cyl(m3, cx, cy, CB_R, CB_Z, LEDGE + 0.02)
    return C
