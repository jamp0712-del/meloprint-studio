﻿# -*- coding: utf-8 -*-
# Concept E parts as NURBS B-rep (OCC): sync axle (exact involute pinions: B-spline flanks, circular tip/root arcs,
# rolling rings), straight-sided racks, new rail 23, and the modifications of the D base / cover / yoke / main gear.
import sys, math
sys.path.insert(0, r"C:\Users\Public\mbx_work")
import numpy as np
from OCP.gp import gp_Pnt, gp_Ax2, gp_Dir, gp_Vec
from OCP.GC import GC_MakeSegment, GC_MakeArcOfCircle
from OCP.TColgp import TColgp_HArray1OfPnt
from OCP.GeomAPI import GeomAPI_Interpolate
from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeEdge, BRepBuilderAPI_MakeWire, BRepBuilderAPI_MakeFace
from OCP.BRepPrimAPI import BRepPrimAPI_MakePrism, BRepPrimAPI_MakeCylinder
from ap1_tool import cut, fuse, box, cyl, moved, valid, n_solids
from ap1_mods import hexagon
from occ_conv import volume
from c2_parts import poly_prism
import e_layout as L

inv = lambda a: math.tan(a) - a


def _checked(op_cls, a, t, kind):
    """Boolean with a volume check: OCC sometimes returns the input unchanged (valid but wrong)."""
    from ap1_tool import _bool
    from OCP.BRepAlgoAPI import BRepAlgoAPI_Common
    import manifold3d as m3
    from mf_tool import to_manifold
    from OCP.TopExp import TopExp_Explorer
    from OCP.TopAbs import TopAbs_SOLID
    from OCP.TopoDS import TopoDS
    va, vt = volume(a), volume(t)
    # common volume independent of OCC (OCC common can fail silently too), solid by solid
    ex = TopExp_Explorer(a, TopAbs_SOLID)
    mt = to_manifold(t, 0.003)
    cm, bad = 0.0, False
    while ex.More():
        so = TopoDS.Solid_s(ex.Current())
        ms = to_manifold(so, 0.003)
        if ms.status() != m3.Error.NoError or abs(ms.volume() - volume(so)) > 1e-3 * abs(volume(so)) + 0.05:
            bad = True
        cm += (ms ^ mt).volume()
        ex.Next()
    if bad:
        cm = max(volume(_bool(BRepAlgoAPI_Common, a, t, f)) for f in (5e-3, 1e-5))
    log = []
    for fz in (5e-3, 1e-5, 1e-3, 2e-2, 1e-4):
        try:
            r = _bool(op_cls, a, t, fz)
        except RuntimeError:
            continue
        exp = va - cm if kind == "cut" else va + vt - cm
        log.append((fz, valid(r), n_solids(r), round(volume(r), 3), round(exp, 3)))
        if not valid(r) and n_solids(r) >= 1:
            from ap1_tool import _fix
            r = _fix(r)
        if valid(r) and n_solids(r) >= 1 and abs(volume(r) - exp) < 2e-4 * max(1.0, abs(exp)) + 0.01 * cm + 0.05:
            return r
    from ap1_tool import bbox
    raise RuntimeError("%s failed volume check tool bbox %s log %s" % (kind, [round(v, 2) for v in bbox(t)], log))


def vcut(a, *tools):
    from OCP.BRepAlgoAPI import BRepAlgoAPI_Cut
    for t in tools:
        a = _checked(BRepAlgoAPI_Cut, a, t, "cut")
    return a


def vfuse(a, *tools):
    from OCP.BRepAlgoAPI import BRepAlgoAPI_Fuse
    for t in tools:
        a = _checked(BRepAlgoAPI_Fuse, a, t, "fuse")
    return a


def _pt(u, v, y):
    return gp_Pnt(float(u), float(y), float(v))           # profile (u, v) -> global (x = u, z = v) at y


def pinion_face(y, cx=0.0, cz=L.AXLE_Z, phase_deg=0.0):
    """Planar face of the involute pinion in the plane y = const, tooth 0 pointing -z at phase 0."""
    pa = math.radians(L.PA)
    rp, rb, ra, rf = L.RP, L.RP * math.cos(pa), L.RA, L.RF
    s = L.M * (math.pi / 2.0 + 2.0 * L.X_SHIFT * math.tan(pa)) - L.THIN_PINION
    half_b = s / (2.0 * rp) + inv(pa)
    pitch = 2.0 * math.pi / L.Z
    rr = np.linspace(rb, ra, 13)
    th = [half_b - inv(math.acos(min(1.0, rb / r))) for r in rr]
    P = lambda r, a: (cx + r * math.cos(a), cz + r * math.sin(a))
    segs = []                                              # CCW in (x, z)
    for k in range(L.Z):
        c = math.radians(-90.0 + phase_deg) + k * pitch
        segs.append(("line", [P(rf, c - half_b), P(rb, c - half_b)]))
        segs.append(("spl", [P(r, c - t) for r, t in zip(rr, th)]))
        segs.append(("arc", [P(ra, c - th[-1]), P(ra, c), P(ra, c + th[-1])]))
        segs.append(("spl", [P(r, c + t) for r, t in zip(rr[::-1], th[::-1])]))
        segs.append(("line", [P(rb, c + half_b), P(rf, c + half_b)]))
        a0, a1 = c + half_b, c + pitch - half_b
        segs.append(("arc", [P(rf, a0), P(rf, 0.5 * (a0 + a1)), P(rf, a1)]))
    # CCW in (x, z) has normal -y; reverse so the face normal is +y (prism along +y stays outward)
    segs = [(t, p[::-1]) for t, p in segs[::-1]]
    w = BRepBuilderAPI_MakeWire()
    for t, p in segs:
        if t == "line":
            e = BRepBuilderAPI_MakeEdge(GC_MakeSegment(_pt(*p[0], y), _pt(*p[1], y)).Value()).Edge()
        elif t == "arc":
            e = BRepBuilderAPI_MakeEdge(GC_MakeArcOfCircle(_pt(*p[0], y), _pt(*p[1], y), _pt(*p[2], y)).Value()).Edge()
        else:
            arr = TColgp_HArray1OfPnt(1, len(p))
            for i, q in enumerate(p):
                arr.SetValue(i + 1, _pt(*q, y))
            it = GeomAPI_Interpolate(arr, False, 1e-7)
            it.Perform()
            e = BRepBuilderAPI_MakeEdge(it.Curve()).Edge()
        w.Add(e)
    return BRepBuilderAPI_MakeFace(w.Wire(), True).Face()


def pinion(y0, y1, **kw):
    s = BRepPrimAPI_MakePrism(pinion_face(y0, **kw), gp_Vec(0, y1 - y0, 0)).Shape()
    assert volume(s) > 0
    return s


def cyl_y(r, y0, y1, cx=0.0, cz=L.AXLE_Z):
    return BRepPrimAPI_MakeCylinder(gp_Ax2(gp_Pnt(cx, y0, cz), gp_Dir(0, 1, 0)), r, y1 - y0).Shape()


def sync_axle():
    s = cyl_y(L.AXLE_R, L.R_RING[0], L.F_PIN[1])
    s = fuse(s, cyl_y(L.RP, *L.R_RING), pinion(*L.R_PIN), cyl_y(L.RP, *L.F_RING), pinion(*L.F_PIN))
    return s


def rack_teeth(y0, y1, x_lim=L.RACK_X):
    """Straight-sided rack teeth (20 deg flanks) between the root and tip lines, spaces centred on x = k*pitch."""
    half = (L.PITCH / 2.0 - L.THIN_RACK) / 2.0
    t = math.tan(math.radians(L.PA))
    z0, z1 = L.RACK_ROOT - 0.02, L.RACK_TIP
    hb = half + (L.RACK_REF - z0) * t
    ht = half - (z1 - L.RACK_REF) * t
    out = None
    k = 0
    xs = []
    while (k + 0.5) * L.PITCH <= x_lim:
        xs += [(k + 0.5) * L.PITCH, -(k + 0.5) * L.PITCH]
        k += 1
    for xc in sorted(xs):
        tooth = poly_prism([(xc - hb, y0, z0), (xc + hb, y0, z0), (xc + ht, y0, z1), (xc - ht, y0, z1)], (0, y1 - y0, 0))
        out = tooth if out is None else fuse(out, tooth)
    return out


# ------------------------------------------------------------------ base, rail 23, cover, main gear, yoke
def base_e(B):
    gy0, gy1 = L.FR_GROOVE
    B = vcut(B, box(-43.2, 17.6, L.STRIP_Z, 43.2, 21.62, 10.3))                    # old rail top 9.85 -> 9.3
    B = vfuse(B, box(-43.25, 21.5, -3.31, 43.25, L.FR_Y1, L.STRIP_Z))               # rail widened to y 23.6
    B = vcut(B, box(-43.2, gy0, L.RACK_ROOT, 43.2, gy1, L.STRIP_Z + 0.5))          # rack groove
    B = vfuse(B, rack_teeth(*L.FR_TEETH))
    # rail 23 ledges follow the wider rail; ledge block for the rail screw
    for sx in (1, -1):
        B = vfuse(B, box(min(26.0 * sx, 43.25 * sx), -67.9, -3.31, max(26.0 * sx, 43.25 * sx), L.R23_Y1, 1.6))
    sxs, sys_ = L.R23_SCREW
    B = vcut(B, cyl(sxs, sys_, 3.1, -4.9, L.SCREW_HEAD_SEAT), cyl(sxs, sys_, 1.65, L.SCREW_HEAD_SEAT - 0.1, 1.7))
    # main gear tilt pad
    r0, r1, zt = L.MAIN_PAD
    pad = vcut(cyl(0.0, -23.218, r1, -3.4, zt), cyl(0.0, -23.218, r0, -3.5, zt + 0.1))
    B = vfuse(B, pad)
    return B


def rail23_e():
    y0, y1 = L.R23_Y0, L.R23_Y1
    X = L.R23_X
    s = box(-X, y0, 1.6, X, y1, L.STRIP_Z)                                       # outer parts and keel from z 1.6
    s = vcut(s, box(-10.5, y0 - 0.1, 1.5, 10.5, y1 + 0.1, 6.85))                  # middle over the handle gear boss
    g0, g1 = L.R23_GROOVE
    s = vcut(s, box(-X - 0.1, g0, L.RACK_ROOT, X + 0.1, g1, L.STRIP_Z + 0.5))
    s = vfuse(s, rack_teeth(*L.R23_TEETH))
    for sx in (1, -1):                                                           # v47 pins into the base holes
        s = vfuse(s, cyl(36.0 * sx, L.R23_PIN_Y, 1.35, -0.4, 1.61))
    nx, ny = L.R23_SCREW
    za, zb = L.R23_NUT_Z
    af = 5.65
    s = vcut(s, hexagon(nx, ny, af, za, zb, 0.0), box(nx - af / 3 ** 0.5, ny, za, nx + af / 3 ** 0.5, y1 + 0.1, zb),
            cyl(nx, ny, 1.65, 1.5, zb + 0.8))
    return s


def cover_e(C):
    C = vcut(C, box(-43.2, -25.6, 13.5, 43.2, -20.8, L.CEILING_Z))                       # mid rib (axle passes there)
    C = vcut(C, box(-43.2, -71.3, 12.0, 43.2, -67.3, L.CEILING_Z))                       # rear rib + D pad
    C = vcut(C, box(-41.6, L.R_PIN[0] - 0.3, L.CEILING_Z - 0.1, 41.6, L.R_PIN[1] + 0.3, 18.75))  # rear pinion relief
    return C


def main_gear_e(G):
    return vcut(G, cyl(0.0, -23.218 + 36.064, 3.3, 10.0, 12.6))                   # crank pin head off (axle retains)


def yoke_e(Yfile):
    """D yoke (file coords) -> E yoke (file coords). Work in resting coords."""
    dz = L.YOKE_FILE_DZ
    Y = moved(Yfile, 0, 0, -dz)
    cx = L.CHEEK_X
    Y = vcut(Y, box(-cx, 17.55, 7.0, cx, 23.7, 20.95),                           # front pinion / ring / old stem
            box(-7.2, 17.55, 3.0, 7.2, 23.7, 10.1),                              # widened front rail, old legs
            box(-7.2, -28.0, 10.76, 7.2, -18.5, 17.6),                            # old hump (cover mid rib gone)
            box(-7.2, -72.5, 3.0, 7.2, -64.5, 13.0),                              # whole D rear end (rebuilt below)
            box(-3.2, 16.0, 7.0, 3.2, 17.6, 10.35),                               # slot front wall under the axle (traps it)
            box(-3.2, -64.6, 7.0, 3.2, -63.9, 10.35))                             # slot rear end wall under the axle
    cz, cr, co = L.CRADLE_Z, L.CRADLE_R, L.CRADLE_OPEN
    parts = [box(-7.0, L.FRONT_CRADLE[0], 10.3, 7.0, L.FRONT_CRADLE[1], L.TOP_Z),
             box(-7.0, L.REAR_CRADLE[0], 10.3, 7.0, L.REAR_CRADLE[1], L.TOP_Z),
             box(-3.0, 14.6, 17.0, 3.0, 17.55, 21.05),                            # new stem to the arrow plate
             box(-7.0, 23.6, 10.1, 7.0, 24.9, L.TOP_Z),                           # front block (cheek support)
             box(-7.0, L.LIP[0], 7.2, 7.0, L.LIP[1], L.TOP_Z),                    # rear lip behind rail 23
             box(-7.0, -27.0, L.AXLE_Z + L.AXLE_R + 0.15, 7.0, -19.0, L.TOP_Z)]   # mid portal tie over the axle
    for sx in (1, -1):
        parts.append(box(min(cx * sx, 7.0 * sx), 17.7, 10.1, max(cx * sx, 7.0 * sx), 27.0, L.TOP_Z))
        parts.append(box(min(cx * sx, 7.0 * sx), L.LIP[0], 10.1, max(cx * sx, 7.0 * sx), -67.0, L.TOP_Z))
        parts.append(box(min(3.65 * sx, 7.0 * sx), -27.0, 10.7, max(3.65 * sx, 7.0 * sx), -19.0, L.TOP_Z))   # portal legs on the walls
    N = parts[0]
    for p in parts[1:]:
        N = vfuse(N, p)
    Y = vfuse(Y, N)
    # axle channel last: downward-open cradles (r 3.1, opening 6.1) through both blocks and the old slot end walls
    y0, y1 = L.REAR_CRADLE[0] - 0.15, L.FRONT_CRADLE[1] + 0.05
    Y = vcut(Y, vfuse(cyl_y(cr, y0, y1, cz=cz), box(-co, y0, 10.2, co, y1, cz)))
    return moved(Y, 0, 0, dz)


def hardware_e():
    """M3x6 socket head screws (4 case, dial, rail 23) and 6 M3 nuts."""
    import c_case as CC
    import c2_layout as CL
    out = {}
    for i, (cx, cy) in enumerate(CC.CORNERS):
        out["HW_M3x6_Case_%d" % (i + 1)] = fuse(cyl(cx, cy, 2.75, CC.CB_Z_NEW, CC.CB_Z_NEW + 3.0), cyl(cx, cy, 1.5, CC.CB_Z_NEW - 6.0, CC.CB_Z_NEW + 0.01))
        rot = 30.0 if cy < 0 else 0.0
        out["HW_M3_Nut_Case_%d" % (i + 1)] = cut(hexagon(cx, cy, 5.5, CC.NUT_TOP - 2.4, CC.NUT_TOP, rot), cyl(cx, cy, 1.5, CC.NUT_TOP - 3.5, CC.NUT_TOP + 1))
    cx, cy = CL.DIAL_C
    seat = CC.DIAL_CB_SEAT
    out["HW_M3x6_Dial"] = fuse(cyl(cx, cy, 2.75, seat, seat + 3.0 - 0.02), cyl(cx, cy, 1.5, seat - 6.0, seat + 0.01))
    out["HW_M3_Nut_Dial"] = cut(hexagon(cx, cy, 5.5, 24.0 - 2.4, 24.0, 30.0), cyl(cx, cy, 1.5, 20, 25))
    nx, ny = L.R23_SCREW
    hs = L.SCREW_HEAD_SEAT
    out["HW_M3x6_Rail"] = fuse(cyl(nx, ny, 2.75, hs - 3.0, hs), cyl(nx, ny, 1.5, hs - 0.01, hs + 6.0))
    za, zb = L.R23_NUT_Z
    out["HW_M3_Nut_Rail"] = cut(hexagon(nx, ny, 5.5, za + 0.05, za + 2.45, 0.0), cyl(nx, ny, 1.5, za - 1, zb + 1))
    return out
