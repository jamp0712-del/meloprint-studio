﻿# -*- coding: utf-8 -*-
# Concept E constants: v47 crank + yoke, yaw locked by a sync axle (two m0.8 pinions on racks at the front rail and
# rail 23, rolling rings on pitch-line strips), main gear tilt pad, M3x6 hardware. Yoke coordinates are "resting".
import math

YOKE_FILE_DZ = 0.248                 # stored yoke B-rep = resting + 0.248 (same convention as v47 / D)

# sync axle and pinions
M = 0.8
Z = 10
X_SHIFT = 0.42
PA = 20.0
RP = M * Z / 2.0                     # 4.0 pitch radius = rolling ring radius
RA = RP + M * (1.0 + X_SHIFT)        # 5.136
RF = RP - M * (1.25 - X_SHIFT)       # 3.336
THIN_PINION = 0.08                   # tooth thickness reduction at the pitch circle (total, both flanks)
THIN_RACK = 0.08                     # -> circumferential backlash 0.16
AXLE_R = 3.0
AXLE_Z = 13.3                        # axle centre (resting)
STRIP_Z = AXLE_Z - RP                # 9.3 rolling strip top = working pitch line
RACK_REF = STRIP_Z - X_SHIFT * M     # 8.964 rack reference line
RACK_TIP = RACK_REF + M              # 9.764
RACK_ROOT = RACK_REF - 1.25 * M      # 7.964
PITCH = math.pi * M                  # 2.5133
RACK_X = 41.9                        # teeth centres within |x| <= RACK_X

# axle stations along y (rear -> front)
R_RING = (-70.7, -69.55)
R_PIN = (-69.15, -67.25)
F_RING = (17.85, 19.0)
F_PIN = (19.4, 21.3)

# front rail (base): strip / groove / solid bands
FR_Y0, FR_Y1 = 17.65, 23.6
FR_GROOVE = (19.15, 21.55)
FR_TEETH = (19.25, 21.45)
# rail 23
R23_Y0, R23_Y1 = -70.9, -64.6
R23_GROOVE = (-69.4, -67.0)
R23_TEETH = (-69.3, -67.1)
R23_X = 43.2

# yoke
CRADLE_R = 3.1
CRADLE_Z = AXLE_Z - 0.1              # yoke rests on the axle top
CRADLE_OPEN = 3.05                   # half width of the downward opening
CEILING_Z = 17.4                     # cover underside (measured)
TOP_Z = 17.3                         # hold-down / roll stop, 0.1 under the cover ceiling
CHEEK_X = 5.45
FRONT_CRADLE = (5.0, 17.75)
REAR_CRADLE = (-67.15, -58.0)
LIP = (-71.65, -71.0)

# main gear tilt pad (annulus under the gear, 0.1 below its underside z -1.8)
MAIN_PAD = (12.0, 14.0, -1.9)

R23_PIN_Y = -69.325                  # v47 pin / base hole position
# rail 23 screw (M3x6 from the base underside into a nut in the rail)
R23_SCREW = (31.0, -67.5)
R23_NUT_Z = (3.45, 5.95)
SCREW_HEAD_SEAT = 0.3
